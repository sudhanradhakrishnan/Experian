﻿namespace Card.BusinessLayer.Implementation
{
    internal class EmployeeInfo
    {
    }
}