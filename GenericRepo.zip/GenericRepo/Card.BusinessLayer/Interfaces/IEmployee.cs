﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Card.DataLayer.Entity;

namespace Card.BusinessLayer.Interfaces
{
    public interface IEmployee
    {
        IEnumerable<EmployeeInfo> EmployeeGet();
        string EmployeeInsert(EmployeeInfo emp);
        string EmployeeUpdate(EmployeeInfo emp);
        string EmployeeDelete(int id);
    }
}
