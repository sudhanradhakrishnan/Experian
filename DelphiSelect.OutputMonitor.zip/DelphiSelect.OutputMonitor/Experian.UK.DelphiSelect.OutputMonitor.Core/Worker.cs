using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace Experian.UK.DelphiSelect.OutputMonitor.Core
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IServiceProvider _services;
        private IHttpClientFactory ClientFactory { get; }
        private Timer timer;
        private WorkerConfigurationModel Config { get; }
        private IHostApplicationLifetime HostApplicationLifetime { get; }


        public Worker(ILogger<Worker> logger, IHostApplicationLifetime hostApplicationLifetime, IServiceProvider services, IHttpClientFactory clientFactory, IOptions<WorkerConfigurationModel> config)
        {
            _logger = logger;
            _services = services;
            ClientFactory = clientFactory;
            Config = config.Value;
            HostApplicationLifetime = hostApplicationLifetime;
        }
       
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                SearchSplunkLog();
               /* try
                {

                    var client = ClientFactory.CreateClient("HttpClientWithSSLUntrusted");

                    client.BaseAddress = new Uri(Config.Url);
                    var request = new HttpRequestMessage(HttpMethod.Post, Config.SearchPath);
                    var byteArray = Encoding.ASCII.GetBytes($"{Config.User}:{Config.Password}");
                    request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
                    var keyValues1= new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("search",
                            "search (\"Message.EventID\"=DSAV01 host=\"CEMS-UAT2-RET*\")")
                    };
                    var keyValues = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("search",
                            "search (\"Message.SourceApp\"=DataSelect \"Message.EventID\"=DSAV01 \"ApplicationType\")")
                    };
                    /*
                     
                     \"Message.SourceApp\"=DataSelect \"Message.EventID\"=DSAV01 \"ApplicationType\"*/
                    //var keyValues = new List<KeyValuePair<string, string>>()
                    //{
                    //    new KeyValuePair<string, string>("search",
                    //        "search (index=*uat* Message.SourceApp=DataSelect Message.EventID=DSAV01 ApplicationType | rename Message.SecurityParameters.experianClientID as Client_ID, Message.SecurityParameters.AccountNumber as AccountNumber  | convert timeformat='%m/%Y' ctime(_time) as Month | stats values(ApplicationType) as Application_Type by Client_ID, AccountNumber, Month | eval Key='Application_Type_List' | table Key Month Client_ID AccountNumber Application_Type)")
                    //};
/*
                    request.Content = new FormUrlEncodedContent(keyValues);
                    var response = await client.SendAsync(request);

                    string strinvalue = response.Content.ReadAsStringAsync().Result;
                    XmlDocument xmlDoc = new XmlDocument();
                    TextReader reader = new StringReader(strinvalue);
                    xmlDoc.Load(reader);
                    string sid = xmlDoc.SelectSingleNode("/response/sid").InnerText;

                   // string path = Config.SearchPath + "/" + sid + "/results";
                    string path = Config.SearchPath + "/" + sid + Config.Results;
                    var request2 = new HttpRequestMessage(HttpMethod.Get, path);
                    var byteArray2 = Encoding.ASCII.GetBytes($"{Config.User}:{Config.Password}");
                    request2.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray2));

                    var response1 = await client.SendAsync(request2);
                    string strinvalue1 = response1.Content.ReadAsStringAsync().Result;

                    XmlDocument xmlDoc1 = new XmlDocument();
                    TextReader reader1 = new StringReader(strinvalue1);
                    xmlDoc1.Load(reader1);


                    Console.Write(strinvalue1);
                }
                catch (Exception e)
                {
                    // example log
                    //LogProvider.Log(LogLevel.Debug, EventIds.PAY_HOL_ING_500, "This is embarassing: seems we've not handled an exception", e);
                }

                // example log
                //LogProvider.Log(LogLevel.Debug, EventIds.PAY_HOL_ING_004, $"Complete :{this.GetType().Name} - Stopping App");

                // this forces it to stop (needed for cloud process)
                8
                    */
                HostApplicationLifetime.StopApplication();
            }
        }


        //private void DoWork(object state)
        //{
        //    SearchSplunkLog();
        //    using (var scope = _services.CreateScope())
        //    {
        //        var ExcelServices = scope.ServiceProvider.GetRequiredService<IExcelServices>();
        //        ExcelServices.Run();
        //    }
        //    _logger.LogInformation("Timed Background Service is working.");
        //}

        private void SearchSplunkLog()
        {
            // do some work
            using (var scope = _services.CreateScope())
            {
                var splunkService = scope.ServiceProvider.GetRequiredService<ISplunkService>();
                splunkService.AccessSplunk();
            }
        }


        private void executeRequest(string url, string sessionKey, string args, string httpMethod)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) =>
            {
                return true;
            };
            // ServicePointManager.ServerCertificateValidationCallback += delegate { return true; };

            HttpWebRequest req = (HttpWebRequest)HttpWebRequest.Create(url);
            req.Method = httpMethod;
            if (!string.IsNullOrEmpty(sessionKey))
                req.Headers.Add("Authorization", "Splunk " + sessionKey);

            if (httpMethod == "POST")
            {
                if (!string.IsNullOrEmpty(args)) req.ContentLength = args.Length;
                req.ContentType = "application/x-www-form-urlencoded";
                Stream reqStream = req.GetRequestStream();
                StreamWriter sw = new StreamWriter(reqStream);
                sw.Write(args);
                sw.Close();
            }


            HttpWebResponse res = (HttpWebResponse)req.GetResponse();
            StreamReader sr = new StreamReader(res.GetResponseStream());
            if (sr.EndOfStream)
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(sr);
            }
           
            sr.Close();
            // xmlDoc.;
        }

        //public override Task StartAsync(CancellationToken cancellationToken)
        //{
        //    _logger.LogInformation("Service Starting");

        //  //  timer = new Timer(DoWork, null, TimeSpan.Zero,
        //   //  TimeSpan.FromSeconds(250));// to be chnaged

        //    return Task.CompletedTask;
        //}

        //protected void loothismethos(object source, FileSystemEventArgs e)
        //{
        //    if (e.ChangeType == WatcherChangeTypes.Created)
        //    {
        //        _logger.LogInformation($"InBound Change Event Triggered by [{e.FullPath}]");

        //        // do some work
        //        using (var scope = _services.CreateScope())
        //        {
        //            var splunkService = scope.ServiceProvider.GetRequiredService<ISplunkService>();
        //            splunkService.AccessSplunk();
        //        }

        //        _logger.LogInformation("Done with Inbound Change Event");
        //    }
        //}

        //public override async Task StopAsync(CancellationToken cancellationToken)
        //{
        //    _logger.LogInformation("Stopping Service");
        //    await base.StopAsync(cancellationToken);
        //}

        //public override void Dispose()
        //{
        //    _logger.LogInformation("Disposing Service");
        //    base.Dispose();
        //}




    }
    
}
