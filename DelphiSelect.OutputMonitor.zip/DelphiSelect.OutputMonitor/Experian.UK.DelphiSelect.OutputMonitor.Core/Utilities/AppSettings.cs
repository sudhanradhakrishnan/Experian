﻿namespace Experian.UK.DelphiSelect.OutputMonitor.Core
{
    public class AppSettings
    {
        public string InputFolder { get; set; }
        public string SplunkURL { get; set; }
       
    }
}
