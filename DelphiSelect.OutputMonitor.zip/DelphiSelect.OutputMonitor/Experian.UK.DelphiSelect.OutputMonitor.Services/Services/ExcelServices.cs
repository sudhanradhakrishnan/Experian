﻿using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Microsoft.Extensions.Logging;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Services
{
    public class ExcelServices: IExcelServices
    {

        private readonly ILogger<ExcelServices> _logger;

        public ExcelServices(ILogger<ExcelServices> logger)
        {
            _logger = logger;
        }

        public void Run()
        {
            _logger.LogInformation("In Excel services A");

            string strFilePath = @"C:\Temp\Excel\";
            var path = strFilePath + "Data" + DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss") + ".xlsx";

            Application ExcelApp = new Application();
            Workbook ExcelWorkBook = null;
            Worksheet ExcelWorkSheet = null;

            ExcelApp.Visible = true;
            ExcelWorkBook = ExcelApp.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);
            try
            {
                ExcelWorkSheet = (Worksheet)ExcelWorkBook.Worksheets[1]; // Compulsary Line  in which sheet you want to write data 
                //Writing data into excel of 100 rows with 10 column 
                for (int r = 1; r < 101; r++) //r stands for ExcelRow and c for ExcelColumn
                {
                    // Excel row and column start positions for writing Row=1 and Col=1
                    for (int c = 1; c < 11; c++)
                        ExcelWorkSheet.Cells[r, c] = "R" + r + "C" + c;
                };
                ExcelWorkSheet.Name = "MySheet";
                //ExcelWorkBook.Worksheets = "MySheet";//Renaming the Sheet1 to MySheet
                ExcelWorkBook.SaveAs(path);
                ExcelWorkBook.Close();
                ExcelApp.Quit();
                Marshal.ReleaseComObject(ExcelWorkSheet);
                Marshal.ReleaseComObject(ExcelWorkBook);
                Marshal.ReleaseComObject(ExcelApp);
            }
            catch (Exception exHandle)
            {
                Console.WriteLine("Exception: " + exHandle.Message);
                Console.ReadLine();
            }
            finally
            {

                foreach (Process process in Process.GetProcessesByName("Excel"))
                    process.Kill();
            }
            _logger.LogInformation("In Excel services B");

        }

    }
}
