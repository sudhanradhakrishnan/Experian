﻿using Experian.UK.DelphiSelect.OutputMonitor.Model;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Splunk.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Xml;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Services
{
    public class SplunkService : ISplunkService
    {
        private string QueryStatus=string.Empty;

        private IHttpClientFactory ClientFactory { get; }
        private Timer timer;
        private WorkerConfigurationModel Config { get; }
        private readonly ILogger<SplunkService> _logger;
        private HttpClient client;

        public SplunkService(ILogger<SplunkService> logger, IHttpClientFactory clientFactory, IOptions<WorkerConfigurationModel> config)
        {
            _logger = logger;
            ClientFactory = clientFactory;
            Config = config.Value;
            client = ClientFactory.CreateClient("HttpClientWithSSLUntrusted");
            client.BaseAddress = new Uri(Config.Url);

        }
        public string AccessSplunk()
        {
            Console.WriteLine("Splunk Started ");
            Run().Wait();
            Console.Write("Press return to exit: ");
            Console.ReadLine();
            return "OK";
        }

        private async Task Run()
        {
         
            try
            {
                HttpRequestMessage requestSid;
                string path = string.Empty;
                GetHttpClientConnection(HttpMethod.Post, out requestSid, Config.SearchPath);
                string sid = await ReadSidFromAPI(client, requestSid);
                Console.WriteLine("/response/sid : " + sid);

                string queryStatus = await FetchQueryStatus(sid);
              

                HttpRequestMessage request;

                path = Config.SearchPath + "/" + sid + Config.Results;
                GetHttpClientConnection(HttpMethod.Get, out request, path);


                var response = await client.SendAsync(request);
                string responsestring = response.Content.ReadAsStringAsync().Result;
                XmlDocument xmlDoc = ConvertXMLFromString(responsestring);




            }
            catch (AuthenticationFailureException)
            {
                Console.WriteLine("Can't get service configuration without logging in.");
            }
            Console.WriteLine("Log off");
           
        }

        private async Task<string> FetchQueryStatus(string sid)
        {
            if (QueryStatus == SplunkQueryResponse.DONE.ToString())
                return QueryStatus;

            string status = string.Empty;
            HttpRequestMessage sidrequest;
            string path = Config.SearchPath + "/" + sid;
            GetHttpClientConnection(HttpMethod.Get, out sidrequest, path);

            var dispatchStateresponse = await client.SendAsync(sidrequest);

            string dispatchStateString = dispatchStateresponse.Content.ReadAsStringAsync().Result;

            XmlDocument dispatchStateXmlDoc = ConvertXMLFromString(dispatchStateString);
            XmlNodeList nodes = dispatchStateXmlDoc.GetElementsByTagName("content");
            if (nodes != null && nodes.Count > 0)
            {
                XmlNode node = nodes[0];
                if (node.HasChildNodes && node.FirstChild.Name == "s:dict")
                {
                    XmlNode ChildNodes = node.ChildNodes[0];

                    XmlNodeList childlist = ChildNodes.ChildNodes;
                    var child = childlist.Cast<XmlNode>()
                                 .Where(n => n.Attributes[0].Value == "dispatchState").SingleOrDefault();
                    if (child != null)
                    {
                        status = child.InnerText;
                        Console.WriteLine("Splunk Query Status:-{0}", child.InnerText);

                        switch (status.ToUpper())
                        {
                            case "DONE":
                                QueryStatus = child.InnerText;
                                break;
                            case "FAILED":
                                Console.WriteLine("Splunk Query Status:-{0}", child.InnerText);
                                Console.ReadLine();
                                break;
                        }
                        Thread.Sleep(1 * 60 * 1000);
                        _ = await FetchQueryStatus(sid);
                    }
                }
            }

            return status;
        }

        private static async Task<string> ReadSidFromAPI(HttpClient client, HttpRequestMessage request)
        {
           
            var keyValues = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("search",
                            "search (\"Message.SourceApp\"=DataSelect \"Message.EventID\"=DSAV01 \"ApplicationType\" Message.SecurityParameters.experianClientID  as Client_ID)")//\"Message.SourceApp\"=DataSelect \"Message.EventID\"=DSAV01 \"ApplicationType\" |\"Earliest \": \"04/19/2021:0:0:0\",\"Latest\": \"04/19/2021:23:59:59\"
                    };
            /*
              var keyValues = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("search",
                            "search (\"Message.SourceApp\"=DataSelect \"Message.EventID\"=DSAV01 \"ApplicationType\" | )")//\"Message.SourceApp\"=DataSelect \"Message.EventID\"=DSAV01 \"ApplicationType\" |\"Earliest \": \"04/19/2021:0:0:0\",\"Latest\": \"04/19/2021:23:59:59\"
                    };
             */
            request.Content = new FormUrlEncodedContent(keyValues);
            var response = await client.SendAsync(request);

            string responseSid = response.Content.ReadAsStringAsync().Result;
            XmlDocument xmlDoc = ConvertXMLFromString(responseSid);
            string sid = xmlDoc.SelectSingleNode("/response/sid").InnerText;
            return sid;
        }

        private void GetHttpClientConnection(HttpMethod verb, out HttpRequestMessage request,string searchPath)
        {
           
            request = new HttpRequestMessage(verb, searchPath);
            var byteArray = Encoding.ASCII.GetBytes($"{Config.User}:{Config.Password}");
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
        }

        private static XmlDocument ConvertXMLFromString(string strinvalue)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.XmlResolver = null;
            TextReader reader = new StringReader(strinvalue);
            xmlDoc.Load(reader);
            return xmlDoc;
        }
    }
}
