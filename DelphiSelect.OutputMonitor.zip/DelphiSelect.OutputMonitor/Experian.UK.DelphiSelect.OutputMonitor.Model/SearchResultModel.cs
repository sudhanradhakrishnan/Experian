﻿using System;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model
{
    public class SearchResultModel
    {
        // private string
        public string Key { get; set; }
        public string Month { get; set; }
        public string Client_ID { get; set; }
        public string AccountNumber { get; set; }
        public string Application_Type { get; set; }

    }
}
