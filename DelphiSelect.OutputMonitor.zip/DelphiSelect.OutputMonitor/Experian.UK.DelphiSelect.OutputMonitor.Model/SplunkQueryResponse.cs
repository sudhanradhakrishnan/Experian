﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model
{
   
    public enum SplunkQueryResponse
    {
        [Display(Name = "Query is queued.")]
        [Description("This query is queued now.")]
        QUEUED,

        [Display(Name = "Query is Parsing.")]
        [Description("This query is Parsing now.")]
        PARSING,

        [Display(Name = "Query is Running.")]
        [Description("This query is Running now.")]
        RUNNING,

        [Display(Name = "Query is Paused.")]
        [Description("This query is paused now.")]
        PAUSED ,

        [Display(Name = "Query is Finalizing.")]
        [Description("This query is Finalizing now.")]
        FINALIZING,

        [Display(Name = "Query Failed.")]
        [Description("This query Failed now.")]
        FAILED,

        [Display(Name = "Query Completed.")]
        [Description("This query Done now.")]
        DONE
       
    }
}
