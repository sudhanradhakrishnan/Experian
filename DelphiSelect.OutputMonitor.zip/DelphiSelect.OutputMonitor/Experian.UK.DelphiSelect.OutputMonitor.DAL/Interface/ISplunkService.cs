﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface
{
    public interface IAddSplunkSearchContext
    {

    }
}
