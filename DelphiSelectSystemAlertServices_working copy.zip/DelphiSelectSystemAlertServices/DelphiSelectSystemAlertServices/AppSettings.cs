﻿namespace DelphiSelectSystemAlertServices
{
    public class AppSettings
    {
        public string InputFolder { get; set; }
    }
}
