﻿using Microsoft.Extensions.Logging;
using System.IO;
using System.Text;

namespace DelphiSelectSystemAlertServices.Services
{
    public interface IServiceA
    {
        void Run();
    }

    public class ServiceA : IServiceA
    {
        private readonly ILogger<ServiceA> _logger;
        private readonly IServiceB _serviceB;

        public ServiceA(ILogger<ServiceA> logger, IServiceB serviceB)
        {
            _logger = logger;
            _serviceB = serviceB;
        }

        public void Run()
        {
            _logger.LogInformation("In Service A");

            string strFilePath = @"C:\Temp\Data.csv";
            string strSeperator = ",";
            StringBuilder sbOutput = new StringBuilder();

            int[][] inaOutput = new int[][]{
            new int[]{1000, 2000, 3000, 4000, 5000},
            new int[]{6000, 7000, 8000, 9000, 10000},
            new int[]{11000, 12000, 13000, 14000, 15000} };

            int ilength = inaOutput.GetLength(0);

            for (int i = 0; i < ilength; i++)
                sbOutput.AppendLine(string.Join(strSeperator, inaOutput[i]));

            // Create and write the csv file
            File.WriteAllText(strFilePath, sbOutput.ToString());

            // To append more lines to the csv file
            File.AppendAllText(strFilePath, sbOutput.ToString());

            _serviceB.Run();
        }
    }
}
