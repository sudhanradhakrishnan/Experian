﻿using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Splunk.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Xml;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Services
{
    public class SplunkService : ISplunkService
    {
        // private string BaseUrl = "https://splunk-cs.uk.experian.local";//https://splunk-cs-api.uk.experian.local/services/auth/login
        private string BaseUrl = "https://splunk-cs-api.uk.experian.local/services/auth/login";

        private IHttpClientFactory ClientFactory { get; }
        private Timer timer;
        private WorkerConfigurationModel Config { get; }
        private readonly ILogger<SplunkService> _logger;
        private HttpClient client;

        public SplunkService(ILogger<SplunkService> logger, IHttpClientFactory clientFactory, IOptions<WorkerConfigurationModel> config)
        {
            _logger = logger;
            ClientFactory = clientFactory;
            Config = config.Value;
            client = ClientFactory.CreateClient("HttpClientWithSSLUntrusted");
            client.BaseAddress = new Uri(Config.Url);

        }
        public string AccessSplunk()
        {
            Console.WriteLine("Splunk Started ");
            Run().Wait();
            Console.Write("Press return to exit: ");
            Console.ReadLine();
            return "OK";
        }

        private async Task Run()
        {
         
            try
            {
                HttpRequestMessage requestSid;

                GetHttpClientConnection(HttpMethod.Post, out requestSid, Config.SearchPath);
                string sid = await ReadSidFromAPI(client, requestSid);
                Console.WriteLine("/response/sid : " + sid);
                Thread.Sleep(2 * 60 * 1000);
                HttpRequestMessage request;
                // string path = Config.SearchPath + "/" + sid + "/results";
                string path = Config.SearchPath + "/" + sid + Config.Results;
                GetHttpClientConnection(HttpMethod.Get, out request, path);


                var response = await client.SendAsync(request);
                string strinvalue1 = response.Content.ReadAsStringAsync().Result;
                NewMethod(strinvalue1);

            }
            catch (AuthenticationFailureException)
            {
                Console.WriteLine("Can't get service configuration without logging in.");
            }
            Console.WriteLine("Log off");
           
        }

        private static void NewMethod(string strinvalue1)
        {
            XmlDocument xmlDoc1 = new XmlDocument();
            TextReader reader1 = new StringReader(strinvalue1);
            xmlDoc1.Load(reader1);
        }

        private static async Task<string> ReadSidFromAPI(HttpClient client, HttpRequestMessage request)
        {
            //var keyValues1 = new List<KeyValuePair<string, string>>()
            //        {
            //            new KeyValuePair<string, string>("search",
            //                "search (\"Message.EventID\"=DSAV01 host=\"CEMS-UAT2-RET*\")")
            //        };
            var keyValues = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("search",
                            "search (\"Message.SourceApp\"=DataSelect \"Message.EventID\"=DSAV01 \"ApplicationType\")")
                    };
            request.Content = new FormUrlEncodedContent(keyValues);
            var response = await client.SendAsync(request);

            string responseSid = response.Content.ReadAsStringAsync().Result;
            XmlDocument xmlDoc = ConvertXMLFromString(responseSid);
            string sid = xmlDoc.SelectSingleNode("/response/sid").InnerText;
            return sid;
        }

        private void GetHttpClientConnection(HttpMethod verb, out HttpRequestMessage request,string searchPath)
        {
           
            request = new HttpRequestMessage(verb, searchPath);
            var byteArray = Encoding.ASCII.GetBytes($"{Config.User}:{Config.Password}");
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
        }

        private static XmlDocument ConvertXMLFromString(string strinvalue)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.XmlResolver = null;
            TextReader reader = new StringReader(strinvalue);
            xmlDoc.Load(reader);
            return xmlDoc;
        }
    }
}
