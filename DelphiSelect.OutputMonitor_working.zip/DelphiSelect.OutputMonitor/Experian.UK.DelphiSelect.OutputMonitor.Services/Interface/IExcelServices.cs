﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Interface
{
    public interface IExcelServices
    {
        void Run();
    }
}
