using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Net.Http;

namespace Experian.UK.DelphiSelect.OutputMonitor.Core
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseWindowsService()
                .ConfigureServices((hostContext, services) =>
                {
                    Console.WriteLine("Environment: " + hostContext.HostingEnvironment.EnvironmentName);
                    Console.WriteLine("Root Path: " + hostContext.HostingEnvironment.ContentRootPath);
                    IConfiguration configuration = hostContext.Configuration;
                   // services.AddExperianLogging(configuration, new ApplicationOptions { Id = "xxxxx", Name = "Delphi Select Output Monitor" });
                    services.AddHostedService<Worker>();
                    services.Configure<AppSettings>(configuration.GetSection("AppSettings"));
                    services.Configure<WorkerConfigurationModel>(configuration.GetSection("splunk"));
                    services.AddHttpClient("HttpClientWithSSLUntrusted").ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
                    {
                        ClientCertificateOptions = ClientCertificateOption.Manual,
                        ServerCertificateCustomValidationCallback =
                            (httpRequestMessage, cert, cetChain, policyErrors) =>
                            {
                                return true;
                            }
                    });
                    services.AddScoped<IEmailService, EmailService>();
                    services.AddScoped<IExcelServices, ExcelServices>();
                    services.AddScoped<ISplunkService, SplunkService>();//ISplunkService
                });
    }


}
