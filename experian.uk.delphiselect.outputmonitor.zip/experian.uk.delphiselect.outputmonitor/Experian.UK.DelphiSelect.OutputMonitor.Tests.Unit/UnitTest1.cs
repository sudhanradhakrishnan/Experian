using System;
using Xunit;

namespace Experian.UK.DelphiSelect.OutputMonitor.Tests.Unit
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
        }
    }
}