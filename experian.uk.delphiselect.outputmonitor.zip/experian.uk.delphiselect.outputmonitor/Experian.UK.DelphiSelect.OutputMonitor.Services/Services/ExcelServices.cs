﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Model;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Utility;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Services
{
    public class ExcelServices: IExcelServices
    {

        private readonly ILogger<ExcelServices> _logger;
        private List<SearchResultResponse> lstobject;
        private readonly IServiceProvider _services;
        private DelphiSelectOutputMonitorConfig Config { get; }
        private IDailyAlertingReportContext dailyAlertReportContext { get; }

        private readonly ExcelUtilities _excelUtilities;



        public ExcelServices(ILogger<ExcelServices> logger, IServiceProvider services, IOptions<DelphiSelectOutputMonitorConfig> config, IDailyAlertingReportContext dailyAlertingReportContext)
        {
            _logger = logger;
            _services = services;
            Config = config.Value;
            dailyAlertReportContext = dailyAlertingReportContext;
            _excelUtilities = new ExcelUtilities();
        }
        public void RunDailyExcelReportServices()
        {
            Console.WriteLine("ExcelServices Started ");

            Run();

            using (var scope = _services.CreateScope())
            {
                var emailService = scope.ServiceProvider.GetRequiredService<IEmailService>();
                emailService.Run();
            }

            Console.Write("Excel services Completed: ");
        }

        public void RunMonthlyExcelReportServices()
        {
            _logger.LogInformation("Monthly Report :: Excel services Started");
            // Run(); TODO: monthly report

            //using (var scope = _services.CreateScope())
            //{
            //    var emailService = scope.ServiceProvider.GetRequiredService<IEmailService>();
            //    emailService.Run();
            //}

        }

        private void Run()
        {
            _logger.LogInformation("Excel services Started");


            List<DailyResultReport> yesterdayRecords = dailyAlertReportContext.GetYesterdayReport();

            List<DailyAlertingReport> lastMonthRecords = dailyAlertReportContext.GetLastMonthReport();

            if (yesterdayRecords.Count() > 0)
            {
                CalculateAggregateDelphiScorecardAvgScoreApplicationType(yesterdayRecords, lastMonthRecords);
            }

            WriteDatatoExcelTemplate();
        }

        #region Daily reoprt
        private void CalculateAggregateDelphiScorecardAvgScoreApplicationType(List<DailyResultReport> yesterdayRecords, List<DailyAlertingReport> lastMonthReport)
        {
            foreach (DailyResultReport yesterdayRecord in yesterdayRecords)
            {
                
                var lastMonthRecords = lastMonthReport
                           .Where(t => t.RequirementCriteria == yesterdayRecord.RequirementCriteria)
                           .Where(e => e.Client_ID == yesterdayRecord.Client_ID)
                           .Where(t => t.AccountNumber == yesterdayRecord.AccountNumber)
                           .ToList();
                if (lastMonthRecords != null)
                {
                    var searchKey = new HashSet<string>(ConstantValues.SearchCriteriaKey);//DelphiScorecard
                    var scorecard = new HashSet<string>(ConstantValues.DelphiScorecard);//
                    if (searchKey.Contains(yesterdayRecord.KeyValue))
                    {

                        CalculatePreviousMonthAggregate(yesterdayRecord, lastMonthRecords);
                    }
                    else if (scorecard.Contains(yesterdayRecord.KeyValue))
                    {
                        calculatePreviousMonthDelphiScorecard(lastMonthReport, yesterdayRecord);
                        calculatePreviousMonthAvgScore(lastMonthReport, yesterdayRecord);
                        calculatePreviousMonthNOC(yesterdayRecord);
                        calculatePreviousMonthApplicationType(lastMonthReport, yesterdayRecord);
                    }

                }


            }
        }

        #region Delphi Score Card
        private readonly List<PreviousMonthCalculation> PreviousMonthDelphiScorecard = new List<PreviousMonthCalculation>();
        private void calculatePreviousMonthDelphiScorecard(List<DailyAlertingReport> lastMonthReport, DailyResultReport yesterday)
        {
            string[] D008D009A = new string[1] { "D008" };
            var scorecard = new HashSet<string>(D008D009A);
            if (scorecard.Contains(yesterday.KeyValue))
            {
                PreviousMonthCalculation delphiScorecard;
                List<DailyAlertingReport> filterByClientIdAccountNumber;
                AssignPreviousMonthCalculation(lastMonthReport, yesterday, out delphiScorecard, out filterByClientIdAccountNumber);
                var lastMonthAggregate = filterByClientIdAccountNumber.GroupBy(s => new { s.Delphi_Scorecard }).ToList();

                string scorecardjoin = string.Join(" ", lastMonthAggregate.Select(x => x.Key.Delphi_Scorecard).ToList());

                string[] scorecardList = scorecardjoin.Split(" ");
                var scorecards = scorecardList.Distinct().ToList();


                delphiScorecard.LastMonthDelphiScorecards = string.Join(" ", scorecards.Select(x => x).ToList());

                PreviousMonthDelphiScorecard.Add(delphiScorecard);
            }



        }

        #endregion

        #region Previous Month Avg_Score

        private readonly List<PreviousMonthCalculation> PreviousMonthAvgScore = new List<PreviousMonthCalculation>();
        private void calculatePreviousMonthAvgScore(List<DailyAlertingReport> lastMonthReport, DailyResultReport yesterday)
        {
            string[] keystring = new string[6] { "D009A", "D010", "D013", "D016", "D028", "D030A" };
            var AvgScore = new HashSet<string>(keystring);
            if (AvgScore.Contains(yesterday.KeyValue))
            {

                PreviousMonthCalculation previousMonthAvgScore;
                List<DailyAlertingReport> filterByClientIdAccountNumber;
                AssignPreviousMonthCalculation(lastMonthReport, yesterday, out previousMonthAvgScore, out filterByClientIdAccountNumber);
                //We have current month avg. Find out Last_Month_avg.   
                //Change= Current_Month_avg-Last_Month_avg
                //Change_Percentage=(Change/Last_Month_avg)x100 
                var Last_Month_avg = filterByClientIdAccountNumber.GroupBy(s => new { s.Client_ID, s.AccountNumber, s.RequirementCriteria, s.KeyValue })
                                                    .Select(g =>
                                                        new
                                                        {
                                                            KeyValue = g.Key.KeyValue,
                                                            RequirementCriteria = g.Key.RequirementCriteria,
                                                            Client_ID = g.Key.Client_ID,
                                                            AccountNumber = g.Key.AccountNumber,
                                                            Lastmonthcount = ((g.Sum(x => x.CountActiveCAIS))),
                                                            LastMonthApplications = ((g.Sum(x => x.TotalApplications))),
                                                            TotalAvg = ((g.Sum(x => x.avg) / filterByClientIdAccountNumber.Count))
                                                        }
                                                  ).ToList();
                if (Last_Month_avg.Count > 0)
                {
                    previousMonthAvgScore.LastMonthAvg = Last_Month_avg[0].TotalAvg;
                    previousMonthAvgScore.LastMonthCount = Last_Month_avg[0].Lastmonthcount;
                    previousMonthAvgScore.LastMonthApplicationCount = Last_Month_avg[0].LastMonthApplications;
                }

                PreviousMonthAvgScore.Add(previousMonthAvgScore);
            }
        }

        #endregion

        #region Previous Month Notice of Correction

        private readonly List<PreviousMonthCalculation> PreviousMonthNOC = new List<PreviousMonthCalculation>();
        private void calculatePreviousMonthNOC(DailyResultReport yesterday)
        {
            string[] keystring = new string[1] { "D024" };
            var Noc = new HashSet<string>(keystring);
            if (Noc.Contains(yesterday.KeyValue))
            {
                PreviousMonthCalculation delphiScorecard = new PreviousMonthCalculation
                {
                    ID = yesterday.ID,
                    KeyValue = yesterday.KeyValue,
                    QueryDate = yesterday.QueryDate,
                    Client_ID = yesterday.Client_ID,
                    AccountNumber = yesterday.AccountNumber,
                    CountActiveCAIS = yesterday.CountActiveCAIS,
                    TotalApplications = yesterday.TotalApplications,
                    RequirementCriteria = yesterday.RequirementCriteria,
                    MODIFIED_DATE = yesterday.MODIFIED_DATE,
                    Application_Type = yesterday.Application_Type,
                    Delphi_Scorecard = yesterday.Delphi_Scorecard,
                    avg = yesterday.avg

                };

                PreviousMonthNOC.Add(delphiScorecard);
            }
        }

        #endregion

        #region Previous Month ApplicationType

        private readonly List<PreviousMonthCalculation> PreviousMonthApplicationType = new List<PreviousMonthCalculation>();
        private void calculatePreviousMonthApplicationType(List<DailyAlertingReport> lastMonthReport, DailyResultReport yesterday)
        {
            string[] keystring = new string[1] { "D029" };
            var scorecard = new HashSet<string>(keystring);
            if (scorecard.Contains(yesterday.KeyValue))
            {
                PreviousMonthCalculation delphiScorecard;
                List<DailyAlertingReport> filterByClientIdAccountNumber;
                AssignPreviousMonthCalculation(lastMonthReport, yesterday, out delphiScorecard, out filterByClientIdAccountNumber);


                //Find out Application_Types used in the previous month (Last_Month_Application_Type).                      
                var lastMonthApplicationType = filterByClientIdAccountNumber.GroupBy(s => new { s.Application_Type }).ToList();

                string applicationType = string.Join(" ", lastMonthApplicationType.Select(x => x.Key.Application_Type).ToList());

                string[] typeList = applicationType.Split(" ");
                var applicationTypes = typeList.Distinct().ToList();


                delphiScorecard.LastMonthApplicationTypes = string.Join(" ", applicationTypes.Select(x => x).ToList());

                PreviousMonthApplicationType.Add(delphiScorecard);
            }

        }



        #endregion

        #region Calculate Previous Month count  Aggregate
        private readonly List<DailyResultReport> PreviousMonthAggregatelist = new List<DailyResultReport>();

        private void CalculatePreviousMonthAggregate(DailyResultReport yesterday, List<DailyAlertingReport> lastMonthReport1)
        {
            var lastMonthAggregate = lastMonthReport1.GroupBy(s => new { s.Client_ID, s.AccountNumber, s.RequirementCriteria, s.KeyValue })
                                    .Select(g =>
                                        new
                                        {
                                            KeyValue = g.Key.KeyValue,
                                            RequirementCriteria = g.Key.RequirementCriteria,
                                            Client_ID = g.Key.Client_ID,
                                            AccountNumber = g.Key.AccountNumber,
                                            Aggregate = g.Sum(x => x.CountActiveCAIS),
                                        }
                                  ).AsEnumerable()
                                     .Select(g => new PreviousMonthAggregate
                                     {
                                         KeyValue = g.KeyValue,
                                         RequirementCriteria = g.RequirementCriteria,
                                         Client_ID = g.Client_ID,
                                         AccountNumber = g.AccountNumber,
                                         Aggregate = g.Aggregate
                                     }).ToList();
            if (lastMonthAggregate.Count > 0)
                yesterday.PreviousMonthAggregate = lastMonthAggregate[0].Aggregate;


            PreviousMonthAggregatelist.Add(yesterday);
        }
        #endregion

        #region Assign Previous Month object to Calculation object
        private static void AssignPreviousMonthCalculation(List<DailyAlertingReport> lastMonthReport, DailyResultReport yesterday, out PreviousMonthCalculation delphiScorecard, out List<DailyAlertingReport> filterByClientIdAccountNumber)
        {
            delphiScorecard = new PreviousMonthCalculation
            {
                ID = yesterday.ID,
                KeyValue = yesterday.KeyValue,
                QueryDate = yesterday.QueryDate,
                Client_ID = yesterday.Client_ID,
                AccountNumber = yesterday.AccountNumber,
                CountActiveCAIS = yesterday.CountActiveCAIS,
                TotalApplications = yesterday.TotalApplications,
                RequirementCriteria = yesterday.RequirementCriteria,
                MODIFIED_DATE = yesterday.MODIFIED_DATE,
                Application_Type = yesterday.Application_Type,
                Delphi_Scorecard = yesterday.Delphi_Scorecard,
                avg = yesterday.avg

            };
            filterByClientIdAccountNumber = lastMonthReport
                                            .Where(t => t.RequirementCriteria == yesterday.RequirementCriteria)
                                            .Where(e => e.Client_ID == yesterday.Client_ID)
                                            .Where(t => t.AccountNumber == yesterday.AccountNumber)
                                            .ToList();

        }

        #endregion

        #region Write Data into Excel Template

        private void WriteDatatoExcelTemplate()
        {
            string filepath = Directory.GetCurrentDirectory(); 
            //Delete the files in the folder
            DirectoryInfo di = new DirectoryInfo(filepath + ConstantValues.reportpath);
            foreach (FileInfo file in di.EnumerateFiles())
            {
                file.Delete();
            }
            string sourcepath = Path.Combine(filepath + ConstantValues.templatepath, ConstantValues.filename);
            string destFile = Path.Combine(filepath + ConstantValues.reportpath, ConstantValues.filename);
            File.Copy(sourcepath, destFile, true);

            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Open(destFile, isEditable: true))
                {

                    //WorksheetPart worksheetPart = GetWorksheetPartByName(spreadsheetDoc, "DATA_01");
                    //var sheetData = new SheetData();
                    //worksheetPart.Worksheet = new Worksheet(sheetData);
                    //SharedStringTablePart stringTable = worksheetPart.GetPartsOfType<SharedStringTablePart>().FirstOrDefault();

                    //Worksheet worksheet = worksheetPart.Worksheet;
                    //SheetData sheetData1 = worksheet.GetFirstChild<SheetData>();

                    //// Row row = RetrieveRow(worksheetPart.Worksheet, 1);
                    //// sheetData.Append(row);

                    //AddDatatolist(sheetData);
                    //worksheetPart.Worksheet.Save();
                    ListDataIntoExcelFromAggregatelist(spreadsheetDoc);
                    ListDataIntoExcelFromODelphiScorecard(spreadsheetDoc);
                    ListDataIntoExcelPreviousMonthAvgScore(spreadsheetDoc);
                    ListDataIntoExcelPreviousMonthNOC(spreadsheetDoc);
                    ListDataIntoExcelPreviousMonthApplicationType(spreadsheetDoc);
                }

            }
            catch (Exception exHandle)
            {
                Console.WriteLine("Exception: " + exHandle.Message);
                Console.ReadLine();
            }
            finally
            {
                foreach (Process process in Process.GetProcessesByName("Excel"))
                    process.Kill();
            }
            _logger.LogInformation("Excel services Ended");
        }

        private  void AddDatatolist(SheetData sheetData)
        {

           

            uint i = 1;
            foreach (DailyResultReport result in PreviousMonthAggregatelist)
            {
                var newRow = new Row()
                {
                    RowIndex = (uint)i + 1
                };
               
                Cell cellA = new Cell();
                cellA.DataType = CellValues.String;
                cellA.CellValue = new CellValue(result.KeyValue); //
                newRow.AppendChild(cellA);


                Cell cellB = new Cell();
                cellB.DataType = CellValues.String;
                cellB.CellValue = new CellValue(result.QueryDate.ToString("MM/dd/yyyy")); //
                newRow.AppendChild(cellB);

                Cell cellC = new Cell();
                cellC.DataType = CellValues.Date;
                cellC.CellValue = new CellValue(result.QueryDate.ToString()); //

                Cell cellClientID = new Cell();
                cellClientID.DataType = CellValues.String;
                cellClientID.CellValue = new CellValue(result.Client_ID); //
                newRow.AppendChild(cellClientID);

                Cell cellAccountNumber = new Cell();
                cellAccountNumber.DataType = CellValues.String;
                cellAccountNumber.CellValue = new CellValue(result.AccountNumber); //
                newRow.AppendChild(cellAccountNumber);

                Cell cellCount = new Cell();
                cellCount.DataType = CellValues.Number;
                cellCount.CellValue = new CellValue(result.CountActiveCAIS.ToString()); //
                newRow.AppendChild(cellCount);

                Cell cellTotalApplications = new Cell();
                cellTotalApplications.DataType = CellValues.Number;
                cellTotalApplications.CellValue = new CellValue(result.TotalApplications.ToString()); //
                newRow.AppendChild(cellTotalApplications);

                Cell cellPreviousAggregate = new Cell();
                cellPreviousAggregate.DataType = CellValues.Number;
                cellPreviousAggregate.CellValue = new CellValue(result.PreviousMonthAggregate.ToString()); //
                newRow.AppendChild(cellPreviousAggregate);
                
                sheetData.Append(newRow);
                i++;
                
            }
        }

        public  Row RetrieveRow(Worksheet worksheet, uint rowIndex)
        {
            return worksheet.GetFirstChild<SheetData>().
            Elements<Row>().Where(r => r.RowIndex == rowIndex).First();
        }

        private void RunMacro(object oApp, object[] oRunArgs)
        {
            oApp.GetType().InvokeMember("Run", System.Reflection.BindingFlags.Default | System.Reflection.BindingFlags.InvokeMethod, null, oApp, oRunArgs);
        }

        private void ListDataIntoExcelFromAggregatelist(SpreadsheetDocument spreadsheetDoc)
        {
            uint i =1;
            foreach (DailyResultReport result in PreviousMonthAggregatelist)
            {
                if (result.KeyValue != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "A", result.KeyValue.ToString(), CellValues.String);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "B", result.QueryDate.ToString("MM/dd/yyyy"), CellValues.Date);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "C", result.QueryDate.ToString(), CellValues.Date);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "D", result.Client_ID, CellValues.String);
                if (result.AccountNumber != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "E", result.AccountNumber,CellValues.String);
                if (result.CountActiveCAIS != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "F", result.CountActiveCAIS.ToString(), CellValues.Number);
                if (result.CountActiveCAIS != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "G", result.CountActiveCAIS.ToString(), CellValues.Number);
                if (result.PreviousMonthAggregate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "H", result.PreviousMonthAggregate.ToString(), CellValues.Number);
                if (result.PreviousMonthAggregate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "I", result.PreviousMonthAggregate.ToString(), CellValues.Number);

                i++;
            }


        }
        private void ListDataIntoExcelFromODelphiScorecard(SpreadsheetDocument spreadsheetDoc)
        {

            uint i;
            i = 1;
            foreach (PreviousMonthCalculation result in PreviousMonthDelphiScorecard)
            {

                if (result.KeyValue != null) 
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "L", result.KeyValue.ToString(), CellValues.String);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "M", result.QueryDate.ToString("MM/dd/yyyy"), CellValues.Date);
                if (result.QueryDate != null) 
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "N", result.QueryDate.ToString(), CellValues.Date);
                if (result.Client_ID != null) 
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "O", result.Client_ID.ToString(), CellValues.String);
                if (result.AccountNumber != null) 
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "P", result.AccountNumber.ToString(), CellValues.String);
                if (result.Delphi_Scorecard != null) 
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "Q", result.Delphi_Scorecard.ToString(), CellValues.String);
                if (result.LastMonthDelphiScorecards != null) 
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "R", result.LastMonthDelphiScorecards.ToString(), CellValues.String);

                i++;
            }

        }
        private void ListDataIntoExcelPreviousMonthAvgScore(SpreadsheetDocument spreadsheetDoc)
        {

            uint i = 1;
            foreach (PreviousMonthCalculation result in PreviousMonthAvgScore)
            {

                //21 to 30
                if (result.KeyValue != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "U", result.KeyValue.ToString(), CellValues.String);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "V", result.QueryDate.ToString("MM/dd/yyyy").ToString(), CellValues.Date);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "W", result.QueryDate.ToString(), CellValues.Date);
                if (result.Delphi_Scorecard != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "X", result.Delphi_Scorecard.ToString(), CellValues.String);
                if (result.Client_ID != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "Y", result.Client_ID.ToString(), CellValues.String);
                if (result.AccountNumber != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "Z", result.AccountNumber.ToString(), CellValues.String);
                if (result.avg != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AA", result.avg.ToString(), CellValues.Number);
                if (result.TotalApplications != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AB", result.TotalApplications.ToString(), CellValues.Number);
                if (result.LastMonthAvg != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AC", result.LastMonthAvg.ToString(), CellValues.Number);
                if (result.LastMonthApplicationCount != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AD", result.LastMonthApplicationCount.ToString(), CellValues.Number);
                i++;
            }

        }
        private void ListDataIntoExcelPreviousMonthNOC(SpreadsheetDocument spreadsheetDoc)
        {

            uint i;

            i = 1;
            foreach (PreviousMonthCalculation result in PreviousMonthNOC)
            {

                //33 to 40
                if (result.KeyValue != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AG", result.KeyValue.ToString(), CellValues.String);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AH", result.QueryDate.ToString("MM/dd/yyyy").ToString(),CellValues.Date);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AI", result.QueryDate.ToString(), CellValues.Date);
                if (result.Client_ID != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AJ", result.Client_ID.ToString(), CellValues.String);
                if (result.AccountNumber != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AK", result.AccountNumber.ToString(), CellValues.String);
                if (result.CountActiveCAIS != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AM", result.CountActiveCAIS.ToString(),CellValues.Number);
                if (result.TotalApplications != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AN", result.TotalApplications.ToString(), CellValues.Number);
                i++;
            }

        }

        private void ListDataIntoExcelPreviousMonthApplicationType(SpreadsheetDocument spreadsheetDoc)
        {

            uint i;

            i = 1;
            foreach (PreviousMonthCalculation result in PreviousMonthApplicationType)
            {

                //43 to 49 Key	Month  Day
                //
                if (result.KeyValue != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AQ", result.KeyValue.ToString(), CellValues.String);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AR", result.QueryDate.ToString("MM/dd/yyyy").ToString(), CellValues.Date);
                if (result.QueryDate != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AS", result.QueryDate.ToString(),CellValues.Date);
                if (result.Client_ID != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AT", result.Client_ID.ToString(), CellValues.String);
                if (result.AccountNumber != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AU", result.AccountNumber.ToString(), CellValues.String);
                if (result.Application_Type != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AV", result.Application_Type.ToString(), CellValues.String);
                if (result.LastMonthApplicationTypes != null)
                    _excelUtilities.AddUpdateCellValue(spreadsheetDoc, "DATA_01", i, "AW", result.LastMonthApplicationTypes.ToString(), CellValues.String);

                i++;
            }
        }
        #endregion
        #endregion

        #region Open XML SDK 2.0
        private static WorksheetPart GetWorksheetPartByName(SpreadsheetDocument document, string sheetName)
        {
            IEnumerable<Sheet> sheets =
           document.WorkbookPart.Workbook.GetFirstChild<Sheets>().
          Elements<Sheet>().Where(s => s.Name == sheetName);
            if (sheets.Count() == 0)
                return null;

            string relationshipId = sheets.First().Id.Value;
            WorksheetPart worksheetPart = (WorksheetPart)
            document.WorkbookPart.GetPartById(relationshipId);
            return worksheetPart;
        }
        #endregion 


    }
}
