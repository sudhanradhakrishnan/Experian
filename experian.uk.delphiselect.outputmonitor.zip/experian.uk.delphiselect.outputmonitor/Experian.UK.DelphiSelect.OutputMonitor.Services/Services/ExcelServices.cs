﻿using Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Model;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Utility;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using Range = Microsoft.Office.Interop.Excel.Range;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Services
{
    public class ExcelServices: IExcelServices
    {

        private readonly ILogger<ExcelServices> _logger;
        private List<SearchResultResponse> lstobject;
        private readonly IServiceProvider _services;
        private DelphiSelectOutputMonitorConfig Config { get; }
        private IDailyAlertingReportContext dailyAlertReportContext { get; }

      
        private readonly string templatepath = @"\Template\";
        private readonly string reportpath = @"\OutPut\Report\";
        private readonly string filename = "DailyTemplateMacro.xlsm";

        private string[] SearchCriteriaKey = new string[32] {"D001","D002","D003","D004","D005","D006","D007","D019","D020","D021","D022","D023",  "D025","D026A","D026B","D026C","D026D","D026E","D026F","D026G","D026H","D026I","D026J","D026K","D026L","D026M","D026N","D026O","D026P","D026Q","D026R","D026S" };
        private string[] DelphiScorecard = new string[9] {"D008","D009A", "D010", "D013","D016", "D029", "D030A", "D028", "D024"};
        public ExcelServices(ILogger<ExcelServices> logger, IServiceProvider services, IOptions<DelphiSelectOutputMonitorConfig> config, IDailyAlertingReportContext dailyAlertingReportContext)
        {
            _logger = logger;
            _services = services;
            Config = config.Value;
            dailyAlertReportContext = dailyAlertingReportContext;
        }
        public void RunDailyExcelReportServices()
        {
            Console.WriteLine("ExcelServices Started ");

            Run();

            using (var scope = _services.CreateScope())
            {
                var emailService = scope.ServiceProvider.GetRequiredService<IEmailService>();
                emailService.Run();
            }

            Console.Write("Excel services Completed: ");
        }

        public void RunMonthlyExcelReportServices()
        {
            Console.WriteLine("ExcelServices Started ");

            Run();

            //using (var scope = _services.CreateScope())
            //{
            //    var emailService = scope.ServiceProvider.GetRequiredService<IEmailService>();
            //    emailService.Run();
            //}

            Console.Write("Excel services Completed: ");
        }

        private void Run()
        {
            _logger.LogInformation("Excel services Started");

            List<DailyResultReport> yesterdayRecords = dailyAlertReportContext.GetYesterdayReport();

            List<DailyAlertingReport> lastMonthRecords = dailyAlertReportContext.GetLastMonthReport();

            if (yesterdayRecords.Count() > 0)
            {
                CalculateAggregateDelphiScorecardAvgScoreApplicationType(yesterdayRecords, lastMonthRecords);
            }

            WriteDatatoExcelTemplate();
        }

        #region Daily reoprt
        private void CalculateAggregateDelphiScorecardAvgScoreApplicationType(List<DailyResultReport> yesterdayRecords, List<DailyAlertingReport> lastMonthReport)
        {
            foreach (DailyResultReport yesterdayRecord in yesterdayRecords)
            {
                var lastMonthRecords = lastMonthReport
                           .Where(t => t.RequirementCriteria == yesterdayRecord.RequirementCriteria)
                           .Where(e => e.Client_ID == yesterdayRecord.Client_ID)
                           .Where(t => t.AccountNumber == yesterdayRecord.AccountNumber)
                           .ToList();
                if (lastMonthRecords != null)
                {
                    var searchKey = new HashSet<string>(SearchCriteriaKey);//DelphiScorecard
                    var scorecard = new HashSet<string>(DelphiScorecard);//
                    if (searchKey.Contains(yesterdayRecord.KeyValue))
                    {

                        CalculatePreviousMonthAggregate(yesterdayRecord, lastMonthRecords);
                    }
                    else if (scorecard.Contains(yesterdayRecord.KeyValue))
                    {
                        calculatePreviousMonthDelphiScorecard(lastMonthReport, yesterdayRecord);
                        calculatePreviousMonthAvgScore(lastMonthReport, yesterdayRecord);
                        calculatePreviousMonthNOC(yesterdayRecord);
                        calculatePreviousMonthApplicationType(lastMonthReport, yesterdayRecord);
                    }

                }


            }
        }

        #region Delphi Score Card
        private readonly List<PreviousMonthCalculation> PreviousMonthDelphiScorecard = new List<PreviousMonthCalculation>();
        private void calculatePreviousMonthDelphiScorecard(List<DailyAlertingReport> lastMonthReport, DailyResultReport yesterday)
        {
            string[] D008D009A = new string[1] { "D008" };
            var scorecard = new HashSet<string>(D008D009A);
            if (scorecard.Contains(yesterday.KeyValue))
            {
                PreviousMonthCalculation delphiScorecard;
                List<DailyAlertingReport> filterByClientIdAccountNumber;
                AssignPreviousMonthCalculation(lastMonthReport, yesterday, out delphiScorecard, out filterByClientIdAccountNumber);
                var lastMonthAggregate = filterByClientIdAccountNumber.GroupBy(s => new { s.Delphi_Scorecard }).ToList();

                string scorecardjoin = string.Join(" ", lastMonthAggregate.Select(x => x.Key.Delphi_Scorecard).ToList());

                string[] scorecardList = scorecardjoin.Split(" ");
                var scorecards = scorecardList.Distinct().ToList();


                delphiScorecard.LastMonthDelphiScorecards = string.Join(" ", scorecards.Select(x => x).ToList());

                PreviousMonthDelphiScorecard.Add(delphiScorecard);
            }



        }

        #endregion

        #region Previous Month Avg_Score

        private readonly List<PreviousMonthCalculation> PreviousMonthAvgScore = new List<PreviousMonthCalculation>();
        private void calculatePreviousMonthAvgScore(List<DailyAlertingReport> lastMonthReport, DailyResultReport yesterday)
        {
            string[] keystring = new string[6] { "D009A", "D010", "D013", "D016", "D028", "D030A" };
            var AvgScore = new HashSet<string>(keystring);
            if (AvgScore.Contains(yesterday.KeyValue))
            {

                PreviousMonthCalculation previousMonthAvgScore;
                List<DailyAlertingReport> filterByClientIdAccountNumber;
                AssignPreviousMonthCalculation(lastMonthReport, yesterday, out previousMonthAvgScore, out filterByClientIdAccountNumber);
                //We have current month avg. Find out Last_Month_avg.   
                //Change= Current_Month_avg-Last_Month_avg
                //Change_Percentage=(Change/Last_Month_avg)x100 
                var Last_Month_avg = filterByClientIdAccountNumber.GroupBy(s => new { s.Client_ID, s.AccountNumber, s.RequirementCriteria, s.KeyValue })
                                                    .Select(g =>
                                                        new
                                                        {
                                                            KeyValue = g.Key.KeyValue,
                                                            RequirementCriteria = g.Key.RequirementCriteria,
                                                            Client_ID = g.Key.Client_ID,
                                                            AccountNumber = g.Key.AccountNumber,
                                                            Lastmonthcount = ((g.Sum(x => x.CountActiveCAIS))),
                                                            LastMonthApplications = ((g.Sum(x => x.TotalApplications))),
                                                            TotalAvg = ((g.Sum(x => x.avg) / filterByClientIdAccountNumber.Count))
                                                        }
                                                  ).ToList();
                if (Last_Month_avg.Count > 0)
                {
                    previousMonthAvgScore.LastMonthAvg = Last_Month_avg[0].TotalAvg;
                    previousMonthAvgScore.LastMonthCount = Last_Month_avg[0].Lastmonthcount;
                    previousMonthAvgScore.LastMonthApplicationCount = Last_Month_avg[0].LastMonthApplications;
                }

                PreviousMonthAvgScore.Add(previousMonthAvgScore);
            }
        }

        #endregion

        #region Previous Month Notice of Correction

        private readonly List<PreviousMonthCalculation> PreviousMonthNOC = new List<PreviousMonthCalculation>();
        private void calculatePreviousMonthNOC(DailyResultReport yesterday)
        {
            string[] keystring = new string[1] { "D024" };
            var Noc = new HashSet<string>(keystring);
            if (Noc.Contains(yesterday.KeyValue))
            {
                PreviousMonthCalculation delphiScorecard = new PreviousMonthCalculation
                {
                    ID = yesterday.ID,
                    KeyValue = yesterday.KeyValue,
                    QueryDate = yesterday.QueryDate,
                    Client_ID = yesterday.Client_ID,
                    AccountNumber = yesterday.AccountNumber,
                    CountActiveCAIS = yesterday.CountActiveCAIS,
                    TotalApplications = yesterday.TotalApplications,
                    RequirementCriteria = yesterday.RequirementCriteria,
                    MODIFIED_DATE = yesterday.MODIFIED_DATE,
                    Application_Type = yesterday.Application_Type,
                    Delphi_Scorecard = yesterday.Delphi_Scorecard,
                    avg = yesterday.avg

                };

                PreviousMonthNOC.Add(delphiScorecard);
            }
        }

        #endregion

        #region Previous Month ApplicationType

        private readonly List<PreviousMonthCalculation> PreviousMonthApplicationType = new List<PreviousMonthCalculation>();
        private void calculatePreviousMonthApplicationType(List<DailyAlertingReport> lastMonthReport, DailyResultReport yesterday)
        {
            string[] keystring = new string[1] { "D029" };
            var scorecard = new HashSet<string>(keystring);
            if (scorecard.Contains(yesterday.KeyValue))
            {
                PreviousMonthCalculation delphiScorecard;
                List<DailyAlertingReport> filterByClientIdAccountNumber;
                AssignPreviousMonthCalculation(lastMonthReport, yesterday, out delphiScorecard, out filterByClientIdAccountNumber);


                //Find out Application_Types used in the previous month (Last_Month_Application_Type).                      
                var lastMonthApplicationType = filterByClientIdAccountNumber.GroupBy(s => new { s.Application_Type }).ToList();

                string applicationType = string.Join(" ", lastMonthApplicationType.Select(x => x.Key.Application_Type).ToList());

                string[] typeList = applicationType.Split(" ");
                var applicationTypes = typeList.Distinct().ToList();


                delphiScorecard.LastMonthApplicationTypes = string.Join(" ", applicationTypes.Select(x => x).ToList());

                PreviousMonthApplicationType.Add(delphiScorecard);
            }

        }



        #endregion

        #region Calculate Previous Month count  Aggregate
        private readonly List<DailyResultReport> PreviousMonthAggregatelist = new List<DailyResultReport>();

        private void CalculatePreviousMonthAggregate(DailyResultReport yesterday, List<DailyAlertingReport> lastMonthReport1)
        {
            var lastMonthAggregate = lastMonthReport1.GroupBy(s => new { s.Client_ID, s.AccountNumber, s.RequirementCriteria, s.KeyValue })
                                    .Select(g =>
                                        new
                                        {
                                            KeyValue = g.Key.KeyValue,
                                            RequirementCriteria = g.Key.RequirementCriteria,
                                            Client_ID = g.Key.Client_ID,
                                            AccountNumber = g.Key.AccountNumber,
                                            Aggregate = g.Sum(x => x.CountActiveCAIS),
                                        }
                                  ).AsEnumerable()
                                     .Select(g => new PreviousMonthAggregate
                                     {
                                         KeyValue = g.KeyValue,
                                         RequirementCriteria = g.RequirementCriteria,
                                         Client_ID = g.Client_ID,
                                         AccountNumber = g.AccountNumber,
                                         Aggregate = g.Aggregate
                                     }).ToList();
            if (lastMonthAggregate.Count > 0)
                yesterday.PreviousMonthAggregate = lastMonthAggregate[0].Aggregate;


            PreviousMonthAggregatelist.Add(yesterday);
        }
        #endregion

        #region Assign Previous Month object to Calculation object
        private static void AssignPreviousMonthCalculation(List<DailyAlertingReport> lastMonthReport, DailyResultReport yesterday, out PreviousMonthCalculation delphiScorecard, out List<DailyAlertingReport> filterByClientIdAccountNumber)
        {
            delphiScorecard = new PreviousMonthCalculation
            {
                ID = yesterday.ID,
                KeyValue = yesterday.KeyValue,
                QueryDate = yesterday.QueryDate,
                Client_ID = yesterday.Client_ID,
                AccountNumber = yesterday.AccountNumber,
                CountActiveCAIS = yesterday.CountActiveCAIS,
                TotalApplications = yesterday.TotalApplications,
                RequirementCriteria = yesterday.RequirementCriteria,
                MODIFIED_DATE = yesterday.MODIFIED_DATE,
                Application_Type = yesterday.Application_Type,
                Delphi_Scorecard = yesterday.Delphi_Scorecard,
                avg = yesterday.avg

            };
            filterByClientIdAccountNumber = lastMonthReport
                                            .Where(t => t.RequirementCriteria == yesterday.RequirementCriteria)
                                            .Where(e => e.Client_ID == yesterday.Client_ID)
                                            .Where(t => t.AccountNumber == yesterday.AccountNumber)
                                            .ToList();

        }

        #endregion

        #region Write Data into Excel Template

        private void WriteDatatoExcelTemplate()
        {
            string filepath = Directory.GetCurrentDirectory();
            var sourcepath = filepath + templatepath + filename;
            var path = filepath + reportpath + filename;
            System.IO.DirectoryInfo di = new DirectoryInfo(filepath + reportpath);
            foreach (FileInfo file in di.EnumerateFiles())
            {
                file.Delete();
            }

            Application ExcelApp = new Application();
            Workbook ExcelWorkBook = ExcelApp.Workbooks.Open(Filename: sourcepath, Editable: true); ;
            Worksheet ExcelWorkSheet = (Worksheet)ExcelWorkBook.Sheets["DATA_01"];

            // ExcelWorkBook = ExcelApp.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);
            try
            {

                // ExcelWorkSheet = AddRowHeaderToExcel(ExcelWorkBook);
                ExcelApp.Visible = false;
                ExcelApp.DisplayAlerts = false;
                Console.WriteLine("Started writed data to excel");
                ListDataIntoExcelFromAggregatelist(ExcelWorkSheet);
                ListDataIntoExcelFromODelphiScorecard(ExcelWorkSheet);
                Console.WriteLine("Completed  writing data to excel");
                for (var row = 1; row <= ExcelWorkBook.Connections.Count; row++)
                {
                    ExcelWorkBook.Connections[row].Refresh();
                    System.Threading.Thread.Sleep(TimeSpan.FromSeconds(15));
                }
                Console.WriteLine("Completed  Refresh excel");

                // ExcelWorkBook.SaveCopyAs(path); - very slow
                // ExcelApp.Application.CalculateUntilAsyncQueriesDone(); // Very slow
                //  System.Threading.Thread.Sleep(TimeSpan.FromMinutes(10));
                // RunMacro(ExcelWorkBook, new Object[] { "Daily Reporting Template V2.0.xlsm!Module1.RefreshQuery" });
                ExcelWorkBook.SaveCopyAs(path);
                Console.WriteLine("Save copy as");
                ExcelWorkBook.Close();
                ExcelApp.Quit();
                Console.WriteLine("ExcelApp.Quit");

            }
            catch (Exception exHandle)
            {
                Console.WriteLine("Exception: " + exHandle.Message);
                Console.ReadLine();
            }
            finally
            {
                Marshal.ReleaseComObject(ExcelWorkSheet);
                Marshal.ReleaseComObject(ExcelWorkBook);
                Marshal.ReleaseComObject(ExcelApp);
                foreach (Process process in Process.GetProcessesByName("Excel"))
                    process.Kill();
            }
            _logger.LogInformation("Excel services Ended");
        }



        private void RunMacro(object oApp, object[] oRunArgs)
        {
            oApp.GetType().InvokeMember("Run", System.Reflection.BindingFlags.Default | System.Reflection.BindingFlags.InvokeMethod, null, oApp, oRunArgs);
        }

        private void ListDataIntoExcelFromAggregatelist(Worksheet ExcelWorkSheet)
        {
            int i = 2;
            foreach (DailyResultReport result in PreviousMonthAggregatelist)
            {
                ExcelWorkSheet.Cells[i, 1] = result.KeyValue;//key A
                ExcelWorkSheet.Cells[i, 2] = result.QueryDate.ToString("MM/dd/yyyy");//Month B							
                ExcelWorkSheet.Cells[i, 3] = result.QueryDate;//Day C
                ExcelWorkSheet.Cells[i, 4] = result.Client_ID;//Client_ID D
                ExcelWorkSheet.Cells[i, 5] = result.AccountNumber;//Account_Number E
                                                                  // ExcelWorkSheet.Cells[i, 6] = result.CountActiveCAIS;//Zero_Count F
                ExcelWorkSheet.Cells[i, 7] = result.CountActiveCAIS;//Non_Zero_Count G
                ExcelWorkSheet.Cells[i, 8] = result.TotalApplications;//Total_Applications H
                ExcelWorkSheet.Cells[i, 9] = result.PreviousMonthAggregate;//Last_Month_Count I
                i++;
            }
        }

        private void ListDataIntoExcelFromODelphiScorecard(Worksheet ExcelWorkSheet)
        {
            int i = 2;
            foreach (PreviousMonthCalculation result in PreviousMonthDelphiScorecard)
            {
                ExcelWorkSheet.Cells[i, 12] = result.KeyValue;//key
                ExcelWorkSheet.Cells[i, 13] = result.QueryDate.ToString("MM/dd/yyyy");//Month						
                ExcelWorkSheet.Cells[i, 14] = result.QueryDate;//Day
                ExcelWorkSheet.Cells[i, 15] = result.Client_ID;//Client_ID
                ExcelWorkSheet.Cells[i, 16] = result.AccountNumber;//Account_Number
                ExcelWorkSheet.Cells[i, 17] = result.Delphi_Scorecard;//Key_Value
                ExcelWorkSheet.Cells[i, 18] = result.LastMonthDelphiScorecards;//Last_Month_Key_Value  
                i++;
            }
            i = 2;
            foreach (PreviousMonthCalculation result in PreviousMonthAvgScore)
            {

                //21 to 30
                //Key	Month	Day		Client_ID	Account_Number				
                ExcelWorkSheet.Cells[i, 21] = result.KeyValue;//key
                ExcelWorkSheet.Cells[i, 22] = result.QueryDate.ToString("MM/dd/yyyy");//Month						
                ExcelWorkSheet.Cells[i, 23] = result.QueryDate;//Day
                ExcelWorkSheet.Cells[i, 24] = result.Delphi_Scorecard;//Filter_2 
                ExcelWorkSheet.Cells[i, 25] = result.Client_ID;//Client_ID 
                ExcelWorkSheet.Cells[i, 26] = result.AccountNumber;//Account_Number 
                ExcelWorkSheet.Cells[i, 27] = result.avg;//Avg_Score
                ExcelWorkSheet.Cells[i, 28] = result.TotalApplications;//Total_Applications
                ExcelWorkSheet.Cells[i, 29] = result.LastMonthAvg;//Last_Month_Score 
                ExcelWorkSheet.Cells[i, 30] = result.LastMonthApplicationCount;//Last_Month_Total
                i++;
            }
            i = 2;
            foreach (PreviousMonthCalculation result in PreviousMonthNOC)
            {
                //33 to 40
                //Key	Month	Day			Zero_NOC - not used		
                ExcelWorkSheet.Cells[i, 33] = result.KeyValue;//key 
                ExcelWorkSheet.Cells[i, 34] = result.QueryDate.ToString("MM/dd/yyyy");//Month 						
                ExcelWorkSheet.Cells[i, 35] = result.QueryDate;//Day 
                ExcelWorkSheet.Cells[i, 36] = result.Client_ID;//Client_ID
                ExcelWorkSheet.Cells[i, 37] = result.AccountNumber;//Account_Number
                ExcelWorkSheet.Cells[i, 39] = result.CountActiveCAIS;//Non_Zero_NOC
                ExcelWorkSheet.Cells[i, 40] = result.TotalApplications;//Total_Applications
                i++;
            }
            i = 2;
            foreach (PreviousMonthCalculation result in PreviousMonthApplicationType)
            {
                //43 to 49 Key	Month  Day    
                ExcelWorkSheet.Cells[i, 43] = result.KeyValue;//key 
                ExcelWorkSheet.Cells[i, 44] = result.QueryDate.ToString("MM/dd/yyyy");//Month 							
                ExcelWorkSheet.Cells[i, 45] = result.QueryDate;//Day 
                ExcelWorkSheet.Cells[i, 46] = result.Client_ID;//Client_ID 
                ExcelWorkSheet.Cells[i, 47] = result.AccountNumber;//Account_Number 
                ExcelWorkSheet.Cells[i, 48] = result.Application_Type;//Application_Type
                ExcelWorkSheet.Cells[i, 49] = result.LastMonthApplicationTypes;//Last_Month_App_Type
                i++;
            }
        }
        #endregion
        #endregion


    }
}
