﻿using Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Model;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Utility;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Splunk.Client;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Services
{
    public class SplunkSDKService : ISplunkSDKService
    {
        private string QueryStatus=string.Empty;

        private DelphiSelectOutputMonitorConfig Config { get; }
        private readonly ILogger<SplunkSDKService> _logger;
        private IHostApplicationLifetime HostApplicationLifetime { get; }

        private IDailyAlertingReportContext dailyAlertReportContext { get; }

        private IMonthlyReportContext _monthlyReportContext  { get; }
        private ISearchCriteriaContext _searchCriteria { get; }
        // searchCriteria

        private List<SearchResultResponse> lstobject ;
        private readonly IServiceProvider _services;
        private string filepath = string.Empty;
        private string searchEarliestTime = string.Empty;
        private string searchLatestTime = string.Empty;

        public bool IsMonthlyReport = false;

        public SplunkSDKService(ILogger<SplunkSDKService> logger, IServiceProvider services, IHostApplicationLifetime hostApplicationLifetime, IOptions<DelphiSelectOutputMonitorConfig> config, IDailyAlertingReportContext dailyAlertingReportContext, IMonthlyReportContext monthlyReportContext, ISearchCriteriaContext searchCriteria)
        {
            _logger = logger;
            _services = services;
            Config = config.Value;
            HostApplicationLifetime = hostApplicationLifetime;
            lstobject = new List<SearchResultResponse>();
            dailyAlertReportContext = dailyAlertingReportContext;
            _monthlyReportContext = monthlyReportContext;
            _searchCriteria = searchCriteria;
            IsMonthlyReport = CommonUtility.CheckCurrentMonthFirstDay();

        }

        public void DelphiSelectMonthlyReport()
        {
            if (IsMonthlyReport)
                DelphiSelectDailyReport();
        }
        public void DelphiSelectDailyReport()
        {
            //TODO Need to remove for testing.
            using (var scope = _services.CreateScope())
            {
                var excelServices = scope.ServiceProvider.GetRequiredService<IExcelServices>();
                excelServices.RunDailyExcelReportServices();
                if (IsMonthlyReport)
                    excelServices.RunMonthlyExcelReportServices();
            }

            var dailysearchlist = new List<SearchCriteria>();
           
            try
            {

                string dayOrMonth = "DAY";
                if (IsMonthlyReport)
                    dayOrMonth = "MONTH";

                dailysearchlist =  _searchCriteria.SearchCriteria(dayOrMonth);            
                
               
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

           

            foreach (SearchCriteria criteria in dailysearchlist)
            {
                if (criteria.Query.Length > 0)
                {
                  Run(criteria).Wait();
                }
            }




            // do some work

            using (var scope = _services.CreateScope())
            {
                var excelServices = scope.ServiceProvider.GetRequiredService<IExcelServices>();
                excelServices.RunDailyExcelReportServices();
                if (IsMonthlyReport)
                    excelServices.RunMonthlyExcelReportServices();
            }

            Console.WriteLine("Delphi Select Daily Report complected!!!!");
        }

       

        private async Task Run(SearchCriteria requirementCriteria)
        {
            try
            {
                var context = new Context(Config.Scheme, Config.Url, Config.Port, TimeSpan.FromSeconds(Config.TimeoutSeconds), new HttpClientHandler()
                {
                    ClientCertificateOptions = ClientCertificateOption.Manual,
                    ServerCertificateCustomValidationCallback = (httpRequestMessage, cert, cetChain, policyErrors) => { return true; }
                });
                using var service = new Service(context);
                await service.LogOnAsync(Config.User, Config.Password);
                Console.WriteLine("Query Splunk Started :{0} ,{1}", requirementCriteria.SheetName, requirementCriteria.Key);
                SearchResultStream resultStream = await RunDailyQuery(requirementCriteria, service);
                service.LogOffAsync();
            }
            catch (AuthenticationFailureException)
            {
                Console.WriteLine("Can't get service configuration without logging in.");
            }
            Console.WriteLine("Query Splunk Completed :{0}", requirementCriteria.SheetName);
        }


        private async Task<SearchResultStream> RunDailyQuery(SearchCriteria requirementCriteria, Service service)
        {
            if (!IsMonthlyReport)
            {

                searchEarliestTime = CommonUtility.SetDateTime(-1);
                searchLatestTime = CommonUtility.SetDateTime(0);
            }
            else
            {
                DateTime start = DateTime.UtcNow;
                DateTime end = DateTime.UtcNow;
                if (IsMonthlyReport && !Config.IsMonthlyDataRequired)
                {
                    start = start.PreviousMonthFirstDay();
                    end = end.PreviousMonthLastDay();
                }
                else
                {
                    start = Config.EarliestStartDate;
                    end = Config.LatestEndDate;
                }
                
                this.searchEarliestTime = start.ToString("yyyy-MM-dd") + "T00:00:00.000-00:00";
                this.searchLatestTime = end.ToString("yyyy-MM-dd") + "T23:59:00.000-00:00";
            }

            string searchQuery = "search " + requirementCriteria.Query;
            SearchResultStream resultStream = await service.SearchOneShotAsync(searchQuery, 0, new JobArgs
            {
                SearchMode = SearchMode.Normal,
                EarliestTime = searchEarliestTime,
                LatestTime = searchLatestTime,
            });

            if (!IsMonthlyReport)
                SearchResultForDailyAlert(resultStream, requirementCriteria.SheetName);
            else
                SearchMonthlyReport(resultStream, requirementCriteria.SheetName);
            return resultStream;
        }

        private void SearchResultForDailyAlert(SearchResultStream resultStream, string requirementCriteria)
        {
            List<DailyAlertingReport> searchResponse = new List<DailyAlertingReport>();

            try
            {
               
                DateTime CheckYesterday = DateTime.UtcNow.AddDays(-1);
                DateTime querydate = DateTime.UtcNow;

                foreach (SearchResult result in resultStream)
                {
                    if (result.GetValue("Day") != null)
                    {
                        querydate = CommonUtility.ConvertStringtoDate(result.GetValue("Day"));
                        if (querydate.Date == CheckYesterday.Date)
                        {
                            DailyAlertingReport searchResultModel = CommonUtility.ExtractDailyReportFromSplunk(requirementCriteria, result);
                            searchResponse.Add(searchResultModel);
                        }
                    }
                }
                dailyAlertReportContext.AddDailyAlertingReport(searchResponse);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Query Splunk Completed :{0}", ex.Message);
            }
        }

        private void SearchMonthlyReport(SearchResultStream resultStream, string requirementCriteria)
        {
            List<DailyAlertingReport> searchResponse = new List<DailyAlertingReport>();

            try
            {

                foreach (SearchResult result in resultStream)
                {
                    DailyAlertingReport searchResultModel = CommonUtility.ExtractDailyReportFromSplunk(requirementCriteria, result);
                    searchResponse.Add(searchResultModel);
                }

                if (IsMonthlyReport && Config.IsMonthlyDataRequired)
                {
                    dailyAlertReportContext.AddDailyAlertingReport(searchResponse);
                }
                else
                {
                    List<MonthlyReport> monthlylist = new List<MonthlyReport>();
                    foreach (DailyAlertingReport result in searchResponse)
                    {
                        MonthlyReport monthlyresult = new MonthlyReport
                        {
                            KeyValue = result.KeyValue,
                            QueryMonth = result.QueryDate,
                            QueryDate = result.QueryDate,
                            Client_ID = result.Client_ID,
                            AccountNumber = result.AccountNumber,
                            CountActiveCAIS = result.CountActiveCAIS,
                            TotalApplications = result.TotalApplications,
                            RequirementCriteria = result.RequirementCriteria,
                            MODIFIED_DATE = result.MODIFIED_DATE,
                            Application_Type = result.Application_Type,
                            Delphi_Scorecard = result.Delphi_Scorecard,
                            avg = result.avg
                        };
                        monthlylist.Add(monthlyresult);
                    }

                    _monthlyReportContext.AddMonthlyReport(monthlylist);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Query Splunk Completed :{0}", ex.Message);
            }
        }


    }
}
