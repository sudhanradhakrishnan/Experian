﻿using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Services
{
    public class EmailService : IEmailService
    {
        private readonly ILogger<EmailService> _logger;
        private readonly IServiceProvider _services;
        private EmailSettingsConfig Config { get; }

        private readonly string reportpath = @"\OutPut\Report\";
        private readonly string filename = "DailyTemplateMacro.xlsm";
        public EmailService(ILogger<EmailService> logger, IOptions<EmailSettingsConfig> config)
        {
            _logger = logger;
            Config = config.Value;
        }



        public void Run()
        {
            Console.WriteLine("Email services Started");
            _logger.LogInformation("In Email Service");
            SendEmail("sudhan.radhakrishnan0@experian.com", "sudhan.radhakrishnan0@experian.com", "Hello Email from Delphi Select :::-  please open the excel and refresh the workbook to view the Result in report");
            //SendEmail("sudhan.radhakrishnan0@experian.com", "Abhilash.Nair@experian.com,Padmakrishnan.Padmanabhadas@experian.com,Prasanth.Chithran@experian.com,Binu.Binto@experian.com,Aswathy.Vijay@experian.com", "Hello Email from Delphi Select");
            Console.WriteLine("Email services Completed");
        }

        #region Send Email Code Function  
        /// <summary>  
        /// Send Email with cc bcc with given subject and message.  
        /// </summary>  
        /// <param name="ToEmail"></param>  
        /// <param name="cc"></param>  
        /// <param name="Subj"></param>  
        /// <param name="Message"></param>  
        private void SendEmail(String ToEmail, string cc, string Message)
        {
           
            string FromEmailid = Config.FromMailAddress;
            string Pass = Config.Password;
            int Port = Config.Port;

            //creating the object of MailMessage  
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(FromEmailid); 
            mailMessage.Subject = Config.Subject;   
            mailMessage.Body = Message;   
            mailMessage.IsBodyHtml = Config.IsBodyHtml;

            string[] ToMuliId = ToEmail.Split(',');
            foreach (string ToEMailId in ToMuliId)
            {
                mailMessage.To.Add(new MailAddress(ToEMailId));  
            }


            string[] CCId = cc.Split(',');

            foreach (string CCEmail in CCId)
            {
                mailMessage.CC.Add(new MailAddress(CCEmail));
            }

            string filepath = Directory.GetCurrentDirectory();
            var path = filepath + reportpath + filename;

            if (path.Length > 0)
            {
                Attachment attachment;
                attachment = new Attachment(path);
                mailMessage.Attachments.Add(attachment);
            }

            try
            {
                using (SmtpClient smtp = new SmtpClient())
                {
                    smtp.Host = Config.HostAddress;
                    //network and security related credentials  
                    smtp.EnableSsl = false;
                   // NetworkCredential NetworkCred = ;
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCredential(Pass, mailMessage);
                    smtp.Port = Port;
                    smtp.Send(mailMessage); //sending Email 
                }
            }
            catch(Exception ex)
            {
                throw;
            }
           
        }

        private NetworkCredential NetworkCredential(string Pass, MailMessage mailMessage)
        {
            NetworkCredential NetworkCred = new NetworkCredential();
            NetworkCred.UserName = mailMessage.From.Address;
            NetworkCred.Password = Pass;
            return NetworkCred;
        }

        #endregion
    }
}
