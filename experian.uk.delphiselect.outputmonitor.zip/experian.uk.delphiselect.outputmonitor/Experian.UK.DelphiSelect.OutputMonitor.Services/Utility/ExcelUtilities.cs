﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Text;
using Range = Microsoft.Office.Interop.Excel.Range;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Utility
{
    public class ExcelUtilities
    {
        public Worksheet Sheet { get; set; }
        private readonly Application _excel = new Application();
        private Workbook _workbook;

        public void SetExcelFile(string path, string sheetName)
        {
            try
            {
                _workbook = _excel.Workbooks.Open(path);

                Sheet = (Worksheet)_workbook.Sheets.Item[sheetName];
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Close();
            }
        }

        public string GetCellData(int row, int col)
        {
            var s = (Range)Sheet.Cells[row, col];

            return s.Value2 != null ? s.Value2.ToString() : string.Empty;
        }

        public void SetCellData(int row, int col, string value)
        {
            var s = (Range)Sheet.Cells[row, col];

            s.Value2 = value;
        }

        public void Close()
        {
            _workbook?.Close();
            _excel?.Quit();
        }
    }
}