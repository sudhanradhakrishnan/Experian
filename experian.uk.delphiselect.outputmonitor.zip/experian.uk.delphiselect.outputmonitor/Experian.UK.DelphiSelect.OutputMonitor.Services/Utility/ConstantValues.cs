﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Utility
{
   public static class ConstantValues
    {
        public static readonly string templatepath = @"\Template";
        public static readonly string reportpath = @"\OutPut\Report";
        public static readonly string filename = "DailyReportingTemplate.xlsx";

        public static string[] SearchCriteriaKey = new string[32] { "D001", "D002", "D003", "D004", "D005", "D006", "D007", "D019", "D020", "D021", "D022", "D023", "D025", "D026A", "D026B", "D026C", "D026D", "D026E", "D026F", "D026G", "D026H", "D026I", "D026J", "D026K", "D026L", "D026M", "D026N", "D026O", "D026P", "D026Q", "D026R", "D026S" };
        public static string[] DelphiScorecard = new string[9] { "D008", "D009A", "D010", "D013", "D016", "D029", "D030A", "D028", "D024" };
    }
}
