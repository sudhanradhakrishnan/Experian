﻿using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using Splunk.Client;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Services.Utility
{
    public static class CommonUtility
    {
        public static int ConvertStringtoInt(this string val)
        {
            int outValue;
            return int.TryParse(val, out outValue) ? (int)outValue : 0;
        }

        public static decimal ConvertStringtoDecmial(this string val)
        {
            decimal outValue;
            decimal returnval = decimal.TryParse(val, out outValue) ? (decimal)outValue : 0;
            decimal r = Math.Round(returnval, 5);
            return r;

        }

        public static DateTime? ConvertStringtoDate(this string dateval)
        {
            DateTime tempDate;
            return DateTime.TryParseExact(dateval, "dd/MM/yyyy",
                                 new CultureInfo("en-US"),
                                 DateTimeStyles.None, out tempDate) ? (DateTime?)tempDate : null;
        }


        public static string  SetDateTime(this int day )
        {
            DateTime start = DateTime.UtcNow.AddDays(day);
            DateTime settime1 = new DateTime(start.Year, start.Month, start.Day, 0, 0, 0);
            //DateTime end = DateTime.UtcNow.AddDays(0);
            //DateTime settime2 = new DateTime(end.Year, end.Month, end.Day, 0, 0, 0);
            return start.ToString("yyyy-MM-dd") + "T00:00:00.000-00:00";
            //this.searchLatestTime = end.ToString("yyyy-MM-dd") + "T00:00:00.000-00:00";
        }

        public static DailyAlertingReport ExtractDailyReportFromSplunk(string requirementCriteria, SearchResult result)
        {
            var searchResultModel = new DailyAlertingReport();
            try
            {
                if (result.GetValue("Key") != null)
                    searchResultModel.KeyValue = result.GetValue("Key");
                if (result.GetValue("Day") != null)
                    searchResultModel.QueryDate = CommonUtility.ConvertStringtoDate(result.GetValue("Day"));
                if (result.GetValue("Client_ID") != null)
                    searchResultModel.Client_ID = result.GetValue("Client_ID");
                if (result.GetValue("AccountNumber") != null)
                    searchResultModel.AccountNumber = result.GetValue("AccountNumber");
                if (result.GetValue("count") != null)
                    searchResultModel.CountActiveCAIS = CommonUtility.ConvertStringtoInt(result.GetValue("count"));
                if (result.GetValue("Total_Applications") != null)
                    searchResultModel.TotalApplications = CommonUtility.ConvertStringtoInt(result.GetValue("Total_Applications"));
                //for second set TODO Application_Type/Delphi_Scorecard/avg
                if (result.GetValue("Application_Type") != null)
                    searchResultModel.Application_Type = result.GetValue("Application_Type");
                if (result.GetValue("Delphi_Scorecard") != null)
                    searchResultModel.Delphi_Scorecard = result.GetValue("Delphi_Scorecard");
                if (result.GetValue("avg") != null)
                    searchResultModel.avg = CommonUtility.ConvertStringtoDecmial(result.GetValue("avg"));

                searchResultModel.RequirementCriteria = requirementCriteria;
                searchResultModel.MODIFIED_DATE = DateTime.UtcNow;
            }
            catch (Exception ex)
            {
                throw (ex);
            }

            return searchResultModel;
        }

        public static decimal CalculatePercentageavg(decimal firstval, decimal secondval)
        {
            decimal percentage = 0;
            if (firstval > 0 && secondval > 0)
                percentage = (firstval / secondval) * 100;
            return percentage;
        }

        public static DateTime PreviousMonthFirstDay(this DateTime currentDate)
        {
            DateTime d = currentDate.PreviousMonthLastDay();

            return new DateTime(d.Year, d.Month, 1);
        }

        public static DateTime PreviousMonthLastDay(this DateTime currentDate)
        {
            return new DateTime(currentDate.Year, currentDate.Month, 1).AddDays(-1);
        }


        public static bool CheckCurrentMonthFirstDay()
        {
            DateTime currentDate = DateTime.UtcNow;
            DateTime currentMonthFirstDay = new DateTime(currentDate.Year, currentDate.Month, 1);
            bool returnvalue = false;
            if (currentMonthFirstDay.Date == currentDate.Date)
                returnvalue = true;

            return returnvalue;            

        }


    }
}
