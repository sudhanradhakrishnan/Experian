using Experian.UK.DelphiSelect.OutputMonitor.Core;
using Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.DAL.Services;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Net.Http;

namespace Experian.UK.DelphiSelect.OutputMonitor
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            var builder = Host.CreateDefaultBuilder(args);
            //    .AddExperianConfiguration();
            try
            {
                builder.ConfigureServices((hostContext, services) =>
                {
                    Console.WriteLine("Environment: " + hostContext.HostingEnvironment.EnvironmentName);
                    Console.WriteLine("Root Path: " + hostContext.HostingEnvironment.ContentRootPath);
                    IConfiguration configuration = hostContext.Configuration;
                    services.AddHostedService<Worker>();
                    var connection = configuration.GetConnectionString("DatabaseConnection");
                    services.AddDbContext<DatabaseContext>(options => options.UseSqlServer(connection));
                    services.AddDbContext<DbContext>(options => options.UseSqlServer(connection));
                    services.Configure<WorkerConfigurationModel>(configuration.GetSection("splunk"));
                    services.Configure<DelphiSelectOutputMonitorConfig>(configuration.GetSection("splunkSDK"));
                    services.Configure<EmailSettingsConfig>(configuration.GetSection("EmailSettings"));
                    services.AddHttpClient("HttpClientWithSSLUntrusted").ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
                    {
                        ClientCertificateOptions = ClientCertificateOption.Manual,
                        ServerCertificateCustomValidationCallback =
                            (httpRequestMessage, cert, cetChain, policyErrors) =>
                            {
                                return true;
                            }
                    });
                    services.AddTransient<IDailyAlertingReportContext, DailyAlertingReportContext>();
                    services.AddTransient<IMonthlyReportContext, MonthlyReportContext>();
                    services.AddTransient<ISearchCriteriaContext, SearchCriteriaContext>();
                    services.AddScoped<DbContext, DatabaseContext>();
                    services.AddScoped<IEmailService, EmailService>();
                    services.AddScoped<IExcelServices, ExcelServices>();
                    services.AddScoped<ISplunkSDKService, SplunkSDKService>();
                });
            }
            catch (Exception e)
            {
                Console.WriteLine("it went wrong", e);
            }
            return builder;
        }
    }
}