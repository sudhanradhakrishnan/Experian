﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model.Core
{
    public class WorkerConfigurationModel
    {
        public string Url { get; set; }
        public string SearchPath { get; set; }
        public string Results { get; set; }
        public string ResultPreview { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
    }
}

