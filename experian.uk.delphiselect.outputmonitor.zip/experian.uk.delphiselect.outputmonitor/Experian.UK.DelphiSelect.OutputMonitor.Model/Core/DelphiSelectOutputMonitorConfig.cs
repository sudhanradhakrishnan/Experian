﻿using Splunk.Client;
using System;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model.Core
{
    public class DelphiSelectOutputMonitorConfig
    {
        public string Url { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public double TimeoutSeconds { get; set; }
        public int Port { get; set; }
        public Scheme Scheme { get; set; }
        public string ExcelLocation { get; set; }

        public bool IsMonthlyDataRequired { get; set; }

      

        public DateTime EarliestStartDate { get; set; }
        public DateTime LatestEndDate { get; set; }
    }
}

