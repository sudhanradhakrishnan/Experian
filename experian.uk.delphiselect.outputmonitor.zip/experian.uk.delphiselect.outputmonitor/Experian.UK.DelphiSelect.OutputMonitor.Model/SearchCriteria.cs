﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model
{
    public class SearchCriteria
    {
        public int ID { get; set; }
        public string DayMonth { get; set; }
        public string SheetName { get; set; }
        public string Key { get; set; }
        public string Query { get; set; }
        public string Description { get; set; }
        public DateTime MODIFIED_DATE { get; set; }

    }
}
