﻿using System;
using System.Collections.Generic;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model
{
    public class SearchResultResponse
    {
        // private string
        public string Key { get; set; }
        public string Month { get; set; }
        public string Client_ID { get; set; }
        public string AccountNumber { get; set; }
        public List<string> Application_Type { get; set; }
    
    }
}
