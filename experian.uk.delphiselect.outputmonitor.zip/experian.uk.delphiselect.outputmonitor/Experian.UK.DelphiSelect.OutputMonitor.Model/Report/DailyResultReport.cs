﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model.Report
{
    public class DailyResultReport : DailyAlertingReport
    {
        private decimal _percentage;

        public decimal PreviousMonthAggregate { get; set; }

        public decimal Percentage
        {
            get => _percentage;
            set
            {
                decimal result = 0;
                if (this.TotalApplications > 0 && this.CountActiveCAIS > 0)
                    result = ((Decimal)this.CountActiveCAIS / (Decimal)this.TotalApplications) * 100;
                _percentage = result;
            }
        }
    }
}
