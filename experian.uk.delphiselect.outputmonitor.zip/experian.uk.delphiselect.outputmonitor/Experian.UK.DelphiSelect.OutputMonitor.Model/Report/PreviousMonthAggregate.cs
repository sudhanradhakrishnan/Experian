﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model.Report
{
    public class PreviousMonthAggregate 
    {

        public int Aggregate { get; set; }
        public string Client_ID { get; set; }
        public string AccountNumber { get; set; }
        public string RequirementCriteria { get; set; }
        public string KeyValue { get; set; }


    }
}
