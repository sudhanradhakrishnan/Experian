﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model.Report
{
    public class PreviousMonthCalculation : DailyAlertingReport
    {
        public string LastMonthDelphiScorecards { get; set; }
        public decimal LastMonthAvg { get; set; }
        public decimal Changeavg { get; set; }
        public decimal Change_Percentageavg { get; set; }
        public decimal LastMonthApplicationsPercentage { get; set; }//* Last_Month_Percentage=(Last_Month_count/Last_Month_Applications )x100
        public string LastMonthApplicationTypes { get; set; }
        public decimal Change_Percentage_Application { get; set; }

        public int LastMonthCount { get; set; }
        public int LastMonthApplicationCount { get; set; }

        private decimal _percentage;
        public decimal Percentage
        {
            get => _percentage;
            set
            {
                decimal result = 0;
                if (this.TotalApplications > 0 && this.CountActiveCAIS > 0)
                    result = ((Decimal)this.CountActiveCAIS / (Decimal)this.TotalApplications) * 100;
                _percentage = result;
            }
        }
    }
}
