﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model.Report
{
    public class DailyAlertingReport
    {

        [Key]
        public int ID { get; set; }
        public string KeyValue { get; set; }
		public DateTime  QueryDate { get; set; }
		public string Client_ID { get; set; }
		public string AccountNumber { get; set; }
		public int CountActiveCAIS { get; set; }
		public int TotalApplications { get; set; }
		public string RequirementCriteria { get; set; }
		public DateTime MODIFIED_DATE { get; set; }
		
		public string Application_Type { get; set; }
		public string Delphi_Scorecard { get; set; }
		public decimal avg { get; set; }

	}


}
