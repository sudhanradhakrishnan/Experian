﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.Model.Report
{
   public class RequirementCriteria
	{
       

		public int CriteriaID { get; set; }
		
		public string RequirementCriteriaValue { get; set; }

	}
}
