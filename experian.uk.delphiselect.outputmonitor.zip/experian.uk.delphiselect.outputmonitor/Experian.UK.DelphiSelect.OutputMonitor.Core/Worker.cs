﻿using Experian.UK.DelphiSelect.OutputMonitor.Model.Core;
using Experian.UK.DelphiSelect.OutputMonitor.Services.Interface;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace Experian.UK.DelphiSelect.OutputMonitor.Core
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IServiceProvider _services;
        private IHttpClientFactory ClientFactory { get; }
        private Timer timer;
        private WorkerConfigurationModel Config { get; }
        private IHostApplicationLifetime HostApplicationLifetime { get; }


        public Worker(ILogger<Worker> logger, IHostApplicationLifetime hostApplicationLifetime, IServiceProvider services, IHttpClientFactory clientFactory, IOptions<WorkerConfigurationModel> config)
        {
            _logger = logger;
            _services = services;
            ClientFactory = clientFactory;
            Config = config.Value;
            HostApplicationLifetime = hostApplicationLifetime;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                SearchSplunkLog();

                HostApplicationLifetime.StopApplication();
            }
        }



        private void SearchSplunkLog()
        {
            // do some work
            using (var scope = _services.CreateScope())
            {
                string filepath = Directory.GetCurrentDirectory();
                var splunkService = scope.ServiceProvider.GetRequiredService<ISplunkSDKService>();
                splunkService.DelphiSelectDailyReport();
                //Generate monthly report
                splunkService.DelphiSelectMonthlyReport();
            }
        }

    }

}
