﻿using Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.SqlTypes;
using System.Linq;

namespace Experian.UK.DelphiSelect.OutputMonitor.DAL.Services
{
    public class MonthlyReportContext : IMonthlyReportContext
    {
      
        private DatabaseContext _context;

        public MonthlyReportContext(DatabaseContext context)
        {
            _context = context;
        }
       

        public int AddMonthlyReport(List<MonthlyReport> entity)
        {
            foreach (MonthlyReport report in entity)
            {
                _context.MonthlyReport.Add(report);
            }              

            return _context.SaveChanges();
        }


    }
}
