﻿using Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Model;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Experian.UK.DelphiSelect.OutputMonitor.DAL.Services
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           // optionsBuilder.UseSqlServer(@"Data Source=10.185.240.79;Initial Catalog=DelphiSelectMonitor;Persist Security Info=True;User ID=DelphiSelectMonitorDev;Password=Omhafeieio");
        }

        public DbSet<DailyAlertingReport> DailyAlertingReport { get; set; }
        public DbSet<MonthlyReport> MonthlyReport { get; set; }

        public DbSet<SearchCriteria> SearchCriteria { get; set; }
      

        #region Required
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DailyAlertingReport>()
                .Property(b => b.avg).HasPrecision(12, 5);
            modelBuilder.Entity<MonthlyReport>()
               .Property(b => b.avg).HasPrecision(12, 5);
        }
        #endregion
    }
}
