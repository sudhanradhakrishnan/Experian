﻿using Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.SqlTypes;
using System.Linq;

namespace Experian.UK.DelphiSelect.OutputMonitor.DAL.Services
{
    public class DailyAlertingReportContext : IDailyAlertingReportContext
    {
      
        private DatabaseContext _context;

        public DailyAlertingReportContext(DatabaseContext context)
        {
            _context = context;
        }
       

        public int AddDailyAlertingReport(List<DailyAlertingReport> entity)
        {
            foreach (DailyAlertingReport report in entity)
            {
                _context.DailyAlertingReport.Add(report);
            }              

            return _context.SaveChanges();
        }


        public List<DailyResultReport> GetYesterdayReport()
        {
            var dailyReports = (from DailyReport in _context.DailyAlertingReport
                                where DailyReport.QueryDate == DateTime.Today.AddDays(-1)
                                select new DailyResultReport
                                {
                                    ID = DailyReport.ID,
                                    KeyValue = DailyReport.KeyValue ,
                                    QueryDate = DailyReport.QueryDate,
                                    Client_ID = DailyReport.Client_ID,
                                    AccountNumber = DailyReport.AccountNumber,
                                    CountActiveCAIS = DailyReport.CountActiveCAIS,
                                    TotalApplications = DailyReport.TotalApplications,
                                    RequirementCriteria = DailyReport.RequirementCriteria,
                                    MODIFIED_DATE = DailyReport.MODIFIED_DATE,
                                    Application_Type = DailyReport.Application_Type,
                                    Delphi_Scorecard = DailyReport.Delphi_Scorecard,
                                    avg = DailyReport.avg,
                                    Percentage =0
                                }).ToList();

            return dailyReports;
        }

        public List<DailyAlertingReport> GetLastMonthReport()
        {
            var startOfTthisMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            var firstDay = startOfTthisMonth.AddMonths(-1);
            var lastDay = startOfTthisMonth.AddDays(-1);
            try
            {
                var lastMonthReport = (from DailyReport in _context.DailyAlertingReport
                                    where DailyReport.QueryDate >= firstDay && DailyReport.QueryDate <= lastDay
                                    select new DailyAlertingReport
                                    {
                                        ID = DailyReport.ID,
                                        KeyValue = DailyReport.KeyValue,
                                        QueryDate = DailyReport.QueryDate,
                                        Client_ID = DailyReport.Client_ID,
                                        AccountNumber = DailyReport.AccountNumber,
                                        CountActiveCAIS = DailyReport.CountActiveCAIS,
                                        TotalApplications = DailyReport.TotalApplications,
                                        RequirementCriteria = DailyReport.RequirementCriteria,
                                        MODIFIED_DATE = DailyReport.MODIFIED_DATE,
                                        Application_Type = DailyReport.Application_Type,
                                        Delphi_Scorecard = DailyReport.Delphi_Scorecard,
                                        avg = DailyReport.avg
                                    }).ToList();                 

                return lastMonthReport;
            }
            catch(Exception ex) 
            {
                throw;
            }

           
        }

    }
}
