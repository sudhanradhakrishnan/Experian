﻿using Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface;
using Experian.UK.DelphiSelect.OutputMonitor.Model;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.DAL.Services
{
    public class SearchCriteriaContext : ISearchCriteriaContext
    {
      
        private DatabaseContext _context;

        public SearchCriteriaContext(DatabaseContext context)
        {
            _context = context;
        }


        public int AddSearchCriteria(List<SearchCriteria> entity)
        {
            foreach (SearchCriteria report in entity)
            {
                _context.SearchCriteria.Add(report);
            }

            return _context.SaveChanges();
        }

        public List<SearchCriteria> SearchCriteria(string MonthorDay)
        {
            var searchCriterialist = (from searchCriteria in _context.SearchCriteria
                                      where searchCriteria.DayMonth == MonthorDay
                                      select new SearchCriteria
                                      {
                                          ID = searchCriteria.ID,
                                          DayMonth = searchCriteria.DayMonth,
                                          SheetName = searchCriteria.SheetName,
                                          Key = searchCriteria.Key,
                                          Query = searchCriteria.Query,
                                          Description = searchCriteria.Description,
                                          MODIFIED_DATE = searchCriteria.MODIFIED_DATE
                                      }).OrderBy(m => m.ID).ToList();
            return searchCriterialist;
        }
    }
}
