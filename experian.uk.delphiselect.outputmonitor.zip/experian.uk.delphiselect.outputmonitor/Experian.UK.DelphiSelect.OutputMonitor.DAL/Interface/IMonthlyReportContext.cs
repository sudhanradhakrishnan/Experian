﻿using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface
{
    public interface IMonthlyReportContext
    {
        int AddMonthlyReport(List<MonthlyReport> entity);

    }
}
