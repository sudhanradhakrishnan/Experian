﻿using Experian.UK.DelphiSelect.OutputMonitor.Model;
using Experian.UK.DelphiSelect.OutputMonitor.Model.Report;
using System;
using System.Collections.Generic;
using System.Text;

namespace Experian.UK.DelphiSelect.OutputMonitor.DAL.Interface
{
    public interface ISearchCriteriaContext
    {
        List<SearchCriteria> SearchCriteria(string MonthorDay);
        int AddSearchCriteria(List<SearchCriteria> entity);
    }
}
