﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigManagementCore.Model
{
    public partial class DataInputViewModel
    {
        [Key]
        public int ID { get; set; }       
        public int ClientID { get; set; }
        public int CustomerID { get; set; }

        public string SystemSpecify { get; set; }
        public string StateRequired { get; set; }

        public string TxtClientID { get; set; }
    }
}
