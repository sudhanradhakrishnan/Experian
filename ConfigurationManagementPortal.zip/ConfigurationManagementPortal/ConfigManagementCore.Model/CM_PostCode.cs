﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigManagementCore.Model
{
    public class CM_PostCode
    {
        [Key]
        public int PostCodeID { get; set; }
        public string PostCodeName { get; set; }
       
    }
}
