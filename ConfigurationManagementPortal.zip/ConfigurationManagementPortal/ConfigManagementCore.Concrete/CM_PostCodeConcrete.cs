﻿using ConfigManagementCore.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConfigManagementCore.Model;

namespace ConfigManagementCore.Concrete
{
    public class CM_PostCodeConcrete : ICM_PostCode
    {
        private DatabaseContext _context;

        public CM_PostCodeConcrete(DatabaseContext context)
        {
            _context = context;
        }

        public List<CM_PostCode> ListofPostCode()
        {
            return _context.CM_PostCode.ToList();
        }
    }
}
