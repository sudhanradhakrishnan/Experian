﻿using ConfigManagementCore.Model;
using Microsoft.EntityFrameworkCore;

namespace ConfigManagementCore.Concrete
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }

        public DbSet<CM_PostCode> CM_PostCode { get; set; }
        public DbSet<Roles> Roles { get; set; }

        public DbSet<CM_Registration> CM_Registration { get; set; }

    }
}
