﻿using ConfigManagementCore.Interface;
using ConfigManagementCore.Model;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic;

namespace ConfigManagementCore.Concrete
{
    public class CM_RegistrationConcrete : ICM_Registration
    {
        private DatabaseContext _context;

        public CM_RegistrationConcrete(DatabaseContext context)
        {
            _context = context;
        }

        public void AddAdmin(CM_Registration entity)
        {
            _context.CM_Registration.Add(entity);
            _context.SaveChanges();
        }

        public int AddUser(CM_Registration entity)
        {
            _context.CM_Registration.Add(entity);
            return _context.SaveChanges();
        }

        public bool CheckUserNameExists(string Username)
        {
            var result = (from user in _context.CM_Registration
                          where user.Username == Username
                          select user).Count();

            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public CM_RegistrationViewModel Userinformation(int UserID)
        {
            var result = (from user in _context.CM_Registration
                          join PostCode in _context.CM_PostCode on user.PostCode equals PostCode.PostCodeID                          
                          where user.ID == UserID
                          select new CM_RegistrationViewModel
                          { 
                            Name =user.Name,
                            Middlename = user.Middlename,
                            SurName = user.SurName,
                            PostCode = PostCode.PostCodeName,
                            HouseNumber = user.HouseNumber ,
                            Streetname = user.Streetname,
                            EmailID =user.EmailID,
                            CreatedOn = user.CreatedOn.Value.ToString("dd/MM/yyyy"),
                            Birthdate = user.Birthdate.Value.ToString("dd/MM/yyyy"),
                            Gender = user.Gender == "M" ? "Male":"Female",                           
                            Username = user.Username,
                            Password = user.Password,
                          }).SingleOrDefault();
            return result;
        }

        public IQueryable<CM_RegistrationViewModel> UserinformationList(string sortColumn, string sortColumnDir, string Search)
        {
            var IQueryableReg = (from user in _context.CM_Registration
                                 join PostCode in _context.CM_PostCode on user.PostCode equals PostCode.PostCodeID                                 
                                 select new CM_RegistrationViewModel
                                 {
                                     Name = user.Name,
                                     Middlename = user.Middlename,
                                     SurName = user.SurName,
                                     PostCode = PostCode.PostCodeName,
                                     HouseNumber = user.HouseNumber,
                                     Streetname = user.Streetname,
                                     EmailID = user.EmailID,
                                     CreatedOn = user.CreatedOn.Value.ToString("dd/MM/yyyy"),
                                     Birthdate = user.Birthdate.Value.ToString("dd/MM/yyyy"),
                                     Gender = user.Gender == "M" ? "Male" : "Female",
                                     Username = user.Username
                                 });
            if (!(string.IsNullOrEmpty(sortColumn) && string.IsNullOrEmpty(sortColumnDir)))
            {
                IQueryableReg = IQueryableReg.OrderBy(sortColumn + " " + sortColumnDir);
            }
            if (!string.IsNullOrEmpty(Search))
            {
                IQueryableReg = IQueryableReg.Where(m => m.Username == Search || m.PostCode == Search || m.EmailID == Search);
            }

            return IQueryableReg;
        }
    }
}
