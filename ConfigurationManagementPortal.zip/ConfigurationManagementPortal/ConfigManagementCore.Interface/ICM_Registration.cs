﻿using ConfigManagementCore.Model;
using System.Linq;

namespace ConfigManagementCore.Interface
{
    public interface ICM_Registration
    {
        int AddUser(CM_Registration entity);
        void AddAdmin(CM_Registration entity);
        bool CheckUserNameExists(string Username);
        CM_RegistrationViewModel Userinformation(int UserID);
        IQueryable<CM_RegistrationViewModel> UserinformationList(string sortColumn, string sortColumnDir, string Search);

    }
}
