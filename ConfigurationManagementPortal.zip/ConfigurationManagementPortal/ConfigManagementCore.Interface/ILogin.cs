﻿using ConfigManagementCore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigManagementCore.Interface
{
    public interface ILogin
    {
        CM_Registration ValidateUser(string userName, string passWord);
        bool UpdatePassword(CM_Registration Registration);
    }
}
