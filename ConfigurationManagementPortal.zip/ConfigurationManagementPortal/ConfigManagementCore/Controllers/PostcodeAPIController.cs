﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ConfigManagementCore.Interface;
using ConfigManagementCore.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ConfigManagementCore.Controllers
{
    [Route("api/[controller]")]
    public class PostcodeAPIController : Controller
    {
        private ICM_PostCode _IPostCode;

        public PostcodeAPIController(ICM_PostCode IPostCode)
        {
            _IPostCode = IPostCode;
        }

        // GET: api/values
        [HttpGet]
        public IEnumerable<CM_PostCode> Get()
        {
            try
            {
                var listofCountry = _IPostCode.ListofPostCode();
                listofCountry.Insert(0, new CM_PostCode { PostCodeID = 0, PostCodeName = "----Select----" });
                return listofCountry;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
