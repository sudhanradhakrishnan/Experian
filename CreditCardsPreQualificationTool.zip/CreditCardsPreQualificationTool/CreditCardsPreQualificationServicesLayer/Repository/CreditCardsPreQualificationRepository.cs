﻿using CreditCardPreQualificationBusinessModels.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CreditCardsPreQualificationServicesLayer.Repository
{
    /// <summary>
    /// This Class is used to implement Database layer
    ///Method for Insert PersonalInfo  Details in DB
    ///Get the all applicant information to display in report screen
    /// </summary>
    public class CreditCardsPreQualificationRepository : ICreditCardsPreQualificationRepository
    {
        private SqlConnection con;
        private readonly IConfiguration config;
        private readonly ILogger<CreditCardsPreQualificationRepository> _logger;
        //To Handle connection related activities

        /// <summary>
        /// This Method is used to connect DB
        /// </summary>
        private void connection()
        {
            string constr = config.GetValue<string>("DBConnection:Connection:PreQualificationconn");
            con = new SqlConnection(constr);
        }

        public CreditCardsPreQualificationRepository(IConfiguration configuration, ILogger<CreditCardsPreQualificationRepository> logger)
        {
            _logger = logger;
            config = configuration;
        }

        /// <summary>
        /// This Method is used to insert details in BD for Audit report
        /// </summary>
        /// <param name="personalInfo">object of PersonalInfo</param>
        /// <returns>return the row number inserted</returns>
        public int CheckPreQualification(PersonalInfo personalInfo)
        {

            connection();

            int identity = 0;

            SqlCommand sqlCommand = new SqlCommand("InsertPersonalInfo", con);
            sqlCommand.CommandType = CommandType.StoredProcedure;//@FirstName,@LastName,@DOB,@AnnualIncome
            sqlCommand.Parameters.AddWithValue("@FirstName", personalInfo.FirstName);
            sqlCommand.Parameters.AddWithValue("@LastName", personalInfo.LastName);
            sqlCommand.Parameters.AddWithValue("@DOB", personalInfo.DateofBirth);
            sqlCommand.Parameters.AddWithValue("@Age", personalInfo.Age);
            sqlCommand.Parameters.AddWithValue("@BankId", personalInfo.BankId);
            sqlCommand.Parameters.AddWithValue("@AnnualIncome", personalInfo.Annualincome);

            sqlCommand.Parameters.Add("@Identity", SqlDbType.Int).Direction = ParameterDirection.Output;


            try
            {
                con.Open();
                sqlCommand.ExecuteNonQuery();
                identity = Convert.ToInt32(sqlCommand.Parameters["@Identity"].Value);

            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Services Name : CreditCardsPreQualificationRepository , Method Name : AddPersonalInfo Error Message :, {ex.Message }");
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
            return identity;
        }

        /// <summary>
        /// This method is used to Add the Bank details for each applicant.
        /// </summary>
        /// <param name="PersonalInfoId">PersonalInfoId id which is received from CheckPreQualification method </param>
        /// <param name="BankDetails">Bank id details</param>
        /// <returns></returns>
        public void AddReportInfo(int PersonalInfoId, int BankDetails)
        {

            connection();

            int identity = 0;

            SqlCommand sqlCommand = new SqlCommand("InsertAuditReportDetails", con);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.AddWithValue("@PersonalInfoId", PersonalInfoId);
            sqlCommand.Parameters.AddWithValue("@BankDetails", BankDetails);
            sqlCommand.Parameters.Add("@Identity", SqlDbType.Int).Direction = ParameterDirection.Output;


            try
            {
                con.Open();
                sqlCommand.ExecuteNonQuery();
               // identity = Convert.ToInt32(sqlCommand.Parameters["@Identity"].Value);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }


        /// <summary>
        /// This method is used to Get the Audit report 
        /// <summary>
        /// <returns>List of ApplicantDetails </returns>
        public List<ApplicantDetails> GetAllApplicantInformation()
        {

            connection();

            SqlCommand sqlCommand = new SqlCommand("GetAllApplicantInformation", con);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            List<ApplicantDetails> lstApplicationDetails = new List<ApplicantDetails>();

            try
            {
                con.Open();
                SqlDataReader reader = sqlCommand.ExecuteReader();

                while (reader.Read())
                {

                    ApplicantDetails _ApplicantDetail = new ApplicantDetails();
                    _ApplicantDetail.FullName = reader["FullName"].ToString();
                    _ApplicantDetail.BankDetails = reader["BankDetails"].ToString();
                    _ApplicantDetail.Age = int.Parse(reader["Age"].ToString());
                    _ApplicantDetail.AnnualIncome = float.Parse(reader["AnnualIncome"].ToString());
                    _ApplicantDetail.AttemptDate = DateTime.Parse(reader["AttemptDate"].ToString());
                    lstApplicationDetails.Add(_ApplicantDetail);

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
            }
            return lstApplicationDetails;
        }
    }
}


