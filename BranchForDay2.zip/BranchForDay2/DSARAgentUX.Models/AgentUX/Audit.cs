﻿using DSARAgentUX.Models.DataSubjectAccessRequests;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSARAgentUX.Models
{
    public class Audit
    {
        public string DsarReferenceId { get; set; }
        
        public string PdfReference { get; set; }
        

        public string ModifyedPdfName { get; set; }
        

        public string ActualPdfName { get; set; }
        

        public string UserId { get; set; }
       

        public bool IsPdFuploaded { get; set; }
        
        public AuditEventsType Operation { get; set; }
        
        public Audit ()
        {
            DsarReferenceId = string.Empty;
            PdfReference = string.Empty;
            ModifyedPdfName = string.Empty;
            ActualPdfName = string.Empty;
            UserId = string.Empty;
            IsPdFuploaded = false;
            Operation = AuditEventsType.NOACTION;
        }
    }
}
