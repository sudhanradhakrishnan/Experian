﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Xml;
using DSARAgentUX.Models.DataSubjectAccessRequests;

namespace DSARAgentUX.Models
{
    public class ServiceUserModel
    {
        public int PdfId { get; set; }
        [Display(Name = "Uploaded File")] public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public string DsarReference { get; set; }
        public string PdfReference { get; set; }
        public string DepartmentFriendlyName { get; set; }
        public DsarStatusType DsarStatus { get; set; }
        public PDFStatusType PdfStatus { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public PublishStatusType PublishStatus { get; set; }
        public DuplicateCheckStatusType DuplicateStatus { get; set; }
        public DsarCancelType DsarCancelStatus { get; set; }
        public dsars DataSubjectAccessRequest { get; set; }
        public XmlDocument xmlcontent { get; set; }

        public string Username { get; set; }
        public DateTime ActivityTime { get; set; }
    }
}