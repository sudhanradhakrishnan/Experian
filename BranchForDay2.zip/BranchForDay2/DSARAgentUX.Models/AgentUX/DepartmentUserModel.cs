﻿using DSARAgentUX.Models.DataSubjectAccessRequests;

namespace DSARAgentUX.Models
{
 public   class DepartmentUserModel
    {
//        public int Id { get; set; }
//        [Display(Name = "Uploaded File")]
//        public string FileName { get; set; }
        public string PdfReferenceNumbers { get; set; }
//        public string DepartmentName { get; set; }
        public string Departments { get; set; }
        public PDFStatusType PdfStatus { get; set; }
        public string ModifiedBy { get; set; }
    }
}
