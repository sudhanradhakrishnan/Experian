﻿namespace DSARAgentUX.Models
{
    public interface ICurrentUser
    {
        bool IsAuthorized { get; }
        bool IsEntitledToCancel { get; }
        bool IsEntitledToPublish { get; }
        bool IsEntitledToRemoveDuplicateCheck { get; }
        UserAuthProfile UserAuthProfile { get; }
        string UserId { get; }
        bool IsEntitledToPdfUpload(string pdfReference);
    }
}