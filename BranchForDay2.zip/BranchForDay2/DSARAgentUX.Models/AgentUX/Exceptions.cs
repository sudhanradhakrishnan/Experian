﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSARAgentUX.Models
{
    
    public class DSARException : System.Exception
    {

        public DSARException(string message) : base(message)
        {

        }
        public DSARException(String message, Exception innerException)
                             : base(message, innerException)
        {
        }
    }

}
