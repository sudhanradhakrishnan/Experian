﻿using System.Collections.Generic;
using System.Linq;

namespace DSARAgentUX.Models
{
    public partial class UserAuthProfile
    {

        public UserAuthProfile(string userId,IEnumerable<string> snowGroupList, groupType[] secgroups)
        {
            var groups = new List<string>();

            foreach (var key in snowGroupList.ToList())
            {
                if (secgroups.FirstOrDefault(x => x.name.Trim().Equals(key.Trim())) != null)
                {
                    groups.Add(secgroups.First(x => x.name.Trim().Equals(key.Trim())).id);
                }
            }

            Group = groups.ToArray();
            Id = userId;

 
        }

        /// <remarks></remarks>
        public string Id { get; set; }

        public string[] Group { get; set; }
    }
}
