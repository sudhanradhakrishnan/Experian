﻿using ExperianLogger;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DSARAgentUX.Models
{
    public sealed class CurrentUser : ICurrentUser
    {
        private ILogger Logger { get; }
        public bool IsAuthorized { get; }
        public string UserId { get; }
        public UserAuthProfile UserAuthProfile { get; }
        public bool IsEntitledToCancel { get; }
        public bool IsEntitledToRemoveDuplicateCheck { get; }
        public bool IsEntitledToPublish { get; }
        private List<string> PdfReferences { get; }
        private actionmapType ActionMap { get; }

        public CurrentUser(securityType securityInformation, UserAuthProfile userAuthProfile)
        {
            IsAuthorized = false;

            Logger = new Logger();

            try
            {

                UserAuthProfile = userAuthProfile;
                UserId = UserAuthProfile.Id;

                if (string.IsNullOrEmpty(UserId))
                {
                    IsAuthorized = UserAuthProfile != null;
                }
                else
                {
                    IsAuthorized = true;
                }


                PdfReferences =
                    !IsAuthorized ? new List<string>() : GetPdfRefByfindGroupsInPdfMaps(securityInformation);

                ActionMap = !IsAuthorized ? new actionmapType() : securityInformation.actionmap;

                IsEntitledToCancel = IsAuthorized && CheckEntitledToCancel();

                IsEntitledToPublish = IsAuthorized && CheckEntitledTopublish();

                IsEntitledToRemoveDuplicateCheck = IsAuthorized && CheckEntitledToRemoveDuplicateCheck();




            }
            catch (Exception ex)
            {
                Logger.LogApplicationError($"USER_AUTH ERROR ,FUNCTION NAME:CurrentUser {UserId} : {ex.Message}");
            }
        }

        public bool IsEntitledToPdfUpload(string pdfReference)
        {
            return PdfReferences.Any(x => x.Equals(pdfReference));
        }

        private bool CheckEntitledToCancel()
        {
            return UserAuthProfile.Group.Any(x => Array.FindAll(ActionMap.cancel, s => s.Equals(x)).Any());
        }

        private bool CheckEntitledToRemoveDuplicateCheck()
        {
            return UserAuthProfile.Group.Any(x => Array.FindAll(ActionMap.removeDuplicateCheck, s => s.Equals(x)).Any());
        }

        private bool CheckEntitledTopublish()
        {
            return UserAuthProfile.Group.Any(x => Array.FindAll(ActionMap.publish, s => s.Equals(x)).Any());

        }

        private List<string> GetPdfRefByfindGroupsInPdfMaps(securityType securityInformation)
        {
            try
            {
                var result = new List<string>();

                foreach (var group in UserAuthProfile.Group.ToList())
                {
                    foreach (var pType in securityInformation.pdfmap.ToList())
                    {
                        if (pType.group.ToList().Contains(group) && !result.Contains(pType.id))
                        {
                            result.Add(pType.id);
                        }
                    }
                }
                return result;

            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"USER_AUTH ERROR ,FUNCTION NAME:GetPdfRefByfindGroupsInPdfMaps {ex.Message}");
                return new List<string>();
            }
        }

    }
}