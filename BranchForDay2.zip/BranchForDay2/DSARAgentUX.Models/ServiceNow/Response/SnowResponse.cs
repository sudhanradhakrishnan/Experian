﻿using DSARAgentUX.Models.ServiceNow.Response;

namespace DSARAgentUX.BusinessLayer.ServiceNow.Response
{
    public class SnowResponse
    {

        public Result result { get; set; }

    }
}
