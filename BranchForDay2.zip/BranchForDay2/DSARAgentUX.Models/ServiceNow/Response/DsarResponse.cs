﻿namespace DSARAgentUX.Models.ServiceNow.Response
{
    public class DsarResponse
    {
        public string dsar_ref { get; set; }
        public string dsar_due_date { get; set; }
        public string request_number { get; set; }
        public string request_id { get; set; }
    }
}
