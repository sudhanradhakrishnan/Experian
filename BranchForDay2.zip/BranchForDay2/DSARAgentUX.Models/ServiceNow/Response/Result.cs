﻿namespace DSARAgentUX.Models.ServiceNow.Response
{
    public class Result
    {
        public string request_number { get; set; }
        public string request_id { get; set; }
    }
}
