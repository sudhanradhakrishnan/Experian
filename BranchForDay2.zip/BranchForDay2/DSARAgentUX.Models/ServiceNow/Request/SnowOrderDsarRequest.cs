﻿namespace DSARAgentUX.Models.ServiceNow.Request
{
    public class SnowOrderDsarRequest
    {
        public string[] items { get; set; }
        public string dsar_ref { get; set; }
        public string dsar_due_date { get; set; }
        public string requestor { get; set; }

    }
}
