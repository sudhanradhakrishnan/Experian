﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSARAgentUX.Models.ServiceNow.Request
{
    public class SnowUpdateDsarRequest
    {
        public string dsar_ref { get; set; }
        public string dsar_pdf { get; set; }
    }
}
