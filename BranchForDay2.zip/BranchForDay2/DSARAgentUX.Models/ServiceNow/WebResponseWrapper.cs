﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DSARAgentUX.Models.ServiceNow
{
    public class WebResponseWrapper : IDisposable
    {

        public void Dispose()
        {
            //Dispose(true);
            GC.SuppressFinalize(this);
        }

        public WebResponseWrapper(WebResponse webResponse, WebException webException)
        {

            if (webResponse != null)
            {
                ResponseString = new StreamReader(webResponse.GetResponseStream()).ReadToEnd();
                HttpStatusCode = HttpStatusCode.OK;
                //TODO Log Here 
            }
            if (webException != null)
            {

                //Set values
                ErrorMessage = webException.ToString();

                ResponseString = "API_FAILURE";
                Status = webException.Status;
  
                if (Status == WebExceptionStatus.ProtocolError)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)webException.Response;
                    HttpStatusCode = httpResponse.StatusCode;

                    ErrorMessage = (int)httpResponse.StatusCode + " - " + "The server returned protocol error "
                       + httpResponse.StatusCode+"\n"+ ErrorMessage;
                }

                //TODO Log Here 
            }

        }

        public string ResponseString { get; set; }
        public string ErrorMessage { get; set; }
        public HttpStatusCode HttpStatusCode { get; set; }
        public WebExceptionStatus Status { get; set; }
    }
}
