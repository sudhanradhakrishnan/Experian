﻿namespace DSARAgentUX.Models
{
    public class Constantfields
    {
        public const string FormattedAddress = "FormattedAddressType";
        public const string StructuredNameType = "StructuredNameType";
        public const string PublishInformation = "Sent to AVCO/Consumer on ";
        public const string HeaderPdfName = "Header.PDF";
        public const string NODATA = "NODATA";
        public const string TRANSFERMESSAGE = "TransferMessage";
        public const string NODATARECEIVED = "No Data Received";
        public const string INSERTED = " Inserted";
        public const string UPDATED = " Updated";
        public const string RemoveItem = " Removed";
        public const string RemoveFailed = " Remove Failed";
        public const string SUCCESS = " success";
        public const string FAILED = " failed";
        public const string PUBLISHEXCEPTION = " Unable to Publish";
        public const string ENCOUNTEREDERROR = " Encountered an Error";
        public const string DSARPDFACTION = "DSARPDFAction";
        public const string SERVICENOWACTION = "ServiceNowAction";
        public const string SERVICENOWVIEW = "ServiceNowView";
        public const string DEPARTMENTUSERVIEW = "DepartmentUserView";
        public const string DsarBatchReportLoad = "DsarBatchReportLoad";
        public const string DSARCTRL = "DsarCtrl";
        public const string PDFFILETYPE = ".pdf,.PDF";
        public const string AUDIORECORDINGPDFREFERENCE = "860";
        public const string AUDIORECORDINGFILETYPE = ".zip,.ZIP";

        public const string FILETYPE = ".pdf,.PDF,.zip,.ZIP";

        public const string MIMETYPE = "application/pdf";

        //application/pdf

    }
}