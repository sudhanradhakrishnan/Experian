﻿namespace DSARAgentUX.Models.DataSubjectAccessRequests
{

    //[dbo].[DSARStatus]
    public enum DsarStatusType
    {
        Active,
        Published,
        Cancelled
    }
    //[dbo].[PDFStatusMaster]
    public enum PDFStatusType
    {
        None,
        State_No_Data,
        Uploaded
    }

    //[dbo].[OperationMaster]
    public enum AuditEventsType
    {
        NOACTION = 100,
        UPLOADPDF = 101,
        VIEWPDF = 102,
        SUPERVISORREVIEW = 103,
        PUBLISHDSAR = 104,
        VIEWALLPDF = 105,
        REMOVEDUPLICATE = 106,
        STATENODATA = 107,
        LANDINGVIEWPAGE = 108,
        LANDINGVIEWPDFPAGE = 109,
        LANDINGUPLOADPDFPAGE = 110,
        LANDINGALLPDFPAGE = 111,
        LANDINGPUBLISHREMOVEDUPLICATEPAGE = 112,
        REPLACEPDF = 113,
        CANCELDSAR = 114,
        REMOVEPDF =115,
        UNDOCANCEL = 116,
        VIEWDEPARTMENTUSERSCREEN = 117,
        SERVICENOWVIEWSCREEN = 118,
        UNDOREMOVEDUPLICATE = 119,
        UNDOPUBLISHDSAR = 120,
        DOWNLOAD = 121,
        CLOSEUPLOADTASKINSNOW = 122,
        CLOSEREVIEWTASKINSNOW = 123
    }
   // [dbo].[PublishStatusMaster]
    public enum PublishStatusType
    {
        None,
        ReadyToPublish,
        Published
    }

    //[dbo].[DuplicateCheckStatusMaster]
    public enum DuplicateCheckStatusType
    {
        None,
        MarkedDuplicate,
        UpdatedDuplicateToSTS
    }
    //[dbo].[DSARCancelStatusMaster]
    public enum DsarCancelType
    {
        None,
        ReadyToCancel,
        Cancelled
    }
}