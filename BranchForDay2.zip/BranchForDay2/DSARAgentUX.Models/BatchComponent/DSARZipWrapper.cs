﻿using System.IO;

namespace DSARAgentUX.Models
{
    public class DsarZipWrapper
    {
        public DsarInformation DsarValue { get; set; }
        public MemoryStream ZipInMemory { get; set; }
    }
}
