﻿using DSARAgentUX.Models.DataSubjectAccessRequests;

namespace DSARAgentUX.Models
{
    public class DsarInformation
    {
        public DsarStatusType Status { get; set; }
        public DuplicateCheckStatusType Duplicate { get; set; }
        public DsarCancelType DsarCancel { get; set; }
//
//        public PublishStatusType dsarpublish { get; set; }
        public string Reference { get; set; }
    }
}



