﻿using System.ComponentModel.DataAnnotations;

namespace DSARAgentUX.Models
{
    public class DsarRequestXmlModel
    {
    }
}