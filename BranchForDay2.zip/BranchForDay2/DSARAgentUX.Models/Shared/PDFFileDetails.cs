﻿using System;
using System.ComponentModel.DataAnnotations;
using DSARAgentUX.Models.DataSubjectAccessRequests;

namespace DSARAgentUX.Models
{
    public class PdfFileDetails
    {
        public int Id { get; set; }
        public string DsarReference { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentDescription { get; set; }
        public string ServiceNowTaskName { get; set; }
        public string PdfReference { get; set; }
        [Display(Name = "Uploaded File")] public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public PDFStatusType Status { get; set; }

        public string StatusFriendlyName => Status.ToString().Replace("_", " ").Replace("State ", "");

        public DateTime ModifiedDate { get; set; }
        public string ModifiedDate_Formatted { get; set; }
        public string ModifiedBy { get; set; }
    }
}