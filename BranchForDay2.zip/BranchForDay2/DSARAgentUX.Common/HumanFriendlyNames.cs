﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace DSARAgentUX.Common
{
    public static class HumanFriendlyNames
    {
        private static Dictionary<string, string> FriendlyNames => new Dictionary<string, string>
        {
            {"NotRequested", "Not Requested"},
            {"Requested", "Requested"},

            {"AffordabilityInformation", "Affordability Information"},
            {"AutomotiveInformation", "Automotive"},

            {"BackgroundCheckingInformation", "Background checking information"},
            {"BusinessAndCompanyInformationType", "Business And Company Information "},

            { "CreditAccountsTracingInformation", "Information used in tracing credit accounts"},
            {"CreditExpertAndFreeAccountInformation",
                 "Information about your CreditExpert subscription and free Experian account"
            },
            {"ComparisonServiceInformation", "Comparison Service Data"},

            {"DetailOfContactWithExperianInformation", "Details about your contact with us"},

            {"ExperianClientRelatedInformation", "Information relating to you as a client of Experian"},
            {"ExperianID", "ExperianID"},

            {"FraudDetectionInformationType", "Information related to fraud detection"},

            {"HistoricCreditReport", "Historic Credit Report Information"},
            {"HRInformation", "Experian Employee or Recruitment Candidate Information" },

            {"LimitedCompany", "Additional personal information for businesses you are associated with"},

            {"MarketingServices", "Experian Marketing Services"},
            {"NonLimitedCompany", "Additional personal information for businesses you are associated with"},

            {"UnclaimedAssetRegister", "Unclaimed asset register"},
            {"WebMonitoringInformation", "Information related to our web monitoring feature"},
            {"AudioRecordings", "Call Recording Information"}


        };

        public static string GetFriendyName(string key)
        {
            var sReturn = key;

            if (FriendlyNames.ContainsKey(key))
            {
                sReturn = FriendlyNames[key];
            }

            return sReturn;
        }


        public static List<string> GetServiceNowTaskName(string key)
        {
            List<string> sReturn = new List<string>();

            if (ServiceNowTaskName.ContainsKey(key))
            {
                sReturn = ServiceNowTaskName[key];
            }

            return sReturn;
        }

        public static List<int> GetPDFbyID(string key)
        {
            List<int> sReturn = new List<int>();

            if (DepartmentWithPDFMapping.ContainsKey(key))
            {
                sReturn = DepartmentWithPDFMapping[key];
            }

            return sReturn;
        }

        private static Dictionary<string, List<int>> DepartmentWithPDFMapping => new Dictionary<string, List<int>>
        {
            {"AdditionBusinessInformation", new List<int>() { 20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200,210,220,230,240,250,260,270,280,290,300,310,320,330,340,350,360,370,380,390,400,410,420,430,440,450,460,470,480,490,500,510,520,530,540,550,560}},
            {"AffordabilityInformation", new List<int>() { 580,590,600 }},
            {"MarketingServices", new List<int>() {570 }},
            {"BackgroundCheckingInformation", new List<int>() { 660 }},
            {"ComparisonServiceInformation", new List<int>() {740 }},
            {"ConsumerServices", new List<int>() {750,760,770,780,790 }},
            {"AutomotiveInformation", new List<int>() {720,730 }},
            {"HistoricCreditReport", new List<int>() {620,630}},
            {"WebMonitoringInformation", new List<int>() {650}},
            {"CreditAccountsTracingInformation", new List<int>() {820}},
            {"UnclaimedAssetRegister", new List<int>() {670}},
            {"HRInformation", new List<int>() {610}},
            {"ExperianID", new List<int>() {640}},
            {"ExperianClientRelatedInformation", new List<int>() {680,690,700,710}},
            {"DetailOfContactWithExperianInformation", new List<int>() {750,760,770,780,790}},
            {"CreditExpertAndFreeAccountInformation", new List<int>() {800,810}},
            {"FraudDetectionInformation", new List<int>() {830,840,850}},
            {"AudioRecordings", new List<int>() {860}}
        };


        private static Dictionary<string, List<string>> ServiceNowTaskName => new Dictionary<string, List<string>>
        {
            {"AdditionBusinessInformation", new List<string>() {"Client Services (Commercial & International Team)","BI EBA","BI PH"}},
            {"MarketingServices", new List<string>() {"DSAR EMS Targeting Data"}},
            {"AffordabilityInformation", new List<string>() {"DSAR Affordability & Open Banking Data","DSAR eCAPS Data","DSAR CATO Data"}},
            {"BackgroundCheckingInformation", new List<string>() {"DSAR EBC CV&TV Data"}},
            {"ComparisonServiceInformation", new List<string>() {"DSAR EBC CV&TV Data"}},
            {"ConsumerServices", new List<string>() {"DSAR R8 Data","DSAR Numero Data","DSAR ECHO Data","DSAR VOF_DQC Data","DSAR Salesforce Voyager Data"}},
            {"AutomotiveInformation", new List<string>() {"DSAR Vehicle AutoCheck","DSAR AutoCheck Data"}},
            {"HistoricCreditReport", new List<string>() {"DSAR Historic Credit Report Data","DSAR Historic Voters Roll Data"}},
            {"WebMonitoringInformation", new List<string>() {"DSAR Open & Dark Web Data"}},
            {"CreditAccountsTracingInformation", new List<string>() {"DSAR BT OSIS Data"}},
            {"UnclaimedAssetRegister", new List<string>() {"DSAR UAR Data"}},
            {"HRInformation", new List<string>() {"HR DSAR Data"}},
            {"ExperianID", new List<string>() {"DSAR IDaaS Identity Data"}},
            {"ExperianClientRelatedInformation", new List<string>() {"DSAR Global Salesforce CRM Data","DSAR BI EBA CRM Data", "DSAR EDQ Data", "DSAR Marketing client registration data"}},
            {"DetailOfContactWithExperianInformation", new List<string>() {"DSAR R8 Data","DSAR Numero Data","DSAR ECHO Data","DSAR VOF_DQC Data","DSAR Salesforce Voyager Data"}},
            {"CreditExpertAndFreeAccountInformation", new List<string>() {"DSAR CST Data","DSAR Corvette Data"}},
            {"FraudDetectionInformation", new List<string>() {"DSAR Hunter VOF Data","DSAR Prove ID Data","DSAR Payments BWA Data"}},
            {"AudioRecordings", new List<string>() { "Consumer Services"}}//TODO need to get department name from Snow team


        };




        public static List<string> LstofDepartments => new List<string>
        {
            {"AdditionBusinessInformation"},
            {"AffordabilityInformation"},
            {"MarketingServices"},
            {"BackgroundCheckingInformation"},
            {"ComparisonServiceInformation"},
            {"ConsumerServices"},
            {"AutomotiveInformation"},
            {"HistoricCreditReport" },
            {"WebMonitoringInformation"},
            {"CreditAccountsTracingInformation"},
            {"UnclaimedAssetRegister"},
            {"HRInformation"},
            {"ExperianID"},
            {"ExperianClientRelatedInformation"},
            {"DetailOfContactWithExperianInformation"},
            {"CreditExpertAndFreeAccountInformation"},
            {"FraudDetectionInformation"}
        };


    }
}