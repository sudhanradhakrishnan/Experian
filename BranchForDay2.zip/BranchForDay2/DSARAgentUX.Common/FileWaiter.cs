﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DSARAgentUX.Common
{
    public class FileWaiter
    {
        private Dictionary<string, DateTime> filesAwaitingProcessing;
        private TimeSpan fileSleepTime;
        private int maxRetryCount;

        public FileWaiter()
        {
            filesAwaitingProcessing = new Dictionary<string, DateTime>();
            fileSleepTime = TimeSpan.Parse(ConfigurationManager.AppSettings["FileSleepTime"]);
            maxRetryCount = Convert.ToInt32(ConfigurationManager.AppSettings["MaxRetryCount"]); 
        }

        public bool FileRestPeriodIsOver(string filePath)
        {
            DateTime addTime;

            if (!filesAwaitingProcessing.TryGetValue(filePath, out addTime))
            {
                return false;
            }

            if (addTime + fileSleepTime < DateTime.Now)
            {
                return true;
            }

            return false;
        }

        public void EnableFileToBeProcessed(string filePath)
        {
            filesAwaitingProcessing.Remove(filePath);
        }

        public bool fileCreatedOrChangedAndNotResting(FileSystemEventArgs eventArgs, string filePath)
        {
            if (filesAwaitingProcessing.ContainsKey(filePath))
            {
                return false;
            }

            if (fileCreatedOrChanged(eventArgs))
            {
                return true;
            }

            return false;
        }

        public void RestFile(string filePath)
        {
            filesAwaitingProcessing.Add(filePath, DateTime.Now);
        }

        public void waitForFileToBeReady(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("Cannot wait for a non-existant file", filePath);
            }

            int pollCount = 0;

            while (true)
            {
                pollCount++;

                try
                {
                    using (var s = new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None, 100))
                    {
                        break;
                    }
                }
                catch (IOException)
                {
                    if (pollCount > maxRetryCount)
                    {
                        throw new TimeoutException(String.Format("Maximum polling count of {0} exceeded.", maxRetryCount));
                    }

                    Thread.Sleep(5000);
                }
            }
        }

        private static bool fileCreatedOrChanged(FileSystemEventArgs eventArgs)
        {
            return eventArgs.ChangeType == WatcherChangeTypes.Changed || eventArgs.ChangeType == WatcherChangeTypes.Created;
        }

    }
}
