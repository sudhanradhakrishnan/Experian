﻿using System;
using System.Configuration;
using System.IO;
using System.Web;
using System.Xml;
using System.Xml.Linq;

namespace DSARAgentUX.Common
{
    public static class Helpers
    {
        public const string AudioRecording = "AudioRecordingsInformation";

        public static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["DSARCon"].ConnectionString;
        }

        public static string ConvertXmltoString(this XmlDocument xmlDoc)
        {
            using (var stringWriter = new StringWriter())
            {
                using (var xmlTextWriter = XmlWriter.Create(stringWriter))
                {
                    xmlDoc.WriteTo(xmlTextWriter);
                    xmlTextWriter.Flush();

                    return stringWriter.GetStringBuilder().ToString();
                }
            }
        }

        public static bool IsFileSizeExceedsLimit(this HttpPostedFileBase file)
        {
            var result = false;
            int allowedFileSize;
            int.TryParse(ConfigurationManager.AppSettings["Agent:PdfSizeLimitInMB"], out allowedFileSize);

            var diff = file.ContentLength - ((allowedFileSize * 1024) * 1024);

            if (diff > 0)
            {
                result = true;
            }

            return result;
        }
        public static bool IsFileSizeExceedsLimit(this byte[] file)
        {
            var result = false;
            int allowedFileSize;
            int.TryParse(ConfigurationManager.AppSettings["Agent:PdfSizeLimitInMB"], out allowedFileSize);

            var diff = file.Length - ((allowedFileSize * 1024) * 1024);

            if (diff > 0)
            {
                result = true;
            }

            return result;
        }

        public static bool HasAudioAndDepartmentSource(XmlNode dsarNode)
        {
            bool datasourcesDosentHaveAudio = false;
            using (TextReader reader = new StringReader(dsarNode.OuterXml))
            {
                var dsarxDocument = XDocument.Load(reader);
                var audioRecording = GetElement(dsarxDocument, AudioRecording);
                foreach (string department in HumanFriendlyNames.LstofDepartments)
                {
                    if (GetElement(dsarxDocument, department) != null && audioRecording != null)
                        datasourcesDosentHaveAudio = true;
                }
            }

            return datasourcesDosentHaveAudio;
        }

        private static XElement GetElement(XDocument doc, string elementName)
        {
            foreach (XNode node in doc.DescendantNodes())
            {
                if (node is XElement)
                {
                    XElement element = (XElement)node;
                    if (element.Name.LocalName.Equals(elementName))
                        return element;
                }
            }
            return null;
        }


    }
}