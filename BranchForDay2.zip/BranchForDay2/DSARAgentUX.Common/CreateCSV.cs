﻿using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DSARAgentUX.Common
{
    public class CsvRow : List<string>
    {
        public string LineText { get; set; }
    }

    public class CsvFileWriter : StreamWriter
    {
        public CsvFileWriter(Stream stream)
            : base(stream)
        {
        }

        public CsvFileWriter(string filename)
            : base(filename)
        {
        }

        public void WriteRow(CsvRow row)
        {
            var builder = new StringBuilder();
            var firstColumn = true;

            foreach (var value in row)
            {
                if (!firstColumn)
                    builder.Append(',');

                if (value.IndexOfAny(new[] {'"', ','}) != -1)
                {
                    builder.AppendFormat("\"{0}\"", value.Replace("\"", "\"\""));
                }
                else
                {
                    builder.Append(value);
                }

                firstColumn = false;
            }

            row.LineText = builder.ToString();
            WriteLine(row.LineText);
        }
    }
}