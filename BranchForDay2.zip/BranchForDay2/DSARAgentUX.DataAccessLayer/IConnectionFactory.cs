﻿namespace DSARAgentUX.DataAccessLayer
{
    /*
    public interface IConnectionFactory
    {
        IDbConnection Create();
    }*/
}