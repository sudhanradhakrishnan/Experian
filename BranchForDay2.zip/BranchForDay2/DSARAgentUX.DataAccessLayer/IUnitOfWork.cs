﻿namespace DSARAgentUX.DataAccessLayer
{
    //public interface IUnitOfWork
    //{
    //    void Dispose();
    //    void SaveChanges();
    //}
}