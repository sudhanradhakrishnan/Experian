USE [DSAR_SR]
GO
/****** Object:  StoredProcedure [dbo].[UploadPostalPDF]    Script Date: 27/07/2018 14:52:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =================================================================================
-- Program Name: DSAR
-- Author: Maneesh
-- Description: This SP is to upload Postal PDF into UploadPostalPDF table
-- InParameter: FileName and FileContent
-- OutParameter: @RequestStatus will say the Status of the Operation like 1= inserted,2= Updated,0 = Error Occured
-- Created Date: 27-07-2018
-- Revision History :
-----------------------------------------------------------------
-- =================================================================================
-- Modified Date		Author		Reason 
-- =================================================================================

-- ==================================================================================  
-- ==================================================================================
Create PROCEDURE [dbo].[UploadPostalPDF]
(
	@DSARReference varchar(8),	
    @pdf_reference varchar(8), 
	@FileName varchar(60), 	
	@FileContent varBinary(Max),	
	@ModifiedBy varchar(100), 
	@Status int,
	@RequestStatus INT OUTPUT	
)
AS
DECLARE @ModifierName  varchar(50)
set @ModifierName = (CASE WHEN LEN(@ModifiedBy) > 0 THEN	 @ModifiedBy ELSE 'Anonymous' END)
IF EXISTS (SELECT * FROM dbo.PostalPDFUpload WHERE pdf_Reference=@pdf_reference AND DSARReference=@DSARReference)
   BEGIN
   	   BEGIN TRY		
			UPDATE dbo.PostalPDFUpload 
			SET Status= @Status,FileName=@FileName,FileContent=@FileContent, 
			ModifiedBy = @ModifierName,
			ModifiedDate=getdate() WHERE DSARReference = @DSARReference AND pdf_Reference = @pdf_reference 
			 SET  @RequestStatus = 2	-- PDF Updated	
			
		END TRY
		BEGIN CATCH
			 SET  @RequestStatus = 0;  -- 'Error Occured While Updating'
		END CATCH

	END
ELSE
    BEGIN		
		 BEGIN TRY		
			Insert into dbo.PostalPDFUpload values(@DSARReference,@pdf_reference,@FileName,@FileContent,@Status,getdate(), @ModifierName)  			
			SET  @RequestStatus = 1 -- PDF inserted 			
		END TRY
		BEGIN CATCH
			 SET  @RequestStatus = -1;  -- 'Error Occured While Inserting'
		END CATCH		
	 END
