
GO
/****** Object:  StoredProcedure [dbo].[CaptureDSARAudit]    Script Date: 01/05/2018 16:29:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =================================================================================
-- Program Name: DSAR
-- Author: C51323A
-- Description: This SP is used to Capture DSAR Event information
-- InParameter: DSARReferenceId pdfreference Username Operation
-- OutParameter: 
-- Created Date: 09-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-----------------------------------------------------------------
-- ==================================================================================
ALTER PROCEDURE [dbo].[CaptureDSARAudit]
(
	@DSARReferenceId VARCHAR(8),
	@pdfreference VARCHAR(8),	
	@Username VARCHAR(50),
	@Operation int,
	@ModifyedPDFName VARCHAR(50),
	@ActualPDFName  VARCHAR(50),
	@IsPDFuploaded bit
)
AS
BEGIN
 DECLARE @newId As int
    BEGIN TRY
	Insert into dbo.Audit ([DSARReference],
							[pdf_reference],
							[Username],
							[Operation],
							[ActivityTime])
					values(@DSARReferenceId,@pdfreference,@Username,@Operation,getdate())
	select @newId = Scope_Identity()
		IF @IsPDFuploaded = 1		
				INSERT INTO [dbo].[PDFAudit]
								   ([AuditID]
								   ,[ActualName]
								   ,[ModifyedName]
								   ,[ActivityTime])
							 VALUES(@newId,@ActualPDFName,@ModifyedPDFName,getdate())			
		
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRANSACTION 
        END
    END CATCH  
END
