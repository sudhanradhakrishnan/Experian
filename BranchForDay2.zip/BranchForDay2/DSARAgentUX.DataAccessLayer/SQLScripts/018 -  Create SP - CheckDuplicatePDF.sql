USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[CheckDuplicatePDF]    Script Date: 25/07/2018 13:06:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =================================================================================
-- Program Name: DSAR
-- Author: C51053A
-- Description: This SP is to checking whether pdf existed or not
-- InParameter: DSARReference and pdf_reference
-- OutParameter: @IsTrue boolean 
-- Created Date: 13-07-2018
--
-----------------------------------------------------------------
-- =================================================================================
-- Created Date		Author		Reason 
-- =================================================================================
-- 13-07-2018		C51053A		Checking whether pdf existed or not
-- ==================================================================================  
-- ==================================================================================
CREATE PROCEDURE [dbo].[CheckDuplicatePDF]
     (
      @DSARReference varchar(8),	
	  @pdf_reference varchar(8)
	  )
AS
BEGIN
      SET NOCOUNT ON;
 
     Select Count(Id) from PDFUpload
                        WHERE DSARReference = @DSARReference and  pdf_Reference = @pdf_reference 
						--and DATALENGTH(FileContent) > 0 
END
GO


