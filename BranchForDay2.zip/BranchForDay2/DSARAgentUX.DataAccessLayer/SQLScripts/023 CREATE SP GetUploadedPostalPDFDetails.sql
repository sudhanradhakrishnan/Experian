USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[GetUploadedPostalPDFDetails]    Script Date: 27/07/2018 14:17:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






-- ===========================================================================================
-- Program Name: GetUploadedPostalPDFDetails
-- Author: C51014A, Maneesh
-- Description: This SP is to pull information for list Postal PDF row content Data using DSAR Referance 
-- InParameter: FileNames and FileContents
-- OutParameter: 
-- Created Date: 04-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-- Maneesh >> please dont load postal pdf content in normal queries size may vary from 10 to 50 mb which will slow the query
-- Removed all Report group and department reference
-----------------------------------------------------------------
-- =============================================================================================
CREATE PROCEDURE [dbo].[GetUploadedPostalPDFDetails]
(
	@DSARReferenceNumber varchar(60),
	@PDFReference varchar(50)
)
AS
BEGIN
	 
SELECT 
			'' as DepartmentNumber,
			'' as DepartmentName,
			'' as DepartmentFriendlyName,
			dsar.DSARReferenceId,
			up.id as PDFId,
			null as PDFReference,
			dsar.Status as DSARStatus , 
			dsar.publish,
			dsar.duplicate,
            up.filename As FileName,
			'' as DepartmentDescription,
			up.Status as PDFstatus,
			ModifiedBy=(CASE WHEN LEN(up.ModifiedBy)>0 THEN up.ModifiedBy ELSE 'Anonymous' END),
			up.ModifiedDate
    FROM    
			DataSubjectAccessRequest as dsar
			INNER JOIN PostalPDFUpload as up on dsar.DSARReferenceId = up.DSARReference
			--and up.pdf_reference = @PDFReference
	
    WHERE 
			dsar.DSARReferenceId = @DSARReferenceNumber and up.pdf_reference = @PDFReference

END


GO


