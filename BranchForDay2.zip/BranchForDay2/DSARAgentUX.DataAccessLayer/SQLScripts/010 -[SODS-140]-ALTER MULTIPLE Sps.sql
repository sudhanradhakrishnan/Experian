USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[GetAllUploadedPDFDetails]    Script Date: 15/05/2018 12:05:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- ===========================================================================================
-- Program Name: GetDepartmentwisePDFDetailsByDSARRef
-- Author: C51014A, Maneesh
-- Description: This SP is to pull information for list  PDF row content Data using DSAR Referance 
-- InParameter: FileNames and FileContents
-- OutParameter: 
-- Created Date: 04-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-----------------------------------------------------------------
-- =============================================================================================
ALTER PROCEDURE [dbo].[GetAllUploadedPDFDetails]
(
	@DSARReferenceNumber varchar(60)
)
AS
BEGIN
	 
	SELECT 
			'' as DepartmentNumber,
			'' as DepartmentName,
			'' as DepartmentFriendlyName,
			up.dsarreference,
			up.id as PDFId,
			up.pdf_reference as PDFReference,
			dsar.Status as DSARStatus , 			
			dsar.Publish as PublishStatus,
			dsar.Duplicate as DuplicateStatus,
            up.filename As FileName,
			'' as DepartmentDescription,
			--up.filecontent,
			up.Status as PDFstatus,
			ModifiedBy=(CASE WHEN LEN(up.ModifiedBy)>0 THEN up.ModifiedBy ELSE 'Anonymous' END),
			up.ModifiedDate
    FROM    
			DataSubjectAccessRequest as dsar
			INNER JOIN PDFUpload as up  on up.DSARReference = dsar.DSARReferenceId 	
	        
	WHERE dsar.DSARReferenceId  = @DSARReferenceNumber 

   
END

GO

USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[GetListOfPDFForReadyToPublishDsars]    Script Date: 15/05/2018 12:05:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- ===========================================================================================
-- Program Name: GetListOfPDFForDsars
-- Author: C51014A, Maneesh
-- Description: This SP is to pull information for list  File content Data using DSAR Referance 
-- InParameter: FileNames and FileContents
-- OutParameter: 
-- Created Date: 04-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-----------------------------------------------------------------
-- =============================================================================================
ALTER PROCEDURE [dbo].[GetListOfPDFForReadyToPublishDsars]
(
	@DSARReferenceNumber varchar(60)
)
AS
BEGIN
    BEGIN TRANSACTION;
    BEGIN TRY		 
		 SELECT [Id]
        ,[DSARReference]
        ,[pdf_reference] as PdfReference
        ,[FileName]
        ,[Status]
        ,[ModifiedDate]
        ,ModifiedBy=(CASE WHEN LEN(ModifiedBy)>0 THEN ModifiedBy ELSE 'Anonymous' END)
  FROM   [dbo].[PDFUpload]  
  WHERE  [DSARReference] = @DSARReferenceNumber

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRANSACTION 
        END
    END CATCH
    COMMIT TRANSACTION 
END;
GO

USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[GetPDFStatus]    Script Date: 15/05/2018 12:07:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =================================================================================
-- Program Name: DSAR
-- Author: C51053A
-- Description:This SP is to pull out PDF Status from the database
-- InParameter:DSARReferenceId,pdf_referenceId
-- OutParameter: PDFStatus
-- Created Date: 09-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-----------------------------------------------------------------
-- ==================================================================================
ALTER PROCEDURE [dbo].[GetPDFStatus]
(
	@DSARReference varchar(8),
	@pdf_reference varchar(8)
)
AS 
    		 
		select up.dsarreference,up.id as pdfId, up.filename,
		 up.Status as PDFstatus,ModifiedBy=(CASE WHEN LEN(up.ModifiedBy)>0 THEN up.ModifiedBy ELSE 'Anonymous' END) from PDFUpload as up
         inner join DataSubjectAccessRequest as dsar on up.DSARReference = dsar.DSARReferenceId 
		 where up.DSARReference = @DSARReference AND up.pdf_reference =@pdf_reference

GO

USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[GetUploadedPDFDetails]    Script Date: 15/05/2018 12:08:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





ALTER PROCEDURE [dbo].[GetUploadedPDFDetails]
(
	@DSARReferenceNumber varchar(60),
	@PDFReference varchar(50)
)
AS
BEGIN
	 
SELECT 
			'' as DepartmentNumber,
			'' as DepartmentName,
			'' as DepartmentFriendlyName,
			dsar.DSARReferenceId,
			up.id as PDFId,
			null as PDFReference,
			dsar.Status as DSARStatus , 
			dsar.publish,
			dsar.duplicate,
            up.filename As FileName,
			'' as DepartmentDescription,
			up.Status as PDFstatus,
			ModifiedBy=(CASE WHEN LEN(up.ModifiedBy)>0 THEN up.ModifiedBy ELSE 'Anonymous' END),
			up.ModifiedDate
    FROM    
			DataSubjectAccessRequest as dsar
			INNER JOIN PDFUpload as up on dsar.DSARReferenceId = up.DSARReference
			--and up.pdf_reference = @PDFReference
	
    WHERE 
			dsar.DSARReferenceId = @DSARReferenceNumber and up.pdf_reference = @PDFReference

END


GO

USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[UpdatePDFStatus]    Script Date: 15/05/2018 12:09:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =================================================================================
-- Program Name: DSAR
-- Author: C51052A
-- Description: This SP is to update the status of the DSARReport in DataSubjectAccessRequest table
-- InParameter: Status
-- OutParameter: 
-- Created Date: 30-03-2018
-- Revision History :
-----------------------------------------------------------------
-- ==================================================================================
ALTER PROCEDURE [dbo].[UpdatePDFStatus]
(
	@DSARReference varchar(50),
	@Status INT,
	@FileContent varBinary(Max),
	@FileName  varchar(60) ,
	@PDFReference varchar(8),
	@ModifiedBy varchar(100)
)
AS
BEGIN

    BEGIN TRANSACTION;
    SAVE TRANSACTION updatePDFStatus;
	SELECT Id from dbo.PDFUpload where DSARReference=@DSARReference and pdf_reference=@PDFReference
    IF (@@ROWCOUNT<1)
	  BEGIN	
			Insert into dbo.PDFUpload values(@DSARReference,@PDFReference,@FileName,@FileContent,@Status,getdate(), (CASE WHEN LEN(@ModifiedBy)>0 THEN @ModifiedBy ELSE 'Anonymous' END)) 
	  END
	ELSE
    BEGIN TRY
		 	Update dbo.PDFUpload SET DSARReference=@DSARReference,
									 pdf_reference=@PDFReference,
									 FileName=@FileName,
									 FileContent=@FileContent,
									 Status=@Status,
									 ModifiedDate=getdate(),
									 ModifiedBy= (CASE WHEN LEN(@ModifiedBy)>0 THEN @ModifiedBy ELSE 'Anonymous' END)  	
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRANSACTION updatePDFStatus; -- rollback to updateDSARStatus
        END
    END CATCH
    COMMIT TRANSACTION 
END;
GO

USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[UploadPDF]    Script Date: 15/05/2018 12:09:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =================================================================================
-- Program Name: DSAR
-- Author: C51323A
-- Description: This SP is to upload PDF into UpLoadPDF table
-- InParameter: FileName and FileContent
-- OutParameter: 
-- Created Date: 15-03-2018
-- Revision History :
-- Modified Date : 18-04-2018
-- Description	:Added Modify by date.
-----------------------------------------------------------------
-- ==================================================================================
ALTER PROCEDURE [dbo].[UploadPDF]
(
	@DSARReference varchar(8),	
    @pdf_reference varchar(8), 
	@FileName varchar(60), 	
	@FileContent varBinary(Max),	
	@ModifiedBy varchar(100), 
	@Status int

	
)
AS
BEGIN

    BEGIN TRANSACTION;
    SAVE TRANSACTION uploadPDF;
   IF EXISTS (SELECT * FROM dbo.PDFUpload WHERE pdf_Reference=@pdf_reference AND DSARReference=@DSARReference)
   BEGIN

  UPDATE dbo.PDFUpload SET Status=@Status,FileName=@FileName,FileContent=@FileContent,ModifiedBy= (CASE WHEN LEN(@ModifiedBy)>0 THEN @ModifiedBy ELSE 'Anonymous' END),ModifiedDate=getdate() WHERE DSARReference =@DSARReference AND pdf_Reference=@pdf_reference 
END
ELSE

    BEGIN TRY
		Insert into dbo.PDFUpload values(@DSARReference,@pdf_reference,@FileName,@FileContent,@Status,getdate(), (CASE WHEN LEN(@ModifiedBy)>0 THEN @ModifiedBy ELSE 'Anonymous' END))  
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRANSACTION uploadPDF; -- rollback to uploadPDF
        END
    END CATCH
    COMMIT TRANSACTION 
END;
GO

USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[GetUploadedPDFDetails]    Script Date: 15/05/2018 12:21:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





-- ===========================================================================================
-- Program Name: GetPDFDetailsByDSARRefAndPDFRef
-- Author: C51014A, Maneesh
-- Description: This SP is to pull information for list  PDF row content Data using DSAR Referance 
-- InParameter: FileNames and FileContents
-- OutParameter: 
-- Created Date: 04-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-- Maneesh >> please dont load pdf content in normal queries size may vary from 10 to 50 mb which will slow the query
-- Removed all Report group and department reference
-----------------------------------------------------------------
-- =============================================================================================
ALTER PROCEDURE [dbo].[GetUploadedPDFDetails]
(
	@DSARReferenceNumber varchar(60),
	@PDFReference varchar(50)
)
AS
BEGIN
	 
SELECT 
			'' as DepartmentNumber,
			'' as DepartmentName,
			'' as DepartmentFriendlyName,
			dsar.DSARReferenceId,
			up.id as PDFId,
			null as PDFReference,
			dsar.Status as DSARStatus , 
			dsar.publish,
			dsar.duplicate,
            up.filename As FileName,
			'' as DepartmentDescription,
			up.Status as PDFstatus,
			ModifiedBy=(CASE WHEN LEN(up.ModifiedBy)>0 THEN up.ModifiedBy ELSE 'Anonymous' END),
			up.ModifiedDate
    FROM    
			DataSubjectAccessRequest as dsar
			INNER JOIN PDFUpload as up on dsar.DSARReferenceId = up.DSARReference
			--and up.pdf_reference = @PDFReference
	
    WHERE 
			dsar.DSARReferenceId = @DSARReferenceNumber and up.pdf_reference = @PDFReference

END


GO

