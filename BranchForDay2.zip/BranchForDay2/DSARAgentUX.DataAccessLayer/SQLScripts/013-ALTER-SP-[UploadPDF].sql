USE [DSAR]
GO
/****** Object:  StoredProcedure [dbo].[UploadPDF]    Script Date: 07/06/2018 16:04:43 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =================================================================================
-- Program Name: DSAR
-- Author: C51323A
-- Description: This SP is to upload PDF into UpLoadPDF table
-- InParameter: FileName and FileContent
-- OutParameter: 
-- Created Date: 15-03-2018
-- Revision History :
-- Modified Date : 18-04-2018
-- Description	:Added Modify by date.
-----------------------------------------------------------------
-- ==================================================================================
ALTER PROCEDURE [dbo].[UploadPDF]
(
	@DSARReference varchar(8),	
    @pdf_reference varchar(8), 
	@FileName varchar(60), 	
	@FileContent varBinary(Max),	
	@ModifiedBy varchar(100), 
	@Status int,
	@RequestStatus INT OUTPUT	
)
AS
DECLARE @ModifierName  varchar(50)
SET @ModifierName = (CASE WHEN LEN(@ModifiedBy) > 0 THEN @ModifiedBy ELSE 'Anonymous' END)

IF EXISTS (SELECT * FROM dbo.PDFUpload WHERE pdf_Reference=@pdf_reference AND DSARReference=@DSARReference)
   BEGIN
		UPDATE dbo.PDFUpload 
			SET Status= @Status, FileName=@FileName, FileContent=@FileContent
				, ModifiedBy = @ModifierName, ModifiedDate=getdate() 
		WHERE DSARReference =@DSARReference AND pdf_Reference=@pdf_reference 
		SET  @RequestStatus = 2	-- PDF Updated	
	END
ELSE
    BEGIN
		INSERT INTO dbo.PDFUpload 
			values(@DSARReference,@pdf_reference,@FileName,@FileContent,@Status,getdate(), @ModifierName)  
		SET  @RequestStatus = 1 -- PDF inserted 
     END