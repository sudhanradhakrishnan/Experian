
IF COL_LENGTH('dbo.DataSubjectAccessRequest', 'Purged') IS NULL
BEGIN
	
	ALTER TABLE [dbo].[DataSubjectAccessRequest] ADD [Purged] [bit] NULL;
    
END

