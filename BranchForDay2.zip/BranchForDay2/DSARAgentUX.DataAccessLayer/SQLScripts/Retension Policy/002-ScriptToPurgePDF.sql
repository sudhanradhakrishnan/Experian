
/****** Object:  StoredProcedure [dbo].[PurgeDsarReports]    Script Date: 04/07/2018 14:21:06 ******/
IF OBJECT_ID('PurgeDsarReports', 'P') IS NOT NULL
BEGIN
	PRINT 'Procedure Found'
    DROP PROCEDURE [dbo].[PurgeDsarReports]
END
GO

/****** Object:  StoredProcedure [dbo].[PurgeDsarReports]    Script Date: 02/07/2018 14:29:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[PurgeDsarReports]
( @PeriodInDays int )
AS 
  		 
	DELETE w  FROM PDFUpload w
		INNER JOIN DataSubjectAccessRequest e ON w.DSARReference=e.DSARReferenceId

	WHERE IsNull(e.Purged, 0) = 0
		and e.Publish = 2 
		and e.Status = 1 
		and e.[ModifiedDate] <= DateAdd("d", 0-@PeriodInDays, GETDATE()) 

	UPDATE  DataSubjectAccessRequest 
		SET Purged = 1
	WHERE IsNull(Purged, 0) = 0
		and Publish=2 
		and Status=1
		and ModifiedDate <= DateAdd("d", 0-@PeriodInDays, GETDATE() ) 


-- Add statement to delete logs if necessary

GO

