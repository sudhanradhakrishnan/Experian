	Select w.*
FROM PDFUpload w
INNER JOIN DataSubjectAccessRequest e
  ON w.DSARReference=e.DSARReferenceId
WHERE e.[ModifiedDate] <= DateAdd("d",-365,GETDATE()) and e.Publish=2 and e.Status=1


