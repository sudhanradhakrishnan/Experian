﻿USE [DSAR]
GO

/****** Object:  StoredProcedure [dbo].[GetDSARRegistrationInformation]    Script Date: 26/04/2018 15:37:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Batch submitted through debugger: SQLQuery10.sql|7|0|C:\Users\C07198A\AppData\Local\Temp\6\~vs2D60.sql
-- =============================================
-- Author:		Experian
-- Create date: 26/04/2018
-- Description:	To get DSAR registration information for list of reference IDs
-- =============================================
CREATE PROCEDURE [dbo].[GetDSARRegistrationInformation]
	-- Add the parameters for the stored procedure here
	(
		@DSARReferenceId varchar(2048)
	)
	AS
BEGIN
	SET NOCOUNT ON;
	Declare @tempRefList nvarchar(2048)
	Declare @resultRefList nvarchar(2048)
	Declare @firstItem int
	Set @tempRefList = @DSARReferenceId
	Set @resultRefList = ''
	Set @firstItem = 1
	WHILE LEN(@tempRefList) > 0
		BEGIN
			Declare @CurrRef varchar(20)
			IF CHARINDEX(',', @tempRefList) > 0
			BEGIN
				Set @CurrRef = SUBSTRING(@tempRefList, 0, CHARINDEX(',', @tempRefList))
				Set @tempRefList = SUBSTRING(@tempRefList, CHARINDEX(',', @tempRefList) + 1, LEN(@tempRefList))
				If @firstItem = 1
					Set @resultRefList =  @resultRefList + '''' + @CurrRef + ''''
				Else
					Set @resultRefList =  @resultRefList + ',''' + @CurrRef + ''''
				Set @firstItem = 0
			END
			ELSE
			BEGIN
				set @CurrRef = @tempRefList
				set @tempRefList = ''
				If @firstItem = 1
					Set @resultRefList =  @resultRefList + '''' + @CurrRef + ''''
				Else
					Set @resultRefList =  @resultRefList + ',''' + @CurrRef + ''''
				Set @firstItem = 0
			END
		END
	
Declare @s1 nvarchar(2048)

set @s1 = 'select [DSARReferenceId], [RegInformationXML] from [DSARRegistrationInformation]
where DSARReferenceId in (' + @resultRefList +  ' )'

exec sp_executesql @s1

END


GO


