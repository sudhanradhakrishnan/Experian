USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[GetAllUploadedPostalPDFDetails]    Script Date: 27/07/2018 14:11:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





-- ===========================================================================================
-- Program Name: GetAllUploadedPostalPDFDetails
-- Author: C51014A, Maneesh
-- Description: This SP is to pull information for list  postal PDF row content Data using DSAR Referance 
-- InParameter: FileNames and FileContents
-- OutParameter: 
-- Created Date: 04-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-----------------------------------------------------------------
-- =============================================================================================
CREATE PROCEDURE [dbo].[GetAllUploadedPostalPDFDetails]
(
	@DSARReferenceNumber varchar(60)
)
AS
BEGIN
	 
	SELECT 
			'' as DepartmentNumber,
			'' as DepartmentName,
			'' as DepartmentFriendlyName,
			up.dsarreference,
			up.id as PDFId,
			up.pdf_reference as PDFReference,
			dsar.Status as DSARStatus , 			
			dsar.Publish as PublishStatus,
			dsar.Duplicate as DuplicateStatus,
            up.filename As FileName,
			'' as DepartmentDescription,
			--up.filecontent,
			up.Status as PDFstatus,
			ModifiedBy=(CASE WHEN LEN(up.ModifiedBy)>0 THEN up.ModifiedBy ELSE 'Anonymous' END),
			up.ModifiedDate
    FROM    
			DataSubjectAccessRequest as dsar
			INNER JOIN PostalPDFUpload as up  on up.DSARReference = dsar.DSARReferenceId 	
	        
	WHERE dsar.DSARReferenceId  = @DSARReferenceNumber 

   
END

GO


