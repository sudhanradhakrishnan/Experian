USE [DSAR_SR]
GO

/****** Object:  Table [dbo].[PostalPDFUpload]    Script Date: 27/07/2018 10:16:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PostalPDFUpload](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DSARReference] [varchar](8) NOT NULL,
	[pdf_reference] [varchar](8) NOT NULL,
	[FileName] [varchar](60) NULL,
	[FileContent] [varbinary](max) NULL,
	[Status] [int] NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](100) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[PostalPDFUpload] ADD  DEFAULT ((-1)) FOR [Status]
GO


