/****** Object:  StoredProcedure [dbo].[CheckDuplicateDSAR]    Script Date: 04/05/2018 15:25:36 ******/
DROP PROCEDURE [dbo].[CheckDuplicateDSAR]
GO

/****** Object:  StoredProcedure [dbo].[CheckDuplicateDSAR]    Script Date: 04/05/2018 15:25:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
-- =================================================================================  
-- Program Name: DSAR  
-- Author: C51053A  
-- Description: This SP is to Check Duplicate DSAR
-- InParameter: DSARReferenceId    
-- OutParameter: @IsTrue boolean  
-- Created Date: 03-05-2018  
-- Revision History :  
-- Modified Date Modified By version Description  
-----------------------------------------------------------------  
-- ==================================================================================  
CREATE PROCEDURE [dbo].[CheckDuplicateDSAR]  
(  
 @DSARReferenceId varchar(8),
  @IsTrue BIT OUTPUT  
)  
AS   
BEGIN    
IF EXISTS (Select DSARReferenceId from DataSubjectAccessRequest where DSARReferenceId = @DSARReferenceId )
    SET @IsTrue = 0x1
ELSE
    SET @IsTrue = 0x0
END
  
GO
