USE [master]
GO
GRANT ADMINISTER BULK OPERATIONS TO [bpmsruntime];
GO
EXEC master..sp_addsrvrolemember @loginame = N'bpmsruntime', @rolename = N'sysadmin'
GO