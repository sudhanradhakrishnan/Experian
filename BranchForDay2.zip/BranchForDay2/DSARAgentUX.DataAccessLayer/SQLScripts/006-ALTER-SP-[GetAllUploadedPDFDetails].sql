-- ===========================================================================================
-- Program Name: GetDepartmentwisePDFDetailsByDSARRef
-- Author: C51014A, Maneesh
-- Description: This SP is to pull information for list  PDF row content Data using DSAR Referance 
-- InParameter: FileNames and FileContents
-- OutParameter: 
-- Created Date: 04-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-----------------------------------------------------------------
-- =============================================================================================
ALTER PROCEDURE [dbo].[GetAllUploadedPDFDetails]
(
	@DSARReferenceNumber varchar(60)
)
AS
BEGIN
	 
	SELECT 
			'' as DepartmentNumber,
			'' as DepartmentName,
			'' as DepartmentFriendlyName,
			up.dsarreference,
			up.id as PDFId,
			up.pdf_reference as PDFReference,
			dsar.Status as DSARStatus , 			
			dsar.Publish as PublishStatus,
			dsar.Duplicate as DuplicateStatus,
            up.filename As FileName,
			'' as DepartmentDescription,
			--up.filecontent,
			up.Status as PDFstatus,
			up.ModifiedBy,
			up.ModifiedDate
    FROM    
			DataSubjectAccessRequest as dsar
			INNER JOIN PDFUpload as up  on up.DSARReference = dsar.DSARReferenceId 	
	        
	WHERE dsar.DSARReferenceId  = @DSARReferenceNumber 

   
END

