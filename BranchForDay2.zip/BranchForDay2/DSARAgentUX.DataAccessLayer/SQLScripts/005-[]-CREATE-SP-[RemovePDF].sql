USE [DSAR_SR]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =================================================================================
-- Program Name: DSAR
-- Author: C51014A
-- Description: This SP is to remove PDF against DataSubjectAccessRequest
-- InParameter: Status
-- OutParameter: 
-- Created Date: 30-03-2018
-- Revision History :
-----------------------------------------------------------------
-- ==================================================================================
CREATE PROCEDURE [dbo].[RemovePDF]
(
	@DSARReference varchar(50),
	@PDFReference varchar(8),
	@ModifiedBy varchar(100)
)
AS
BEGIN

    BEGIN TRANSACTION;
    SAVE TRANSACTION updatePDFStatus;

    BEGIN TRY
			DELETE FROM PDFUpload where DSARReference = @DSARReference and pdf_reference=@PDFReference;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRANSACTION updatePDFStatus; -- rollback to updateDSARStatus
        END
    END CATCH
    COMMIT TRANSACTION 
END;
GO


