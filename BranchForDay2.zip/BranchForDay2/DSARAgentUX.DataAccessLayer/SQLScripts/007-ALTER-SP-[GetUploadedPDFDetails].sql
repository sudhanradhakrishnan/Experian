-- ===========================================================================================
-- Program Name: GetPDFDetailsByDSARRefAndPDFRef
-- Author: C51014A, Maneesh
-- Description: This SP is to pull information for list  PDF row content Data using DSAR Referance 
-- InParameter: FileNames and FileContents
-- OutParameter: 
-- Created Date: 04-04-2018
-- Revision History :
-- Modified Date Modified By version Description
-- Maneesh >> please dont load pdf content in normal queries size may vary from 10 to 50 mb which will slow the query
-- Removed all Report group and department reference
-----------------------------------------------------------------
-- =============================================================================================
ALTER PROCEDURE [dbo].[GetUploadedPDFDetails]
(
	@DSARReferenceNumber varchar(60),
	@PDFReference varchar(50)
)
AS
BEGIN
	 
SELECT 
			'' as DepartmentNumber,
			'' as DepartmentName,
			'' as DepartmentFriendlyName,
			dsar.DSARReferenceId,
			up.id as PDFId,
			null as PDFReference,
			dsar.Status as DSARStatus , 
			dsar.publish,
			dsar.duplicate,
            up.filename As FileName,
			'' as DepartmentDescription,
			up.Status as PDFstatus,
			up.ModifiedBy,
			up.ModifiedDate
    FROM    
			DataSubjectAccessRequest as dsar
			INNER JOIN PDFUpload as up on dsar.DSARReferenceId = up.DSARReference
			--and up.pdf_reference = @PDFReference
	
    WHERE 
			dsar.DSARReferenceId = @DSARReferenceNumber and up.pdf_reference = @PDFReference

END


