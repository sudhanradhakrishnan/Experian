Drop table Departments


CREATE TABLE [dbo].[Department](
              [Code] [nvarchar](50) NOT NULL,
       [Name] [nvarchar](50) NOT NULL,
       [Description] [nvarchar](500) NULL
) ON [PRIMARY]
GO

INSERT INTO [Department] ( code , Name , Description )
VALUES ( '001', 'HR', 'Human Resources' )
, ( '02', 'Benefits', 'Benefits' )
, ( '03', 'INsurance ', 'INsurance  Services ' )


CREATE TABLE [dbo].[ReportGroup]
(
       Pdf_Reference [nvarchar](50) NOT NULL
       , Department [nvarchar](50) NOT NULL
       , FriendlyName [nvarchar](50) NOT NULL
)


INSERT INTO ReportGroup ( Pdf_Reference , Department , FriendlyName )
VALUES ( '001', '001', 'EmploymentHistory' )
, ( '002', '001', 'Benefits' )
, ( '003', '001', 'SALARY' )
, ( '004', '002', 'Affordabilty' )
, ( '005', '002', 'Renewal' )


CREATE TABLE [dbo].[PDFUpload](
       
       [Id] [int] IDENTITY(1,1) NOT NULL,
       
       [DSARReference] [varchar](8) NOT NULL,
       pdf_reference [varchar](8) NOT NULL,
       
       [FileName] [varchar](60) NULL,
       [FileContent] [varbinary](max) NULL,
       
       -- [DepartID] [varchar](60) NOT NULL,
       
       
       [ModifiedDate] [datetime]  NULL,
       [ModifiedBy] [varchar](100) NULL,
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]



INSERT INTO PDFUpload ( DSARReference , pdf_reference , FileName , FileContent )
VALUES ( 'R1234567', '001', 'R1234567_EmploymentHistory.pdf' , null )
, ( 'R1234567', '005', 'R1234567_Renewal.pdf' , null )
, ( 'R1234567', '003', 'R1234567_Salary.pdf' , null )

select * from PDFUpload
select * FROM [Department] 
select * FROM [ReportGroup]

select * from PDFUpload as up
inner join [ReportGroup]  as rg on up.pdf_reference = rg.pdf_reference 
inner join [Department]  as dp on rg.Department = dp.[Code]

