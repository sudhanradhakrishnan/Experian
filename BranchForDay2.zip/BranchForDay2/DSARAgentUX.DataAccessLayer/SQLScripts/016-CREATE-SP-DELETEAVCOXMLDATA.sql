USE [DSAR_SR]
GO

/****** Object:  StoredProcedure [dbo].[DeleteAVCOXMLDATA]    Script Date: 29/06/2018 15:34:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =================================================================================
-- Program Name: DSAR
-- Author: C51014A  Description: This SP is to Delete the XML data to SQL tables.
-- InParameter: XMLContent
-- OutParameter: 
-- Created Date: 19-03-2018
-- Revision History :
-- Modified Date Modified By version Description

-----------------------------------------------------------------
-- ==================================================================================
CREATE PROCEDURE [dbo].[DeleteAVCOXMLDATA](
@AVCOXML XML
) 
	
AS
BEGIN


DELETE FROM PDFUpload WHERE DSARReference IN(
		SELECT 
		DSARReference= AvcoData.value('(Reference)[1]', 'varchar(50)')

      FROM 
      @AVCOXML.nodes('/dsar') AS XTbl(AvcoData))

DELETE FROM DataSubjectAccessRequest WHERE DSARReferenceId IN(
		SELECT 
		DSARReferenceId= AvcoData.value('(Reference)[1]', 'varchar(50)')

      FROM 
      @AVCOXML.nodes('/dsar') AS XTbl(AvcoData))
END
GO


