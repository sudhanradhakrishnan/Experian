/****** Object:  StoredProcedure [dbo].[UploadStateNoDataPDF]    Script Date: 24/07/2018 13:59:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =================================================================================
-- Program Name: DSAR
-- Author: Maneesh 
-- Description: This SP is used to Capture DSAR Event information
-- InParameter: DSARReferenceId pdfreference 
-- OutParameter: 
-- Created Date: 19-07-2018
-- Revision History :
-- Modified Date Modified By version Description
-----------------------------------------------------------------
-- ==================================================================================
CREATE PROCEDURE [dbo].[UploadStateNoDataPDF] 
(
@filePath varchar(100),
@DSARReference varchar(8),
@PDFReference varchar(8),
@FileName varchar(60), 
@ModifiedBy varchar(100), 
@Status int,
@RequestStatus INT OUTPUT	 
	
)
As
Begin
		BEGIN TRY	
		Declare @sql varchar(max)
		Insert into 
		dbo.PDFUpload(DSARReference,pdf_reference,[FileName],[Status],ModifiedDate,ModifiedBy) 
		values(@DSARReference,@PDFReference,@FileName,@Status,getdate(), @ModifiedBy)  			
	
		Set @sql='Update PDFUpload SET FileContent=  (SELECT * FROM OPENROWSET(BULK '''
		+ @filePath+@filename+''', SINGLE_BLOB) AS BLOB) where DSARReference='''
		+ @DSARReference +''' and pdf_reference=''' + @PDFReference +'''' 

		exec(@sql)
		SET  @RequestStatus = 1	-- 	
		END TRY
		BEGIN CATCH
			 SET  @RequestStatus = 0  -- 	 
		END CATCH   

End

GO


