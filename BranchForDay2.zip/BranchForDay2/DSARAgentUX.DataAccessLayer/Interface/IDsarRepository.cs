﻿using DSARAgentUX.Models;
using System.Collections.Generic;
using System.Xml;

namespace DSARAgentUX.DataAccessLayer.Interface
{
    public interface IDsarRepository
    {
        XmlDocument GetDsarReferenceId(string dsarReferenceId);
        bool CheckDsarDuplicate(string dsarReferenceId);
        List<DsarInformation> GetReadyToPublishedDsars();
        List<DsarInformation> GetCompletedAndDuplicateAndCancelledDsars();
        int UpdateCancelDuplicate();
    }
}
