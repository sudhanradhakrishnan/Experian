﻿using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using System.Collections.Generic;

namespace DSARAgentUX.DataAccessLayer.Interface
{
    public interface IViewPdfRepository
    {
        ServiceUserModel GetPdfFile(string dsarReference, string pdfReference);
        ServiceUserModel GetDsarInformation(string dsarReference);
        List<ServiceUserModel> GetAllUploadedPdfDetails(string dsarReferenceId);
        List<ServiceUserModel> GetAllUploadedPostalPdfDetails(string dsarReferenceId);
        List<ServiceUserModel> GetUploadedPdfDetails(string dsarReferenceId, string pdfReference);
        List<ServiceUserModel> GetUploadedPostalPdfDetails(string dsarReferenceId, string pdfReference);
        DepartmentUserModel GePdfStatus(string dsarReferenceId, string pdfReference);
        int RemovePdf(string dsarReference, string pdfReference, string userId);
        int UpdateDsarCancelStatus(string dsarReferenceId, DsarCancelType dsarcancel, DsarStatusType dsarStatus);
        int UpdateDsarPublishStatus(string dsarReferenceId, PublishStatusType status, DsarStatusType dsarStatus);
        ServiceUserModel GetCancelledUsernameByReference(string dsarReferenceId);
        int UpdateRemoveDuplicateStatus(string dsarReferenceId, DuplicateCheckStatusType status);
        void CaptureEvent(Audit audit);
        ServiceUserModel GetPostalReportFile(string dsarReference, string pdfReference);
        int RemovePostalReport(string dsarReference, string pdfReference, string userId);
    }
}
