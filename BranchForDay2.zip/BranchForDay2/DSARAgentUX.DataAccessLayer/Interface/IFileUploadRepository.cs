﻿using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using System.Collections.Generic;

namespace DSARAgentUX.DataAccessLayer.Interface
{
    public interface IFileUploadRepository
    {
        int UploadPdf(PdfFileDetails pdffile, PDFStatusType status, string dsarNumber, string pdfReference,
            string userId);
        bool CheckDuplicatePDF(string dsarNumber, string pdfReference);
        bool CheckDuplicatePostalPDF(string dsarNumber, string pdfReference);
        List<int> GetDsarStatus(string dsarNumber);
        List<PdfFileDetails> GetListOfPdfForReadyToPublishDsars(string dsarReferenceNumber);
        int UploadStateNoDataPDF(string filePath, string FileName, string DSARReference, string PDFReference, string ModifiedBy);
        int UploadPostalPdf(PdfFileDetails pdffile, PDFStatusType status, string dsarNumber, string pdfReference, string userId);
    }
}
