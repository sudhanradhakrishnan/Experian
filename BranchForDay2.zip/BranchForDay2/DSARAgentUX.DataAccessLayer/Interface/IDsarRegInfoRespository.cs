﻿using System.Collections.Generic;

namespace DSARAgentUX.DataAccessLayer.Interface
{
    public interface IDsarRegInfoRepository
    {
        Dictionary<string, string> GetAllRegInfoXml(List<string> references);
    }
}
