﻿namespace DSARAgentUX.DataAccessLayer.Interface
{
    public interface IAvcoxmlRepository
    {
        void SaveAvcoxml(string dsarRequestXml);
    }
}
