﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DSARAgentUX.DataAccessLayer.Repositories
{
    public class SecurityRepository
    {
        public securityType SecurityInformation { get; set; }

        public SecurityRepository(securityType securityInformation)
        {
            SecurityInformation = securityInformation;
        }

        public string GetPdfFileName(string dsarReference, string pdfReference)
        {
            
            var pdfName = dsarReference + "_" + GetPdfMap(pdfReference).readableName;
            return pdfName;
        }

        public string GetNoDataFileName(string pDfReference)
        {
            var pdfName = GetPdfMap(pDfReference).nodataFilename;
            return pdfName;
        }

        public pdfType GetPdfMap(string pDfReference)
        {
            var result = SecurityInformation.pdfmap.Where(x => x.id.Equals(pDfReference))
               .ToList()
               .Select(selmap => selmap);
            return result.Distinct().FirstOrDefault();
        }

        public List<pdfType> GetAllPdfMaps()
        {
                var result = SecurityInformation.pdfmap.Select(selmap => selmap);
                return result.ToList();
        }
    }
}