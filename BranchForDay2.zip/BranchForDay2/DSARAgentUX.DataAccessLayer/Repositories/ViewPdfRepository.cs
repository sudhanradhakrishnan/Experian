﻿using DSARAgentUX.DataAccessLayer.Interface;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Xml;

namespace DSARAgentUX.DataAccessLayer.Repositories
{
    public class ViewPdfRepository : IViewPdfRepository
    {
        private readonly string _connectionString;

        public ViewPdfRepository()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["DSARCon"].ConnectionString;
        }

        public ServiceUserModel GetPdfFile(string dsarReference, string pdfReference)
        {
            var file = new ServiceUserModel();

            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetPDFFile", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarReference));
                    command.Parameters.Add(new SqlParameter("@Pdf_Reference", pdfReference));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                file.FileContent = (byte[])sqlreader["FileContent"];
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }

            return file;
        }


        public ServiceUserModel GetDsarInformation(string dsarReference)
        {
            var serviceUserModel = new ServiceUserModel();
           
            string dsarXmldata = string.Empty;

            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand())
                {
                    command.Connection = conn;
                    command.CommandText = "GetDSARInformationByReferance";
                    command.Parameters.Add(new SqlParameter("@DSARReferenceNumber", dsarReference));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                serviceUserModel.DsarReference = Convert.ToString(sqlreader["DSARReferenceId"]);
                                serviceUserModel.ModifiedDate = Convert.ToDateTime(sqlreader["ModifiedDate"]);
                                serviceUserModel.DsarCancelStatus = (DsarCancelType) Enum.Parse(typeof(DsarCancelType),
                                                                        sqlreader["DSARCancel"].ToString());
                                serviceUserModel.DsarStatus = (DsarStatusType) Enum.Parse(typeof(DsarStatusType),
                                                                        sqlreader["Status"].ToString());
                                serviceUserModel.PublishStatus = (PublishStatusType) Enum.Parse(typeof(PublishStatusType),
                                                                        sqlreader["Publish"].ToString());
                                serviceUserModel.DuplicateStatus = (DuplicateCheckStatusType) Enum.Parse(typeof(DuplicateCheckStatusType),
                                                                        sqlreader["Duplicate"].ToString());
                                dsarXmldata = (string) sqlreader["XMLdata"];
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }
            serviceUserModel.xmlcontent = BindStringtoXmlContent(dsarXmldata);
            return serviceUserModel;
        }

        private XmlDocument BindStringtoXmlContent(string xmlContent)
        {
            var xdoc = new XmlDocument
            {
                XmlResolver = null
            };

            XmlReader reader = null;
            var settings = new XmlReaderSettings
            {
                XmlResolver = null
            };
            if (!string.IsNullOrWhiteSpace(xmlContent))
            {
                reader = XmlReader.Create(new StringReader(xmlContent), settings);
            }

            if (reader != null)
            {
                xdoc.Load(reader);
            }

            return xdoc;
        }

        public List<ServiceUserModel> GetAllUploadedPdfDetails(string dsarReferenceId)
        {

            var list = new List<ServiceUserModel>();
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetAllUploadedPDFDetails", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceNumber", dsarReferenceId));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                int pdfid;
                                int.TryParse(sqlreader["PDFId"].ToString(), out pdfid);
                                var serviceUser = new ServiceUserModel
                                {
                                    DepartmentFriendlyName = Convert.ToString(sqlreader["DepartmentFriendlyName"]),
                                    DsarReference = Convert.ToString(sqlreader["dsarreference"]),
                                    PdfId = pdfid,
                                    PdfReference = Convert.ToString(sqlreader["PDFReference"]),
                                    DsarStatus = (DsarStatusType)Enum.Parse(typeof(DsarStatusType),
                                                    sqlreader["DSARStatus"].ToString()),
                                    PublishStatus = (PublishStatusType)Enum.Parse(typeof(PublishStatusType),
                                                    sqlreader["PublishStatus"].ToString()),
                                    DuplicateStatus = (DuplicateCheckStatusType)Enum.Parse(typeof(DuplicateCheckStatusType),
                                                    sqlreader["DuplicateStatus"].ToString()),
                                    FileName = Convert.ToString(sqlreader["FileName"]),
                                    PdfStatus = (PDFStatusType)Enum.Parse(typeof(PDFStatusType),
                                                    sqlreader["PDFstatus"].ToString()),
                                    ModifiedDate = Convert.ToDateTime(sqlreader["ModifiedDate"]),
                                    ModifiedBy = Convert.ToString(sqlreader["ModifiedBy"])
                                };
                                list.Add(serviceUser);
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }
            return list;

        }
        public List<ServiceUserModel> GetAllUploadedPostalPdfDetails(string dsarReferenceId)
        {

            var list = new List<ServiceUserModel>();
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetAllUploadedPostalPDFDetails", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceNumber", dsarReferenceId));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                int pdfid;
                                int.TryParse(sqlreader["PDFId"].ToString(), out pdfid);
                                var serviceUser = new ServiceUserModel
                                {
                                    DepartmentFriendlyName = Convert.ToString(sqlreader["DepartmentFriendlyName"]),
                                    DsarReference = Convert.ToString(sqlreader["dsarreference"]),
                                    PdfId = pdfid,
                                    PdfReference = Convert.ToString(sqlreader["PDFReference"]),
                                    DsarStatus = (DsarStatusType)Enum.Parse(typeof(DsarStatusType),
                                                    sqlreader["DSARStatus"].ToString()),
                                    PublishStatus = (PublishStatusType)Enum.Parse(typeof(PublishStatusType),
                                                    sqlreader["PublishStatus"].ToString()),
                                    DuplicateStatus = (DuplicateCheckStatusType)Enum.Parse(typeof(DuplicateCheckStatusType),
                                                    sqlreader["DuplicateStatus"].ToString()),
                                    FileName = Convert.ToString(sqlreader["FileName"]),
                                    PdfStatus = (PDFStatusType)Enum.Parse(typeof(PDFStatusType),
                                                    sqlreader["PDFstatus"].ToString()),
                                    ModifiedDate = Convert.ToDateTime(sqlreader["ModifiedDate"]),
                                    ModifiedBy = Convert.ToString(sqlreader["ModifiedBy"])                                   
                                };
                                list.Add(serviceUser);
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }
            return list;

        }
        public List<ServiceUserModel> GetUploadedPdfDetails(string dsarReferenceId, string pdfReference)
        {
            var list = new List<ServiceUserModel>();
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetUploadedPDFDetails", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceNumber", dsarReferenceId));
                    command.Parameters.Add(new SqlParameter("@PDFReference", pdfReference));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                int pdfid;
                                int.TryParse(sqlreader["PDFId"].ToString(), out pdfid);
                                ServiceUserModel serviceUser = new ServiceUserModel
                                {
                                    DepartmentFriendlyName = Convert.ToString(sqlreader["DepartmentFriendlyName"]),
                                    DsarReference = Convert.ToString(sqlreader["DSARReferenceId"]),
                                    PdfId = pdfid,
                                    PdfReference = pdfReference,
                                    DsarStatus = (DsarStatusType)Enum.Parse(typeof(DsarStatusType),
                                                    sqlreader["DSARStatus"].ToString()),
                                    PublishStatus = (PublishStatusType)Enum.Parse(typeof(PublishStatusType),
                                                    sqlreader["publish"].ToString()),
                                    DuplicateStatus = (DuplicateCheckStatusType)Enum.Parse(typeof(DuplicateCheckStatusType),
                                                    sqlreader["duplicate"].ToString()),
                                    FileName = Convert.ToString(sqlreader["FileName"]),
                                    PdfStatus = (PDFStatusType)Enum.Parse(typeof(PDFStatusType),
                                                    sqlreader["PDFstatus"].ToString()),
                                    ModifiedDate = Convert.ToDateTime(sqlreader["ModifiedDate"]),
                                    ModifiedBy = Convert.ToString(sqlreader["ModifiedBy"])
                                };
                                list.Add(serviceUser);
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }
            return list;

        }

        public List<ServiceUserModel> GetUploadedPostalPdfDetails(string dsarReferenceId, string pdfReference)
        {
            var list = new List<ServiceUserModel>();
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetUploadedPostalPDFDetails", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceNumber", dsarReferenceId));
                    command.Parameters.Add(new SqlParameter("@PDFReference", pdfReference));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                int pdfid;
                                int.TryParse(sqlreader["PDFId"].ToString(), out pdfid);
                                ServiceUserModel serviceUser = new ServiceUserModel
                                {
                                    DepartmentFriendlyName = Convert.ToString(sqlreader["DepartmentFriendlyName"]),
                                    DsarReference = Convert.ToString(sqlreader["DSARReferenceId"]),
                                    PdfId = pdfid,
                                    PdfReference = pdfReference,
                                    DsarStatus = (DsarStatusType)Enum.Parse(typeof(DsarStatusType),
                                                    sqlreader["DSARStatus"].ToString()),
                                    PublishStatus = (PublishStatusType)Enum.Parse(typeof(PublishStatusType),
                                                    sqlreader["publish"].ToString()),
                                    DuplicateStatus = (DuplicateCheckStatusType)Enum.Parse(typeof(DuplicateCheckStatusType),
                                                    sqlreader["duplicate"].ToString()),
                                    FileName = Convert.ToString(sqlreader["FileName"]),
                                    PdfStatus = (PDFStatusType)Enum.Parse(typeof(PDFStatusType),
                                                    sqlreader["PDFstatus"].ToString()),
                                    ModifiedDate = Convert.ToDateTime(sqlreader["ModifiedDate"]),
                                    ModifiedBy = Convert.ToString(sqlreader["ModifiedBy"])
                                };
                                list.Add(serviceUser);
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }
            return list;

        }

        public DepartmentUserModel GePdfStatus(string dsarReferenceId, string pdfReference)
        {
            DepartmentUserModel file = null;
            try
            {
                using (var conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (var command = new SqlCommand("dbo.GetPDFStatus", conn))
                    {
                        command.Parameters.Add(new SqlParameter("@DSARReference", dsarReferenceId));
                        command.Parameters.Add(new SqlParameter("@pdf_reference", pdfReference));
                        command.CommandType = CommandType.StoredProcedure;
                        using (var sqlreader = command.ExecuteReader())
                        {
                            if (sqlreader.HasRows)
                            {
                                while (sqlreader.Read())
                                {
                                    file = new DepartmentUserModel
                                    {
                                        Departments = sqlreader["Description"].ToString(),
                                        PdfReferenceNumbers = sqlreader["pdfId"].ToString(),
                                        PdfStatus = (PDFStatusType)Enum.Parse(typeof(PDFStatusType),
                                            sqlreader["PDFstatus"].ToString()),
                                        ModifiedBy = sqlreader["ModifiedBy"].ToString()
                                    };
                                }
                                sqlreader.Close();
                            }
                        }
                    }
                }
                return file;
                //using (var command = _context.CreateCommand())
                //{
                //    command.CommandText = "GetPDFStatus";
                //    command.Parameters.Add(new SqlParameter("@DSARReference", dsarReferenceId));
                //    command.Parameters.Add(new SqlParameter("@pdf_reference", pdfReference));
                //    command.CommandType = CommandType.StoredProcedure;
                //    var readerDepartment = command.ExecuteReader();

                //    while (readerDepartment.Read())
                //    {
                //        file = new DepartmentUserModel
                //        {
                //            Departments = readerDepartment["Description"].ToString(),
                //            PdfReferenceNumbers = readerDepartment["pdfId"].ToString(),
                //            PdfStatus = (PDFStatusType) Enum.Parse(typeof(PDFStatusType),
                //                readerDepartment["PDFstatus"].ToString()),
                //            ModifiedBy = readerDepartment["ModifiedBy"].ToString()
                //        };
                //    }

                //    readerDepartment.Close();
                //    return file;
                //}
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public int RemovePdf(string dsarReference, string pdfReference, string userId)
        {
            int requestStatus;

            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.RemovePDF", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarReference));
                    command.Parameters.Add(new SqlParameter("@PDFReference", pdfReference));
                    command.Parameters.Add(new SqlParameter("@ModifiedBy", userId));
                    SqlParameter returnValue =
                                                new SqlParameter("@RequestStatus", SqlDbType.Int) {Direction = ParameterDirection.Output};
                    command.Parameters.Add(returnValue);
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                    requestStatus = (int)command.Parameters["@RequestStatus"].Value;
                }
            }
            return requestStatus;
        }

        public int UpdateDsarCancelStatus(string dsarReferenceId, DsarCancelType dsarcancel, DsarStatusType dsarStatus)
        {
            int returnOutput;
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.UpdateDSARCancelled", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceId", dsarReferenceId));
                    command.Parameters.Add(new SqlParameter("@DSARCancel", dsarcancel));
                    command.Parameters.Add(new SqlParameter("@DSARStatus", Convert.ToInt32(dsarStatus)));
                    SqlParameter returnValue =
                        new SqlParameter("@RequestStatus", SqlDbType.Int) {Direction = ParameterDirection.Output};
                    command.Parameters.Add(returnValue);
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                    returnOutput = (int)command.Parameters["@RequestStatus"].Value;
                }
            }

            return returnOutput;
        }

        public int UpdateDsarPublishStatus(string dsarReferenceId, PublishStatusType status, DsarStatusType dsarStatus)
        {
            int returnOutput;
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.UpdateDSARPublished", conn))
                {
                    command.Parameters.Add(new SqlParameter("@PublishStatus", Convert.ToInt32(status)));
                    command.Parameters.Add(new SqlParameter("@Status", Convert.ToInt32(dsarStatus)));
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarReferenceId));
                    SqlParameter returnValue =
                        new SqlParameter("@RequestStatus", SqlDbType.Int) {Direction = ParameterDirection.Output};
                    command.Parameters.Add(returnValue);
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                    returnOutput = (int)command.Parameters["@RequestStatus"].Value;
                }
            }
            return returnOutput;
        }

        public ServiceUserModel GetCancelledUsernameByReference(string dsarReferenceId)
        {
            //using (var command = _context.CreateCommand())
            //{
            //    command.CommandText = "GetActivityLogByReference";
            //    command.Parameters.Add(new SqlParameter("@DSARReference", dsarReferenceId));
            //    command.Parameters.Add(new SqlParameter("@Operation", Convert.ToInt32(AuditEventsType.CANCELDSAR)));
            //    command.CommandType = CommandType.StoredProcedure;
            //    return ToList(command).FirstOrDefault();
            //}

            var serviceUserModel = new ServiceUserModel();
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetActivityLogByReference", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarReferenceId));
                    command.Parameters.Add(new SqlParameter("@Operation", Convert.ToInt32(AuditEventsType.CANCELDSAR)));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                serviceUserModel.Username = Convert.ToString(sqlreader["Username"]);
                                break;
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }
            return serviceUserModel;


        }
        public int UpdateRemoveDuplicateStatus(string dsarReferenceId, DuplicateCheckStatusType status)
        {
            int returnOutput;
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.UpdateDSARDuplicate", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceId", dsarReferenceId));
                    command.Parameters.Add(new SqlParameter("@DuplicateStatus", Convert.ToInt32(status)));
                    SqlParameter returnValue =
                        new SqlParameter("@RequestStatus", SqlDbType.Int) {Direction = ParameterDirection.Output};
                    command.Parameters.Add(returnValue);
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                    returnOutput = (int)command.Parameters["@RequestStatus"].Value;
                }
            }

            return returnOutput;
        }

        public void CaptureEvent(Audit audit)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.CaptureDSARAudit", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceId", audit.DsarReferenceId));
                    command.Parameters.Add(new SqlParameter("@pdfreference", audit.PdfReference));
                    command.Parameters.Add(new SqlParameter("@Username", audit.UserId));
                    command.Parameters.Add(new SqlParameter("@Operation", Convert.ToInt32(audit.Operation)));
                    command.Parameters.Add(new SqlParameter("@ModifyedPDFName", audit.ModifyedPdfName));
                    command.Parameters.Add(new SqlParameter("@ActualPDFName", audit.ActualPdfName));
                    command.Parameters.Add(new SqlParameter("@IsPDFuploaded", audit.IsPdFuploaded));
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                }
            }
        }

        public ServiceUserModel GetPostalReportFile(string dsarReference, string pdfReference)
        {
            var file = new ServiceUserModel();

            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetPostalPDFFile", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarReference));
                    command.Parameters.Add(new SqlParameter("@Pdf_Reference", pdfReference));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                file.FileContent = (byte[])sqlreader["FileContent"];
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }

            return file;
        }

        public int RemovePostalReport(string dsarReference, string pdfReference, string userId)
        {
            int requestStatus;

            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.RemovePostalPDF", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarReference));
                    command.Parameters.Add(new SqlParameter("@PDFReference", pdfReference));
                    command.Parameters.Add(new SqlParameter("@ModifiedBy", userId));
                    SqlParameter returnValue =
                        new SqlParameter("@RequestStatus", SqlDbType.Int) { Direction = ParameterDirection.Output };
                    command.Parameters.Add(returnValue);
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                    requestStatus = (int)command.Parameters["@RequestStatus"].Value;
                }
            }
            return requestStatus;
        }
    }
}