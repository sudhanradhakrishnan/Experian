﻿using DSARAgentUX.DataAccessLayer.Interface;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Xml;

namespace DSARAgentUX.DataAccessLayer.Repositories
{
    public class AvcoXmlRepository : IAvcoxmlRepository
    {

        public AvcoXmlRepository()
        {
        }

        public void SaveAvcoxml(string dsarRequestXml)
        {
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.SaveAVCOXMLDATA", conn))
                {
                    using (var reader = new StringReader(dsarRequestXml))
                    {
                        using (var xmlreader = new XmlTextReader(reader))
                        {
                            var xml = new SqlXml(xmlreader);
                            command.Parameters.Add(new SqlParameter("@AVCOXML", xml));
                            command.CommandType = CommandType.StoredProcedure;
                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
        }
    }
}