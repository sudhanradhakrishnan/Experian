﻿using DSARAgentUX.DataAccessLayer.Interface;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DSARAgentUX.DataAccessLayer.Repositories
{
    public class DsarRegInfoRespository : IDsarRegInfoRepository
    {

        public DsarRegInfoRespository()
        {
        }

        public Dictionary<string, string> GetAllRegInfoXml(List<string> references)
        {

            var inputReferences = JoinString(references);

            var result = new Dictionary<string, string>();

            var connection = ConfigurationManager.ConnectionStrings["DSARCon"].ConnectionString;

            using (var con = new SqlConnection(connection))
            {
                con.Open();
                
                var command = new SqlCommand("dbo.GetDSARRegistrationInformation", con);
                command.Parameters.AddWithValue("@DSARReferenceId", inputReferences);
                command.CommandType = CommandType.StoredProcedure;
                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    result.Add(Convert.ToString(reader[0]), Convert.ToString(reader[1]));
                }

                reader.Close();
            }

            return result;
        }

        private static string JoinString(List<string> references)
        {
            var sb = new StringBuilder();
            var firstItem = true;
            foreach (var item in references)
            {
                sb.Append(firstItem ? $"{item.Trim()}" : $",{item.Trim()}");
                firstItem = false;
            }

            return sb.ToString();
        }
    }
}