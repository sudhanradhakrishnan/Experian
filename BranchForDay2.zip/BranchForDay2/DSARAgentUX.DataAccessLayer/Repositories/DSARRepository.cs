﻿using DSARAgentUX.DataAccessLayer.Interface;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Xml;

namespace DSARAgentUX.DataAccessLayer.Repositories
{
    public class DsarRepository : IDsarRepository
    {

        public DsarRepository()
        {
        }

        public XmlDocument GetDsarReferenceId(string dsarReferenceId)
        {
            var xdoc = new XmlDocument
            {
                XmlResolver = null
            };

            XmlReader reader = null;

            var connection = ConfigurationManager.ConnectionStrings["DSARCon"].ConnectionString;

            using (var con = new SqlConnection(connection))
            {
                con.Open();
                var cmd = new SqlCommand("dbo.GetXMLdata", con);
                cmd.Parameters.AddWithValue("@DSARReferenceId", dsarReferenceId);
                cmd.CommandType = CommandType.StoredProcedure;
                var xmlcontent = cmd.ExecuteScalar();

                if (xmlcontent != null)
                {
                    var settings = new XmlReaderSettings
                    {
                        XmlResolver = null
                    };
                    reader = XmlReader.Create(new StringReader(xmlcontent.ToString()), settings);
                }

                if (reader != null)
                    xdoc.Load(reader);

                return xdoc;
            }
        }


        public bool CheckDsarDuplicate(string dsarReferenceId)
        {
            bool returnValue = false;
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.CheckDuplicateDSAR", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceId", dsarReferenceId));
                    command.CommandType = CommandType.StoredProcedure;
                    int dsarReferencecount;
                    int.TryParse(command.ExecuteScalar().ToString(), out dsarReferencecount);
                    if (dsarReferencecount > 0)
                    {
                        returnValue = true;
                    }
                }
            }
            return returnValue;
        }

        public List<DsarInformation> GetReadyToPublishedDsars()
        {
            //using (var command = _context.CreateCommand())
            //{
            //    command.CommandText = "GetReadyToPublishDSARS";
            //    command.CommandType = CommandType.StoredProcedure;
            //    //Reference = DSARReferenceId,RegistrationDate,DocumentDeliveryMethod,Status 
            //    return ToList(command).ToList();
            //}

            var listofDsarInformation = new List<DsarInformation>();
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetReadyToPublishDSARS", conn))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                var dsarInformation = new DsarInformation
                                {
                                    Reference = Convert.ToString(sqlreader["Reference"]),
                                    Status = (DsarStatusType) Enum.Parse(typeof(DsarStatusType),
                                        sqlreader["Status"].ToString())
                                };
                                listofDsarInformation.Add(dsarInformation);
                            }

                            sqlreader.Close();
                        }
                    }
                }
            }

            return listofDsarInformation;
        }

        public List<DsarInformation> GetCompletedAndDuplicateAndCancelledDsars()
        {
            //using (var command = _context.CreateCommand())
            //{
            //    command.CommandText = "GetCompletedAndDuplicateAndCancelledDSARS";
            //    command.Parameters.Add(new SqlParameter("@DuplicateStatus", DuplicateCheckStatusType.MarkedDuplicate));
            //    command.Parameters.Add(new SqlParameter("@PublishStatus", PublishStatusType.ReadyToPublish));
            //    command.Parameters.Add(new SqlParameter("@DSARCancelStatus", DsarCancelType.ReadyToCancel));
            //    command.CommandType = CommandType.StoredProcedure;

            //    return ToList(command).ToList();
            //}


           var listofDsarInformation = new List<DsarInformation>();
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetCompletedAndDuplicateAndCancelledDSARS", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DuplicateStatus", DuplicateCheckStatusType.MarkedDuplicate));
                    command.Parameters.Add(new SqlParameter("@PublishStatus", PublishStatusType.ReadyToPublish));
                    command.Parameters.Add(new SqlParameter("@DSARCancelStatus", DsarCancelType.ReadyToCancel));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                             
                                var dsarInformation = new DsarInformation
                                {
                                    Reference = Convert.ToString(sqlreader["Reference"]),
                                    DsarCancel = (DsarCancelType) Enum.Parse(typeof(DsarCancelType),
                                        sqlreader["DSARCancel"].ToString()),
                                    Duplicate = (DuplicateCheckStatusType) Enum.Parse(typeof(DuplicateCheckStatusType),
                                        sqlreader["Duplicate"].ToString()),
                                    Status = (DsarStatusType) Enum.Parse(typeof(DsarStatusType),
                                        sqlreader["Status"].ToString())
                                };
                                listofDsarInformation.Add(dsarInformation);
                            }

                            sqlreader.Close();
                        }
                    }
                }
            }

            return listofDsarInformation;
        }


        public int UpdateCancelDuplicate()
        {
            int returnOutput;
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.UpdateDuplicateCancelledDSARS", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DuplicateStatus", DuplicateCheckStatusType.MarkedDuplicate));
                    command.Parameters.Add(new SqlParameter("@DSARCancelStatus", DsarCancelType.ReadyToCancel));
                    SqlParameter returnValue =
                        new SqlParameter("@RequestStatus", SqlDbType.Int) {Direction = ParameterDirection.Output};
                    command.Parameters.Add(returnValue);
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();
                    returnOutput = (int)command.Parameters["@RequestStatus"].Value;
                }
            }

            return returnOutput;


        }
    }
}