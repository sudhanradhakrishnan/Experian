﻿using DSARAgentUX.DataAccessLayer.Interface;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DSARAgentUX.DataAccessLayer.Repositories
{
    public class FileUploadRepository : IFileUploadRepository
    {

        public FileUploadRepository()
        {
          
        }

        public int UploadPdf(PdfFileDetails pdffile, PDFStatusType status,string dsarNumber, string pdfReference, string userId)
        {
            int requestStatus;
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.UploadPDF", conn))
                {
                    command.Parameters.Add(new SqlParameter("@ModifiedBy", userId));
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarNumber));
                    command.Parameters.Add(new SqlParameter("@pdf_reference", pdfReference));
                    command.Parameters.Add(new SqlParameter("@FileName", pdffile.FileName));
                    command.Parameters.Add(new SqlParameter("@FileContent", pdffile.FileContent));
                    command.Parameters.Add(new SqlParameter("@Status", status));
                     
                    var returnValue =
                        new SqlParameter("@RequestStatus", SqlDbType.Int) {Direction = ParameterDirection.Output};
                    command.Parameters.Add(returnValue);
                    //command.CommandText = "UploadPDF";
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();

                    requestStatus = (int)command.Parameters["@RequestStatus"].Value;
                }
            }

            return requestStatus;
        }
        public int UploadPostalPdf(PdfFileDetails pdffile, PDFStatusType status, string dsarNumber, string pdfReference, string userId)
        {
            int requestStatus;
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.UploadPostalPDF", conn))
                {
                    command.Parameters.Add(new SqlParameter("@ModifiedBy", userId));
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarNumber));
                    command.Parameters.Add(new SqlParameter("@pdf_reference", pdfReference));
                    command.Parameters.Add(new SqlParameter("@FileName", pdffile.FileName));
                    command.Parameters.Add(new SqlParameter("@FileContent", pdffile.FileContent));
                    command.Parameters.Add(new SqlParameter("@Status", status));

                    var returnValue =
                        new SqlParameter("@RequestStatus", SqlDbType.Int) { Direction = ParameterDirection.Output };
                    command.Parameters.Add(returnValue);
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();

                    requestStatus = (int)command.Parameters["@RequestStatus"].Value;
                }
            }

            return requestStatus;
        }

        public bool CheckDuplicatePDF(string dsarNumber, string pdfReference) 
        {
            bool requestStatus = false;
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();

                using (var command = new SqlCommand("dbo.CheckDuplicatePDF", conn))
                {                    
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarNumber));
                    command.Parameters.Add(new SqlParameter("@pdf_reference", pdfReference));
                    command.CommandType = CommandType.StoredProcedure;
                    int dsarReferencecount;
                    int.TryParse(command.ExecuteScalar().ToString(), out dsarReferencecount);
                    if (dsarReferencecount > 0)
                    {
                        requestStatus = true;
                    }
                    
                }
            }

            return requestStatus;
        }
        public bool CheckDuplicatePostalPDF(string dsarNumber, string pdfReference)
        {
            bool requestStatus = false;
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();

                using (var command = new SqlCommand("dbo.CheckDuplicatePostalPDF", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarNumber));
                    command.Parameters.Add(new SqlParameter("@pdf_reference", pdfReference));
                    command.CommandType = CommandType.StoredProcedure;
                    int dsarReferencecount;
                    int.TryParse(command.ExecuteScalar().ToString(), out dsarReferencecount);
                    if (dsarReferencecount > 0)
                    {
                        requestStatus = true;
                    }

                }
            }

            return requestStatus;
        }
        public List<int> GetDsarStatus(string dsarNumber)
        {


            // DsarStatusType dsarStatus =new DsarStatusType();
            var listofDsarInformation = new List<int>();
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetDSARStatus", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReference", dsarNumber));
                    command.CommandType = CommandType.StoredProcedure;
                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                
                                listofDsarInformation.Add(Convert.ToInt16(sqlreader["Status"]));
                                listofDsarInformation.Add(Convert.ToInt16(sqlreader["Publish"]));
                                //listofDsarInformation.Add(sqlreader["Duplicate"].ToString());
                                listofDsarInformation.Add(Convert.ToInt16(sqlreader["DSARCancel"]));
                            }

                            sqlreader.Close();
                        }
                    }
                }
            }

            return listofDsarInformation;
        }
        public List<PdfFileDetails> GetListOfPdfForReadyToPublishDsars(string dsarReferenceNumber)
        {
            var listofPdfFileDetails = new List<PdfFileDetails>();
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.GetListOfPDFForReadyToPublishDsars", conn))
                {
                    command.Parameters.Add(new SqlParameter("@DSARReferenceNumber", dsarReferenceNumber));
                    command.CommandType = CommandType.StoredProcedure;

                    using (var sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (sqlreader.Read())
                            {
                                int pdfid;
                                int.TryParse(sqlreader["Id"].ToString(), out pdfid);
                                var pdfFileDetail = new PdfFileDetails
                                {
                                    Id = pdfid,
                                    DsarReference = Convert.ToString(sqlreader["DSARReference"]),
                                    PdfReference = Convert.ToString(sqlreader["PdfReference"]),
                                    FileName = Convert.ToString(sqlreader["FileName"]),
                                    Status = (PDFStatusType) Enum.Parse(typeof(PDFStatusType),
                                        sqlreader["Status"].ToString()),
                                    ModifiedDate = Convert.ToDateTime(sqlreader["ModifiedDate"]),
                                    ModifiedBy = Convert.ToString(sqlreader["ModifiedBy"])
                                };
                                listofPdfFileDetails.Add(pdfFileDetail);
                            }
                            sqlreader.Close();
                        }
                    }
                }
            }
            return listofPdfFileDetails;
        }

        public int UploadStateNoDataPDF(string filePath, string FileName, string DSARReference, string PDFReference, string ModifiedBy)
        {
            int requestStatus;
            using (var conn = new SqlConnection(Common.Helpers.GetConnectionString()))
            {
                conn.Open();
                using (var command = new SqlCommand("dbo.UploadStateNoDataPDF", conn))
                {
                    command.Parameters.Add(new SqlParameter("@ModifiedBy", ModifiedBy));
                    command.Parameters.Add(new SqlParameter("@DSARReference", DSARReference));
                    command.Parameters.Add(new SqlParameter("@PDFReference", PDFReference));
                    command.Parameters.Add(new SqlParameter("@FileName", FileName));
                    command.Parameters.Add(new SqlParameter("@Status", PDFStatusType.State_No_Data));
                    command.Parameters.Add(new SqlParameter("@filePath", filePath));
                    var returnValue =
                        new SqlParameter("@RequestStatus", SqlDbType.Int) { Direction = ParameterDirection.Output };
                    command.Parameters.Add(returnValue);
                    command.CommandType = CommandType.StoredProcedure;
                    command.ExecuteNonQuery();

                    requestStatus = (int)command.Parameters["@RequestStatus"].Value;
                }
            }

            return requestStatus;
        }
    }
}