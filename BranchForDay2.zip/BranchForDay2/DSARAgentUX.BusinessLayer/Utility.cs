﻿using DSARAgentUX.Models;
using System;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace DSARAgentUX.BusinessLayer
{
    public static class Utility
    {

        public static XmlRootAttribute AddNamespaceForXml(string elementname, string namespacename)
        {
            var xRoot = new XmlRootAttribute
            {
                ElementName = elementname,
                Namespace = namespacename,
                IsNullable = true
            };

            return xRoot;
        }
        public static T DeserializeXmlFileToObject<T>(string xmlFile, string elementname, string nsliteral)
        {
            T returnObject;

            if (string.IsNullOrEmpty(xmlFile))
                return default(T);

            var outerXml = xmlFile;
            var settings = new XmlReaderSettings
            {
                XmlResolver = null
            };

            var serializer = new XmlSerializer(typeof(T),
                AddNamespaceForXml(elementname, nsliteral));

            using (var reader = XmlReader.Create(new StringReader(outerXml), settings))
            {
                returnObject = (T) serializer.Deserialize(reader);
            }

            return returnObject;
        }

        public static dsars DeSerialiseDsars(XmlDocument doc)
        {
            dsars dsars;
            using (TextReader reader = new StringReader(doc.InnerXml))
            {
                var serializer = new XmlSerializer(typeof(dsars));
                dsars = (dsars) serializer.Deserialize(reader);
            }

            return dsars;
        }

        public static string ReformatXmLforDsarsClass(XmlDocument outXml)
        {
            var rootXml = new XmlDocument();
            rootXml.LoadXml(@"<?xml version=""1.0"" encoding=""utf - 16""?><dsars xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema""  xmlns=""http://experian.com/DSAR_Submission/v1""></dsars>");

            if (outXml?.DocumentElement == null)
                return rootXml.OuterXml;

            var rootNode = rootXml.ImportNode(outXml.DocumentElement, true);
            rootXml.DocumentElement?.AppendChild(rootNode);

            return rootXml.OuterXml;
        }

        public static string GetAbsolutePath(string relativePath,string aplicationname)
        {
            var basePath = Path.GetFullPath(".");

            if (relativePath == null)
                return null;

            var parentStart = basePath.IndexOf(aplicationname, StringComparison.Ordinal);
            var replacePath = string.Empty;

            if (parentStart >= 0)
            {
                replacePath = basePath.Replace(basePath.Substring(parentStart + aplicationname.Length), relativePath);                
            }

            return replacePath;
        }


        public static byte[] LoadFileContent(string path)
        {
            if (string.IsNullOrEmpty(path))
                path = ConfigurationManager.AppSettings["Headerpath"];
            var contents = new byte[0];
            using (var fStream = File.OpenRead(path))
            {
                contents = new byte[fStream.Length];
                fStream.Read(contents, 0, (int)fStream.Length);
                fStream.Close();
            }
            return contents;
        }
    }
}