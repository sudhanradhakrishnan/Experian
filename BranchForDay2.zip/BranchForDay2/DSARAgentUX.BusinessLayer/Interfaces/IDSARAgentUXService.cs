﻿using DSARAgentUX.Models;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using DSARAgentUX.Models.DataSubjectAccessRequests;

namespace DSARAgentUX.BusinessLayer.Interfaces
{
    public interface IDSARAgentUXService
    {
        void UploadReportData(PdfFileDetails pdfFile, string dsarNumber, string pdfReference, string userId);
        string PdfName(PdfFileDetails pdfFile, string dsarNumber, string pdfReference);
        void UploadReportNoData(string dsarReference,string pdfReference, string userId);
        
        ServiceUserModel GetCancelledUsernameByReference(string dsarReferenceId);
       
        ServiceUserModel GetDsarInformation(string dsarReference);
        List<ServiceUserModel> GetAllUploadedPdfDetails(string dsarReferenceId);
        List<ServiceUserModel> GetUploadedPdfDetails(string dsarReferenceId, string pdfReference);
        List<ServiceUserModel> GetAllUploadedPostalPdfDetails(string dsarReferenceId);
        List<ServiceUserModel> GetUploadedPostalPdfDetails(string dsarReferenceId, string pdfReference);
        DepartmentUserModel GePdfStatus(string dSarReferenceId, string pdfReference);
        void RemovePdf(string dsarReference, string pdfReference, string userId);
        void UpdateDsarCancelStatus(string dsarReferenceNumber, DsarCancelType dsarCancel, string userId, DsarStatusType dsarStatus, AuditEventsType audEvent);
   
        void UpdateRemoveDuplicateStatus(string dsarReferenceNumber, DuplicateCheckStatusType status, string userId);
        void UpdatePublishStatus(string dsarReferenceNumber, PublishStatusType status,string userId);
        void CaptureEvent(Audit audit);
        CurrentUser ValidateCurrentUser();
        ServiceUserModel GetPdfFile(string dsarReference, string pdfReference);
        void UploadPostalReportData(PdfFileDetails pdfFile, string dsarNumber, string pdfReference, string userId);


      //  void UpdatePublishStatus(string dsarReferanceID);
        List<pdfType> GetAllPdfMaps();

        void RemovePostalReport(string dsarReference, string pdfReference, string userId);
        ServiceUserModel GetPostalReportFile(string dsarReference, string pdfReference);


        void CloseReviewTaskInSnow(string dsarReference, string pdfReference,  string userId);
        void CloseUploadTaskInSnow(string dsarReference, string pdfReference, string userId);

        bool ReadTaskStatusDsarUpload(string dsarReference, string pdfReference);
        bool ReadTaskStatusDsarReview(string dsarReference, string pdfReference);


    }
}