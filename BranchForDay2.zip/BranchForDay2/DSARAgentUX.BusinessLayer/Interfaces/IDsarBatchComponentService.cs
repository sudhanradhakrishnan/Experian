﻿using System.Collections.Generic;
using System.Xml.Linq;
using DSARAgentUX.BusinessLayer.ServiceNow.Response;
using DSARAgentUX.Models;
using DSARAgentUX.Models.ServiceNow.Request;

namespace DSARAgentUX.BusinessLayer.Interfaces
{
    public interface IDsarBatchComponentService
    {
        #region "DSARExport Services"
        List<DsarZipWrapper> GetAllPublishedDsarZipMem();
        void UpdatePublishStatus(string dsarReferanceId);
        List<DsarInformation> DropCsvForCompletedAndDuplicateDsaRs();
        void UpdateCancelDuplicateInformation();
        #endregion

        #region "DSARLoad Services"
        bool CheckDsarDuplicate(string dsarReference);
        void SaveAvcoxml(string xmlAvcoData);

        Dictionary<string, string> GetReferencedXmlFromDb(XDocument xDocument);
        XDocument GenerateBiFile(string fullXmlPath, Dictionary<string, string> referenceXmlFromDb);

        SnowResponse CreateTaskInSnow(SnowOrderDsarRequest taskinformation);
        #endregion
    }
}
