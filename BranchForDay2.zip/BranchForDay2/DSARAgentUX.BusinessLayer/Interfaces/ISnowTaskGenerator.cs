﻿using DSARAgentUX.BusinessLayer.ServiceNow.Response;
using DSARAgentUX.Models.ServiceNow.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSARAgentUX.BusinessLayer.Interfaces
{
    public interface ISnowTaskGenerator
    {
        string GeneratedFileName { get; set; }   

        List<SnowOrderDsarRequest> dsarRequest { get; set; }
        List<SnowResponse> lstofServiceNowResponse { get; set; }
        void CreateServiceNowTaskUsingDsarRef();
        void WriteServiceNowResponseInOutputFile();
    }
}
