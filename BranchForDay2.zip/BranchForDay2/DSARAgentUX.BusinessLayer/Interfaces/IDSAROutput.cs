﻿using DSARAgentUX.Models.ServiceNow.Request;
using System.Collections.Generic;

namespace DSARAgentUX.BusinessLayer.Interfaces
{
    public interface IDSAROutput
    {
        string GeneratedFileName { get; set; }
        string ErrorFileName { get; set; }
        string InputFileName { get; set; }

        List<SnowOrderDsarRequest> dsarRequest { get; set; }

        void Build(string inputPath);
    }
}