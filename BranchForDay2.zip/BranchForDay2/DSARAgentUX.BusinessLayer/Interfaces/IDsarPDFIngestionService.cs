﻿using DSARAgentUX.BusinessLayer.ServiceNow.Response;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using DSARAgentUX.Models.ServiceNow.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSARAgentUX.BusinessLayer.Interfaces
{
    public interface IDsarPDFIngestionService
    {
        ServiceUserModel GetDsarInformation(string dsarReference);
        bool CheckDuplicatePDF(string dsarNumber, string pdfReference);
        bool CheckDuplicatePostalPDF(string dsarNumber, string pdfReference);
        int UploadPdf(PdfFileDetails pdffile, PDFStatusType status, string dsarNumber, string pdfReference, string userId);
        int UploadStateNoDataPDF(string filePath ,string DSARReference ,string PDFReference , string FileName ,string ModifiedBy);
        int UploadPostalPdf(PdfFileDetails pdffile, PDFStatusType status, string dsarReference, string pdfReference, string userId);
        string UpdateSnowDsarUploadTask(SnowUpdateDsarRequest snowUpdateDsarRequest);
        string UpdateSnowDsarReviewTask(SnowUpdateDsarRequest snowUpdateDsarRequest);
    }
}
