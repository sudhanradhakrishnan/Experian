﻿using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Models.ServiceNow.Request;
using DSARAgentUX.Models.ServiceNow.Response;
using ExperianLogger;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DSARAgentUX.BusinessLayer.LoadProcess
{
    public class SnowTaskGenerator : IDisposable
    {
        void IDisposable.Dispose()
        {
            GC.SuppressFinalize(this);
        }



        private static ILogger _logger;
        public string GeneratedFileName { get; set; }
        public List<SnowOrderDsarRequest> dsarRequest { get; set; }
        public List<DsarResponse> serviceNowResponses { get; set; }

        private readonly IDsarBatchComponentService _batchComponentService;
        public SnowTaskGenerator(string generatedFileName, List<SnowOrderDsarRequest> _dsarRequest)
        {
            _batchComponentService = new DsarBatchComponentService();
            serviceNowResponses = new List<DsarResponse>();
            GeneratedFileName = generatedFileName;
            dsarRequest = _dsarRequest;
            _logger = new Logger();
        }

        public void CreateServiceNowTaskUsingDsarRef()
        {
            if (dsarRequest != null && dsarRequest.Count > 0)
            {
                foreach (SnowOrderDsarRequest dsarRequest in dsarRequest)
                {
                    var dsarResponse = new DsarResponse();

                    try
                    {
                        var snowResponse = _batchComponentService.CreateTaskInSnow(dsarRequest);
                        if (snowResponse != null)
                        {
                            dsarResponse.dsar_ref = dsarRequest.dsar_ref;
                            dsarResponse.dsar_due_date = dsarRequest.dsar_due_date;
                            dsarResponse.request_number = snowResponse.result.request_number;
                            dsarResponse.request_id = snowResponse.result.request_id;

                            serviceNowResponses.Add(dsarResponse);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogApplicationInfo("DsarSnowCreate", $"SNow Task for dsar referance : {dsarRequest.dsar_ref} failed. Error message : {ex.Message}");
                        break;
                    }
                }
                WriteServiceNowResponseInOutputFile();
            }
        }

        private void WriteServiceNowResponseInOutputFile()
        {
            string filename = string.Empty;
            string _separatorLine = new string('=', 80);
            var _sb = new StringBuilder();
            _sb.AppendLine($"Service now task created automatically ");
            _sb.AppendLine();
            _sb.AppendLine(_separatorLine);

            if (serviceNowResponses.Count > 0)
            {
                foreach (DsarResponse dsarResponse in serviceNowResponses)
                {
                    _sb.AppendLine($"DSAR Reference : {dsarResponse.dsar_ref}");
                    _sb.AppendLine($"Requested Date : {dsarResponse.dsar_due_date}");
                    _sb.AppendLine($"Services Now Task: {dsarResponse.request_number}");
                    _sb.AppendLine();
                }
            }

            File.AppendAllText(GeneratedFileName, _sb.ToString());

        }

    }
}
