﻿using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Models;
using DSARAgentUX.Models.ServiceNow.Request;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;
using System.Xml;

namespace DSARAgentUX.BusinessLayer
{
    public class HumanFriendlyDsarOutput : IDSAROutput
    {
        public string GeneratedFileName { get; set; }
        public string ErrorFileName { get; set; }
        public string InputFileName { get; set; }
        private StringBuilder _sb { get; set; }

        public List<SnowOrderDsarRequest> dsarRequest { get; set; }

        public HumanFriendlyDsarOutput(string inputPath)
        {
            InputFileName = inputPath;
            dsarRequest = new List<SnowOrderDsarRequest>();
        }

        public void Build(string inputPath)
        {
            GenerateFileNames();
            GenerateHardcodedHumanReadableContent();
            File.WriteAllText(GeneratedFileName, _sb.ToString());
        }

        private void GenerateHardcodedHumanReadableContent()
        {
            var doc = new XmlDocument();
            doc.Load(InputFileName);
            var inputDsars = Utility.DeSerialiseDsars(doc);
            var humanFriendlyDsar = new HumanFriendlyDsar();
            _sb = new StringBuilder();

            foreach (var inputDsar in inputDsars.Items)
            {
                if (!(inputDsar is DSARType))
                {
                    if (Convert.ToString(inputDsar) == Constantfields.NODATA)
                    {
                        _sb.AppendLine(humanFriendlyDsar.BuildNoData(inputDsar as string));
                    }
                    continue;
                }               
                _sb.AppendLine(humanFriendlyDsar.Build(inputDsar as DSARType));
                dsarRequest.Add(humanFriendlyDsar.dsarRequest);
            }
        }

        private void GenerateFileNames()
        {
            var buFileStorePath = ConfigurationManager.AppSettings["humanReadableFileShareLocation"];
            var inpFileNameWoExtension = Path.GetFileNameWithoutExtension(InputFileName);
            var curreDateTime = DateTime.Now.ToString("yyyyMMddhhmmtt");
            GeneratedFileName = Path.Combine(buFileStorePath, inpFileNameWoExtension
                                                              + "_Services.txt");
            ErrorFileName = Path.Combine(buFileStorePath,
                inpFileNameWoExtension + "_Services.Error.txt");
        }
    }
}