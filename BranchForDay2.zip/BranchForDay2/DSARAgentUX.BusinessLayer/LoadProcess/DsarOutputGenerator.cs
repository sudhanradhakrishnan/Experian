﻿using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Models.ServiceNow.Request;
using System.Collections.Generic;

namespace DSARAgentUX.BusinessLayer
{
    public class DsarOutputGenerator
    {
        public readonly List<IDSAROutput> _list = new List<IDSAROutput>();
        public void AddGenerator(IDSAROutput output)
        {
            _list.Add(output);
        }

        public void BuildAll(string inputFilePath)
        {
            foreach (var item in _list)
            {
                item.Build(inputFilePath);
            }
        }
    }
}