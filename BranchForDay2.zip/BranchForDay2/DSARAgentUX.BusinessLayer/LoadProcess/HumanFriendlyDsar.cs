﻿using DSARAgentUX.Common;
using DSARAgentUX.Models;
using DSARAgentUX.Models.ServiceNow.Request;
using System.Collections.Generic;
using System.Text;

namespace DSARAgentUX.BusinessLayer
{
    public class HumanFriendlyDsar
    {
        private StringBuilder _sb;

        private readonly string _separatorLine = new string('=', 80);

        public SnowOrderDsarRequest dsarRequest { get; set; }

        private List<string> selectedDataSources { get; set; }


        public string Build(DSARType dsar)
        {
            selectedDataSources = new List<string>();
            _sb = new StringBuilder();
            _sb.AppendLine(_separatorLine);
            _sb.AppendLine($"DSAR Reference : {dsar.Reference}");
            _sb.AppendLine($"Requested Date : {dsar.RequestDate:d}");
            _sb.AppendLine(_separatorLine);
            dsarRequest = new SnowOrderDsarRequest
            {
                dsar_ref = dsar.Reference,
                dsar_due_date = $"{dsar.RequestDate:yyyy-MM-dd}"
            };

            var dataSources = dsar.DataSources;

            for (var i = 0; i < 5; i++)
            {
                var humanIndex = i + 1;
                
                if (dataSources.AdditionBusinessInformation != null && i < dataSources.AdditionBusinessInformation.Length)
                {
                    AddDataSourceRequiredLine(true,
                        dataSources.AdditionBusinessInformation[i].Item is LimitedCompanyType
                            ? $"{HumanFriendlyNames.GetFriendyName("LimitedCompany")} ({humanIndex})"
                            : $"{HumanFriendlyNames.GetFriendyName("NonLimitedCompany")} ({humanIndex})");
                }
                else
                {
                    AddDataSourceRequiredLine(false,
                        $"{HumanFriendlyNames.GetFriendyName("LimitedCompany")} ({humanIndex})");
                }
            }

            AddDataSourceRequiredLine(dsar.DataSources.MarketingServices != null,
                HumanFriendlyNames.GetFriendyName("MarketingServices"));
            AddDataSourceRequiredLine(dsar.DataSources.AffordabilityInformation != null,
                HumanFriendlyNames.GetFriendyName("AffordabilityInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.HRInformation != null,
                HumanFriendlyNames.GetFriendyName("HRInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.HistoricCreditReport != null,
                HumanFriendlyNames.GetFriendyName("HistoricCreditReport"));
            AddDataSourceRequiredLine(dsar.DataSources.ExperianID != null,
                HumanFriendlyNames.GetFriendyName("ExperianID"));
            AddDataSourceRequiredLine(dsar.DataSources.WebMonitoringInformation != null,
                HumanFriendlyNames.GetFriendyName("WebMonitoringInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.BackgroundCheckingInformation != null,
                HumanFriendlyNames.GetFriendyName("BackgroundCheckingInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.UnclaimedAssetRegister != null,
                HumanFriendlyNames.GetFriendyName("UnclaimedAssetRegister"));
            AddDataSourceRequiredLine(dsar.DataSources.ExperianClientRelatedInformation != null,
                HumanFriendlyNames.GetFriendyName("ExperianClientRelatedInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.AutomotiveInformation != null,
                HumanFriendlyNames.GetFriendyName("AutomotiveInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.ComparisonServiceInformation != null,
                HumanFriendlyNames.GetFriendyName("ComparisonServiceInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.DetailOfContactWithExperianInformation != null,
                HumanFriendlyNames.GetFriendyName("DetailOfContactWithExperianInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.CreditExpertAndFreeAccountInformation != null,
                HumanFriendlyNames.GetFriendyName("CreditExpertAndFreeAccountInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.CreditAccountsTracingInformation != null,
                HumanFriendlyNames.GetFriendyName("CreditAccountsTracingInformation"));
            AddDataSourceRequiredLine(dsar.DataSources.FraudDetectionInformation != null,
                HumanFriendlyNames.GetFriendyName("FraudDetectionInformationType"));
            AddDataSourceRequiredLine(dsar.DataSources.AudioRecordingsInformation != null,
              HumanFriendlyNames.GetFriendyName("AudioRecordings"));

            _sb.AppendLine();
            _sb.AppendLine(_separatorLine);
            _sb.AppendLine();
            dsarRequest.items = selectedDataSources.ToArray();
            return _sb.ToString();
        }

        public string BuildNoData(string nodata)
        {
            _sb = new StringBuilder();
            _sb.AppendLine(_separatorLine);
            _sb.AppendLine($"NO DATA");
            _sb.AppendLine(_separatorLine);
            _sb.AppendLine();
            return _sb.ToString();
        }

        private void AddDataSourceRequiredLine(bool isSelected, string optionName)
        {
            var val = isSelected ? "X" : " ";

            _sb.AppendLine($"[{val}] {optionName}");
            if (isSelected)
            {
                selectedDataSources.Add($"{optionName}");
            }
        }
    }
}