﻿using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Models.ServiceNow.Request;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Xml.Linq;

namespace DSARAgentUX.BusinessLayer
{
    public class BUFileDsarOutput : IDSAROutput
    {
        private readonly IDsarBatchComponentService _ssarBatchService;
        public string GeneratedFileName { get; set; }
        public string ErrorFileName { get; set; }
        public string InputFileName { get; set; }
        public List<SnowOrderDsarRequest> dsarRequest { get; set; }

        public XDocument BUFileContent { get; set; }

        public BUFileDsarOutput(string inputFile)
        {
            InputFileName = inputFile;
            _ssarBatchService = new DsarBatchComponentService();
            dsarRequest = null;//Setting to null as we will not use in SnowTaskGenerator
        }

        public void Build(string inputPath)
        {
            GenerateFileNames();
            BUFileContent = GenerateBIFileContent();
            //fileContent.Save(GeneratedFileName);
        }

        private void GenerateFileNames()
        {
            var buFileStorePath = ConfigurationManager.AppSettings["buFileShareLocation"];
            var inpFileNameWOExtension = Path.GetFileNameWithoutExtension(InputFileName);
            var curreDateTime = DateTime.Now.ToString("yyyyMMddhhmmtt");
            GeneratedFileName = Path.Combine(buFileStorePath, inpFileNameWOExtension + "_BU.xml");
            ErrorFileName = Path.Combine(buFileStorePath,
                inpFileNameWOExtension + "_BU.Error.xml");
        }

        private XDocument GenerateBIFileContent()
        {
            var xDocument = XDocument.Load(InputFileName);
            var referenceXmlFromDb = _ssarBatchService.GetReferencedXmlFromDb(xDocument);
            if (referenceXmlFromDb != null && referenceXmlFromDb.Count > 0)
            {
                return _ssarBatchService.GenerateBiFile(InputFileName, referenceXmlFromDb);
            }

            return xDocument;
        }
    }
}