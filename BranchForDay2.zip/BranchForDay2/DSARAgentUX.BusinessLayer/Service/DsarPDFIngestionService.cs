﻿using DSARAgentUX.BusinessLayer.API_Proxies;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.BusinessLayer.ServiceNow.Response;
using DSARAgentUX.DataAccessLayer.Interface;
using DSARAgentUX.DataAccessLayer.Repositories;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using DSARAgentUX.Models.ServiceNow.Request;
using ExperianLogger;

namespace DSARAgentUX.BusinessLayer
{
    public class DsarPDFIngestionService : DSARServiceBase, IDsarPDFIngestionService
    {

        private readonly ILogger _logger;

        private readonly IFileUploadRepository _fileUploadRepository;

        private readonly SecurityRepository _securityRepository;
        public DsarPDFIngestionService()
        {
            _logger = new Logger();
            _fileUploadRepository = new FileUploadRepository();

            _securityRepository = new SecurityRepository(GetSecurityInformation());
        }
        public bool CheckDuplicatePDF(string dsarNumber, string pdfReference)
        {
            return _fileUploadRepository.CheckDuplicatePDF(dsarNumber, pdfReference);
        }
        public bool CheckDuplicatePostalPDF(string dsarNumber, string pdfReference)
        {
            return _fileUploadRepository.CheckDuplicatePostalPDF(dsarNumber, pdfReference);
        }

        public int UploadPdf(PdfFileDetails pdffile, PDFStatusType status, string dsarReference, string pdfReference, string userId)
        {
            pdffile.FileName= _securityRepository.GetPdfFileName(dsarReference, pdfReference);
            return _fileUploadRepository.UploadPdf(pdffile, status, dsarReference, pdfReference, userId);
        }

        public int UploadStateNoDataPDF(string filePath, string DSARReference, string PDFReference, string FileName, string ModifiedBy)
        { 
            return _fileUploadRepository.UploadStateNoDataPDF(filePath, _securityRepository.GetNoDataFileName(PDFReference), DSARReference, PDFReference, ModifiedBy);
        }

        public int UploadPostalPdf(PdfFileDetails pdffile, PDFStatusType status, string dsarReference, string pdfReference, string userId)
        {
            pdffile.FileName = _securityRepository.GetPdfFileName(dsarReference, pdfReference);
            return _fileUploadRepository.UploadPostalPdf(pdffile, status, dsarReference, pdfReference, userId);
        }

        public string UpdateSnowDsarUploadTask(SnowUpdateDsarRequest snowUpdateDsarRequest)
        {
            using (var api = new ServiceNowApi())
            {
                return api.UpdateDsarUploadTask(snowUpdateDsarRequest);
            }

        }

        public string UpdateSnowDsarReviewTask(SnowUpdateDsarRequest snowUpdateDsarRequest)
        {
            using (var api = new ServiceNowApi())
            {
                return api.UpdateDsarReviewTask(snowUpdateDsarRequest);
            }

        }
    }
}
