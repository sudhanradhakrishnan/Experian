﻿using DSARAgentUX.Common;
using DSARAgentUX.DataAccessLayer.Interface;
using DSARAgentUX.DataAccessLayer.Repositories;
using DSARAgentUX.Models;
using System.Configuration;
using System.IO;
using System.Xml;

namespace DSARAgentUX.BusinessLayer
{
    public  abstract class DSARServiceBase
    {

        private readonly IViewPdfRepository _viewPdfRepository;
        public DSARServiceBase()
        {
            _viewPdfRepository = new ViewPdfRepository();
        }

        protected securityType GetSecurityInformation()
        {
            var mappingFile = new XmlDocument
            {
                XmlResolver = null
            };

            var fs = new FileStream(ConfigurationManager.AppSettings["Agent:securityXMLFullpath"], FileMode.Open, FileAccess.Read);
            mappingFile.Load(fs);

            return Utility.DeserializeXmlFileToObject<securityType>(mappingFile.ConvertXmltoString(), "security",
                "http://experian.com/DSAR_Security/v1");
        }

        public ServiceUserModel GetDsarInformation(string dsarReference)
        {
            return _viewPdfRepository.GetDsarInformation(dsarReference);
        }
    }
}
