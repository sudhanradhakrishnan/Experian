﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using DSARAgentUX.BusinessLayer.API_Proxies;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.BusinessLayer.ServiceNow.Response;
using DSARAgentUX.DataAccessLayer.Interface;
using DSARAgentUX.DataAccessLayer.Repositories;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using DSARAgentUX.Models.ServiceNow.Request;
using ExperianLogger;

namespace DSARAgentUX.BusinessLayer
{
    public class DsarBatchComponentService : IDsarBatchComponentService
    {

       // private readonly SecurityRepository _securityRepository;
        private readonly ILogger _logger;
        private readonly IDsarRepository _dsarRepository;
        private readonly IFileUploadRepository _fileUploadRepository;
        private readonly IViewPdfRepository _viewPdfRepository;
        private readonly IAvcoxmlRepository _avcoxmlRepository;
        private readonly IDsarRegInfoRepository _dsarRegInfoRep;

        public DsarBatchComponentService()
        {
            _logger = new Logger();
            _dsarRepository = new DsarRepository();
            _fileUploadRepository = new FileUploadRepository();
            _avcoxmlRepository = new AvcoXmlRepository();
            _viewPdfRepository = new ViewPdfRepository();
            _dsarRegInfoRep = new DsarRegInfoRespository();
        }
        #region "DSARExport Services"
        public List<DsarZipWrapper> GetAllPublishedDsarZipMem()
        {
            var list = new List<DsarZipWrapper>();

            var listofDsar = _dsarRepository.GetReadyToPublishedDsars();

            foreach (var dsar in listofDsar)
            {
                if (dsar.Reference == null)
                    continue;

                list.Add(new DsarZipWrapper
                {
                    DsarValue = dsar,
                    ZipInMemory = GetDsarZipMemByDsarReference(dsar.Reference)
                });
            }

            return list;
        }


        public MemoryStream GetDsarZipMemByDsarReference(string dsarReferenceNumber)
        {
            return CreateZipInMemory(dsarReferenceNumber);
        }


        private MemoryStream CreateZipInMemory(string dsarReferenceNumber)
        {
            var pdfModels = _fileUploadRepository.GetListOfPdfForReadyToPublishDsars(dsarReferenceNumber);

            using (var compressedFileStream = new MemoryStream())
            {
                using (var zipArchive = new ZipArchive(compressedFileStream, ZipArchiveMode.Update, false))
                {
                    var debugSetting = Convert.ToBoolean(ConfigurationManager.AppSettings["IsHeaderPDFAttached"]);
                    if (debugSetting)
                        StorePdfMemoryintoZip(zipArchive, new PdfFileDetails { FileName = Constantfields.HeaderPdfName, FileContent = Utility.LoadFileContent(string.Empty) });
                    foreach (var model in pdfModels)
                    {
                        model.FileContent = _viewPdfRepository.GetPdfFile(model.DsarReference, model.PdfReference).FileContent;
                        StorePdfMemoryintoZip(zipArchive, model);
                    }

                    return compressedFileStream;
                }
            }
        }


        private static void StorePdfMemoryintoZip(ZipArchive zipArchive, PdfFileDetails model)
        {
            var zipEntry = zipArchive.CreateEntry(model.FileName);
            using (var originalFileStream = new MemoryStream(model.FileContent))
            using (var zipEntryStream = zipEntry.Open())
            {
                originalFileStream.CopyTo(zipEntryStream);
            }
        }

        public void UpdatePublishStatus(string dsarReferenceId)
        {
            _viewPdfRepository.UpdateDsarPublishStatus(dsarReferenceId, PublishStatusType.Published, DsarStatusType.Published);
        }
        public List<DsarInformation> DropCsvForCompletedAndDuplicateDsaRs()
        {
            return _dsarRepository.GetCompletedAndDuplicateAndCancelledDsars();
        }


        public void UpdateCancelDuplicateInformation()
        {
            int returnOutput = _dsarRepository.UpdateCancelDuplicate();
            string action = string.Empty;
            switch (returnOutput)
            {
                case 0:
                    action = Constantfields.FAILED;
                    break;
                case 1:
                    action = Constantfields.SUCCESS;
                    break;
            }
            _logger.LogApplicationInfo("DSAREXPORT01", $"DSAR Table Update Cancel,Duplicate and Status Information to DataBase: { action } ");

        }
        #endregion
        
        #region "DSARLoad Services"

        public bool CheckDsarDuplicate(string dsarReference)
        {
            var xdoc = _dsarRepository.CheckDsarDuplicate(dsarReference);
            return xdoc;
        }

        public void SaveAvcoxml(string xmlAvcoData)
        {
            _avcoxmlRepository.SaveAvcoxml(xmlAvcoData);
        }

        public Dictionary<string, string> GetReferencedXmlFromDb(XDocument xDocument)
        {
            if (xDocument == null)
                return null;
            var referencedXml = new Dictionary<string, string>();
            var dsars = xDocument.Descendants("dsar");


            var references = dsars
                .Select(item => item.Descendants().FirstOrDefault(p => p.Name.LocalName == "Reference")?.Value)
                .ToList();

            if (references.Count > 0)
            {
                referencedXml = GetRegInformationForReferences(references);
            }
            return referencedXml;
        }
        public XDocument GenerateBiFile(string fullXmlPath, Dictionary<string, string> regInfoXmlFromDb)
        {
            var inputXDoc = XDocument.Load(fullXmlPath);
            var inputDsars = inputXDoc.Descendants("dsar");
            foreach (var inputDsarItem in inputDsars)
            {
                var inputRefId = inputDsarItem.Descendants().FirstOrDefault(p => p.Name.LocalName == "Reference")
                    ?.Value;

                if (IsReferencePresent(regInfoXmlFromDb, inputRefId))
                {
                    DoProcessing(regInfoXmlFromDb, inputRefId, inputDsarItem);
                }
            }

            return inputXDoc;
        }

        public SnowResponse CreateTaskInSnow(SnowOrderDsarRequest taskinformation)
        {
            var snowResponse = new SnowResponse();
            var serviceNowApi = new ServiceNowApi();
            snowResponse = serviceNowApi.CreateTaskInServiceNow(taskinformation);
            return snowResponse;
        }
        #endregion

        #region private methods

        private Dictionary<string, string> GetRegInformationForReferences(List<string> references)
        {
            return _dsarRegInfoRep.GetAllRegInfoXml(references);
        }



        private static bool IsReferencePresent(IReadOnlyDictionary<string, string> regInfoXmlFromDb, string inputRefId)
        {
            return inputRefId != null && regInfoXmlFromDb.ContainsKey(inputRefId);
        }

        private static void DoProcessing(IReadOnlyDictionary<string, string> regInfoXmlFromDb, string inputRefId,
            XElement inputDsarItem)
        {
            var regInfoXDoc = XDocument.Load(new StringReader(regInfoXmlFromDb[inputRefId]));

            TransferPersonalDetails(inputDsarItem, regInfoXDoc);
            TransferAddressDetails(inputDsarItem, regInfoXDoc);
        }

        private static void TransferAddressDetails(XElement inputDsarItem, XDocument regInfoXDoc)
        {
            var inputAddressDetails = inputDsarItem.Descendants("Address");
            var additionalAddr = regInfoXDoc.Descendants("AdditionalAddresses").FirstOrDefault()
                ?.Descendants("AddressModel").ToList();

            if (additionalAddr == null)
                return;

            foreach (var regInfoAddritem in additionalAddr)
            {
                var addrStructure = new XElement("StructuredAddress");
                if (regInfoAddritem.Element("Flat") != null)
                    addrStructure.Add(new XElement("Flat", regInfoAddritem.Element("Flat")?.Value));
                if (regInfoAddritem.Element("HouseNumber") != null)
                    addrStructure.Add(new XElement("HouseNumber", regInfoAddritem.Element("HouseNumber")?.Value));
                if (regInfoAddritem.Element("HouseName") != null)
                    addrStructure.Add(new XElement("HouseName", regInfoAddritem.Element("HouseName")?.Value));
                if (regInfoAddritem.Element("Street") != null)
                    addrStructure.Add(new XElement("Street", regInfoAddritem.Element("Street")?.Value));
                if (regInfoAddritem.Element("District") != null)
                    addrStructure.Add(new XElement("District", regInfoAddritem.Element("District")?.Value));
                if (regInfoAddritem.Element("PostTown") != null)
                    addrStructure.Add(new XElement("PostTown", regInfoAddritem.Element("PostTown")?.Value));
                if (regInfoAddritem.Element("County") != null)
                    addrStructure.Add(new XElement("County", regInfoAddritem.Element("County")?.Value));
                if (regInfoAddritem.Element("Postcode") != null)
                    addrStructure.Add(new XElement("Postcode", regInfoAddritem.Element("Postcode")?.Value));
                if (regInfoAddritem.Element("DateFrom") != null)
                    addrStructure.Add(new XElement("FromDate",
                        regInfoAddritem.Element("DateFrom")?.Value.Substring(0, 10)));
                if (regInfoAddritem.Element("DateTo") != null)
                    addrStructure.Add(new XElement("ToDate",
                        regInfoAddritem.Element("DateTo")?.Value.Substring(0, 10)));

                inputAddressDetails.FirstOrDefault().AddFirst(addrStructure);

                if (inputAddressDetails.Descendants("FormattedAddress").Any())
                    inputAddressDetails.Descendants("FormattedAddress").Remove();
            }
        }

        private static void TransferPersonalDetails(XElement inputDsarItem, XDocument regInfoXDoc)
        {
            var inputPersonDetail = inputDsarItem.Descendants("Person");
            var structName = new XElement("StucturedName");
            var regInfoPersonDetail = regInfoXDoc.Descendants("Person").FirstOrDefault();

            if (regInfoPersonDetail?.Element("Title") != null)
                structName.Add(new XElement("Title", regInfoPersonDetail.Element("Title")?.Value));
            if (regInfoPersonDetail?.Element("Forename") != null)
                structName.Add(new XElement("Forename", regInfoPersonDetail.Element("Forename")?.Value));
            if (regInfoPersonDetail?.Element("Middlename") != null)
                structName.Add(new XElement("Middlename", regInfoPersonDetail.Element("Middlename")?.Value));
            if (regInfoPersonDetail?.Element("Surname") != null)
                structName.Add(new XElement("Surname", regInfoPersonDetail.Element("Surname")?.Value));
            if (regInfoPersonDetail?.Element("Suffix") != null)
                structName.Add(new XElement("Suffix", regInfoPersonDetail.Element("Suffix")?.Value));

            var personDetail = inputPersonDetail.ToList();

            if (!personDetail.Descendants("StucturedName").Any())
            {
                personDetail.FirstOrDefault()?.AddFirst(structName);
                if (personDetail.Descendants("FormattedName").Any())
                    personDetail.Descendants("FormattedName").Remove();
            }
        }
        #endregion
    }
}