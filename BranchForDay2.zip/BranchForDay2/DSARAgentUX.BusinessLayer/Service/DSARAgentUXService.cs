﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Linq;

using DSARAgentUX.BusinessLayer.API_Proxies;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Common;
using DSARAgentUX.DataAccessLayer.Interface;
using DSARAgentUX.DataAccessLayer.Repositories;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using DSARAgentUX.Models.ServiceNow.Request;
using ExperianLogger;

namespace DSARAgentUX.BusinessLayer
{
    public class DSARAgentUXService : IDSARAgentUXService
    {
        private readonly SecurityRepository _securityRepository;
        private readonly ILogger _logger;
        private readonly IDsarRepository _dsarRepository;
        private readonly IFileUploadRepository _fileUploadRepository;
        private readonly IViewPdfRepository _viewPdfRepository;
        private readonly IAvcoxmlRepository _avcoxmlRepository;
        private readonly IDsarRegInfoRepository _dsarRegInfoRep;

        public DSARAgentUXService()
        {
            _securityRepository = new SecurityRepository(GetSecurityInformation());
            _logger = new Logger();
            _dsarRepository = new DsarRepository();
            _fileUploadRepository = new FileUploadRepository();
            _viewPdfRepository = new ViewPdfRepository();
            _avcoxmlRepository = new AvcoXmlRepository();
            _dsarRegInfoRep = new DsarRegInfoRespository();
        }

        public void UploadReportData(PdfFileDetails pdfFile, string dsarNumber, string pdfReference, string userId)
        {
            pdfFile.FileName = _securityRepository.GetPdfFileName(dsarNumber, pdfReference);

            UploadReportItem(dsarNumber, PDFStatusType.Uploaded, pdfReference, userId, pdfFile.FileName, pdfFile);
        }
        public void UploadPostalReportData(PdfFileDetails pdfFile, string dsarNumber, string pdfReference, string userId)
        {
            pdfFile.FileName = _securityRepository.GetPdfFileName(dsarNumber, pdfReference);

            UploadPostalReportItem(dsarNumber, PDFStatusType.Uploaded, pdfReference, userId, pdfFile.FileName, pdfFile);
        }
        public void UploadReportNoData(string dsarReference, string pdfReference, string userId)
        {


            var pdfFile = new PdfFileDetails
            {
                FileName = _securityRepository.GetNoDataFileName(pdfReference)

            };


            UploadReportItem(dsarReference, PDFStatusType.State_No_Data, pdfReference, userId, pdfFile.FileName, pdfFile);

        }

        private void UploadReportItem(string dsarReference, PDFStatusType status, string pdfReference, string userId, string actualPdfName, PdfFileDetails pdfFile)
        {
            string pdfAction = string.Empty;
            string action = string.Empty;
            int pdfActionstate = 0;

            if (status == PDFStatusType.State_No_Data)
            {
                pdfActionstate = _fileUploadRepository.UploadStateNoDataPDF(ConfigurationManager.AppSettings["db:nodata"], pdfFile.FileName, dsarReference, pdfReference, userId);
            }
            else
            {
                pdfActionstate = _fileUploadRepository.UploadPdf(pdfFile, status, dsarReference, pdfReference, userId);

            }

            AuditEventsType audEvent = AuditEventsType.NOACTION;
            switch (pdfActionstate)
            {
                case 1:
                    pdfAction = Constantfields.INSERTED;
                    audEvent = AuditEventsType.UPLOADPDF;
                    action = Constantfields.SUCCESS;
                    break;
                case 2:
                    pdfAction = Constantfields.UPDATED;
                    audEvent = AuditEventsType.REPLACEPDF;
                    action = Constantfields.SUCCESS;
                    break;
                case -1:
                    pdfAction = Constantfields.INSERTED;
                    audEvent = AuditEventsType.UPLOADPDF;
                    action = Constantfields.FAILED;
                    break;
                case 0:
                    pdfAction = Constantfields.UPDATED;
                    audEvent = AuditEventsType.REPLACEPDF;
                    action = Constantfields.FAILED;
                    break;
            }
            if (status == PDFStatusType.State_No_Data)
            {
                audEvent = AuditEventsType.STATENODATA;
                pdfAction = $" {pdfAction} (No Data)";

            }

            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarReference,
                PdfReference = pdfReference,
                ModifyedPdfName = pdfFile.FileName,
                ActualPdfName = actualPdfName,
                UserId = userId,
                IsPdFuploaded = true,
                Operation = audEvent
            });

            _logger.LogApplicationInfo("DSARUPLOAD",
                 $"User {userId} has {pdfAction} item ref {pdfReference} for Dsar {dsarReference} with {actualPdfName} :- {action}"
                );

            if (pdfActionstate <= 0)
            {
                throw new DSARException("Unable process report upload request");
            }

            //ServiceNowUpdate(userId, dsarReference, pdfReference);
        }


        private void ServiceNowUpdate(string userId, string dsarRef, string reportRef)
        {

            var dsarPdfIngestionService = new DsarPDFIngestionService();

            var snowResponse = dsarPdfIngestionService.UpdateSnowDsarUploadTask(new SnowUpdateDsarRequest() { dsar_ref = dsarRef, dsar_pdf = reportRef });

            string snowMessage;
            snowMessage = snowResponse.Equals("API_FAILURE") == true
                ? $"User {userId} failed to update ServiceNow Upload task against DSAR:{dsarRef} & Report:{reportRef}"
                : $"User {userId} updated ServiceNow Upload task against DSAR:{dsarRef} & Report:{reportRef}";

            _logger.LogApplicationInfo("DSARUPLOAD", snowMessage);


            var snowReviewResponse = dsarPdfIngestionService.UpdateSnowDsarReviewTask(new SnowUpdateDsarRequest() { dsar_ref = dsarRef, dsar_pdf = reportRef });



            string snowReviewMessage;
            snowReviewMessage = snowReviewResponse.Equals("API_FAILURE") == true
                ? $"User {userId} failed to update ServiceNow Review task against DSAR:{dsarRef} & Report:{reportRef}"
                : $"User {userId} updated ServiceNow Review task against DSAR:{dsarRef} & Report:{reportRef}";

            _logger.LogApplicationInfo("DSARREVIEW", snowReviewMessage);

        }

        private void UploadPostalReportItem(string dsarReference, PDFStatusType status, string pdfReference, string userId, string actualPdfName, PdfFileDetails pdfFile)
        {
            string pdfAction = string.Empty;
            string action = string.Empty;
            int pdfActionstate = 0;

            pdfActionstate = _fileUploadRepository.UploadPostalPdf(pdfFile, status, dsarReference, pdfReference, userId);

            AuditEventsType audEvent = AuditEventsType.NOACTION;
            switch (pdfActionstate)
            {
                case 1:
                    pdfAction = Constantfields.INSERTED;
                    audEvent = AuditEventsType.UPLOADPDF;
                    action = Constantfields.SUCCESS;
                    break;
                case 2:
                    pdfAction = Constantfields.UPDATED;
                    audEvent = AuditEventsType.REPLACEPDF;
                    action = Constantfields.SUCCESS;
                    break;
                case -1:
                    pdfAction = Constantfields.INSERTED;
                    audEvent = AuditEventsType.UPLOADPDF;
                    action = Constantfields.FAILED;
                    break;
                case 0:
                    pdfAction = Constantfields.UPDATED;
                    audEvent = AuditEventsType.REPLACEPDF;
                    action = Constantfields.FAILED;
                    break;
            }
            if (status == PDFStatusType.State_No_Data)
            {
                audEvent = AuditEventsType.STATENODATA;
                pdfAction = $" {pdfAction} (No Data)";

            }

            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarReference,
                PdfReference = pdfReference,
                ModifyedPdfName = pdfFile.FileName,
                ActualPdfName = actualPdfName,
                UserId = userId,
                IsPdFuploaded = true,
                Operation = audEvent
            });

            _logger.LogApplicationInfo("DSARUPLOAD",
                 $"User {userId} has {pdfAction} item ref {pdfReference} for Dsar {dsarReference} with {actualPdfName} :- {action}"
                );

            if (pdfActionstate <= 0)
            {
                throw new DSARException("Unable process the request");
            }

        }
        public string PdfName(PdfFileDetails pdfFile, string dsarNumber, string pdfReference)
        {
            pdfFile.FileName = _securityRepository.GetPdfFileName(dsarNumber, pdfReference);
            return pdfFile.FileName;
        }

        public ServiceUserModel GetDsarInformation(string dsarReference)
        {
            ServiceUserModel dsarObject = _viewPdfRepository.GetDsarInformation(dsarReference);
            dsarObject.DataSubjectAccessRequest = Utility.DeserializeXmlFileToObject<dsars>(Utility.ReformatXmLforDsarsClass(dsarObject.xmlcontent), "dsars", "http://experian.com/DSAR_Submission/v1");

            return dsarObject;
        }


        public List<ServiceUserModel> GetAllUploadedPdfDetails(string dsarReferenceId)
        {
            return _viewPdfRepository.GetAllUploadedPdfDetails(dsarReferenceId);
        }

        public List<ServiceUserModel> GetUploadedPdfDetails(string dsarReferenceId, string pdfReference)
        {
            return _viewPdfRepository.GetUploadedPdfDetails(dsarReferenceId, pdfReference); ;
        }
        public List<ServiceUserModel> GetAllUploadedPostalPdfDetails(string dsarReferenceId)
        {
            return _viewPdfRepository.GetAllUploadedPostalPdfDetails(dsarReferenceId);
        }

        public List<ServiceUserModel> GetUploadedPostalPdfDetails(string dsarReferenceId, string pdfReference)
        {
            return _viewPdfRepository.GetUploadedPostalPdfDetails(dsarReferenceId, pdfReference); ;
        }
        public DepartmentUserModel GePdfStatus(string dsarReferenceId, string pdfReference)
        {
            return _viewPdfRepository.GePdfStatus(dsarReferenceId, pdfReference);
        }


        public void RemovePdf(string dsarReference, string pdfReference, string userId)
        {
            int returnOutput = _viewPdfRepository.RemovePdf(dsarReference, pdfReference, userId);
            string action = string.Empty;
            AuditEventsType AudEvent = AuditEventsType.REMOVEPDF;
            switch (returnOutput)
            {
                case 1:
                    action = Constantfields.RemoveItem;
                    break;
                case 0:
                    action = Constantfields.RemoveFailed;
                    break;
            }
            _logger.LogApplicationInfo("DSARRemove",
                 $"User {userId} for Dsar {dsarReference} item {pdfReference} : {action} ");


            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarReference,
                PdfReference = pdfReference,
                UserId = userId,
                Operation = AudEvent
            });


            if (returnOutput == 0)
                throw new DSARException("Unable to Remove PDF");

        }

        public void UpdateDsarCancelStatus(string dsarReferenceNumber, DsarCancelType dsarCancel, string userId, DsarStatusType dsarStatus, AuditEventsType audEvent)
        {
            int returnOutput = _viewPdfRepository.UpdateDsarCancelStatus(dsarReferenceNumber, dsarCancel, dsarStatus);
            string action = string.Empty;
            string auditstring = "cancel";
            if (dsarCancel == DsarCancelType.None)
                auditstring = "Undo cancel";

            switch (returnOutput)
            {
                case 0:
                    action = Constantfields.FAILED;
                    break;
                case 1:
                    action = Constantfields.SUCCESS;
                    break;
            }
            _logger.LogApplicationInfo("DSARCANCELLED",
                $"User {userId} for Dsar {dsarReferenceNumber} try to {auditstring}  :- {action} ");


            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarReferenceNumber,
                UserId = userId,
                Operation = audEvent
            });


            if (returnOutput == 0)
                throw new DSARException("Unable to mark as Cancelled");


        }

        public void UpdateRemoveDuplicateStatus(string dsarReferenceNumber, DuplicateCheckStatusType status, string userId)
        {
            int returnOutput = _viewPdfRepository.UpdateRemoveDuplicateStatus(dsarReferenceNumber, status);
            string action = string.Empty;
            string auditstring = "mark duplicate";
            AuditEventsType audit = AuditEventsType.REMOVEDUPLICATE;
            if (status == DuplicateCheckStatusType.None)
            {
                audit = AuditEventsType.UNDOREMOVEDUPLICATE;
                auditstring = "Undo mark duplicate";
            }

            switch (returnOutput)
            {
                case 0:
                    action = Constantfields.FAILED;
                    break;
                case 1:
                    action = Constantfields.SUCCESS;
                    break;
            }
            _logger.LogApplicationInfo("DSARDUPLICATE",
                 $"User {userId} for Dsar {dsarReferenceNumber} try to {auditstring}  :- {action} ");

            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarReferenceNumber,
                UserId = userId,
                Operation = audit
            });

            if (returnOutput == 0)
                throw new DSARException("Unable to mark as Remove duplicate");
        }

        public ServiceUserModel GetCancelledUsernameByReference(string dsarReferenceId)
        {
            return _viewPdfRepository.GetCancelledUsernameByReference(dsarReferenceId);
        }
        public void UpdatePublishStatus(string dsarReferenceNumber, PublishStatusType status, string userId)
        {
            AuditEventsType audit = AuditEventsType.UNDOPUBLISHDSAR;
            DsarStatusType dsarStatus = DsarStatusType.Active;
            string auditstring = "Undo publish";
            if (status == PublishStatusType.ReadyToPublish)
            {
                audit = AuditEventsType.PUBLISHDSAR;
                dsarStatus = DsarStatusType.Published;
                auditstring = "publish";
            }

            int returnOutput = _viewPdfRepository.UpdateDsarPublishStatus(dsarReferenceNumber, status, dsarStatus);
            string action = string.Empty;
            switch (returnOutput)
            {
                case 0:
                    action = Constantfields.FAILED;
                    break;
                case 1:
                    action = Constantfields.SUCCESS;
                    break;
            }
            _logger.LogApplicationInfo("DSARPublish",
                $"User {userId} for Dsar {dsarReferenceNumber} try to {auditstring}  :- {action} ");

            // CaptureEvent(dsarReferenceNumber, audit, userId);
            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarReferenceNumber,
                UserId = userId,
                Operation = audit
            });

            if (returnOutput == 0)
                throw new DSARException(Constantfields.PUBLISHEXCEPTION);

        }



        public ServiceUserModel GetPdfFile(string dsarReference, string pdfReference)
        {

            return _viewPdfRepository.GetPdfFile(dsarReference, pdfReference);
        }



        public void CaptureEvent(Audit audit)
        {
            _viewPdfRepository.CaptureEvent(audit);
        }

        public CurrentUser ValidateCurrentUser()
        {
            string userId = string.Empty;
            try
            {
                userId = HttpContext.Current.GetOwinContext().Authentication.User.Claims
                    .First(m => m.Type.Contains(@"identity/claims/nameidentifier")).Value.Split('@')[0];
            }
            catch (Exception e)
            {
                throw new DSARException("User Authentication Failed." + e.Message);
            }

            string userSubstitute = ConfigurationManager.AppSettings["Snow:UserSubstitue"];

            if (!string.IsNullOrEmpty(userSubstitute)) // TODO: to be removed later , added this to cope with the Servicenow API which development is in progress
            {
                userId = userSubstitute;
            }


            string[] arrGroups;
            using (var snowApi = new ServiceNowApi())
            {
                arrGroups = snowApi.GetDsarGroups(userId);
            }


                return new CurrentUser(_securityRepository.SecurityInformation,
                    new UserAuthProfile(
                        userId
                        // new ServiceNowApi().GetDsarGroups(userId),
                        , arrGroups
                        , _securityRepository.SecurityInformation.groups
                        )
                    );

        }

        public securityType GetSecurityInformation()
        {
            var mappingFile = new XmlDocument
            {
                XmlResolver = null
            };

            var fs = new FileStream(ConfigurationManager.AppSettings["Agent:securityXMLFullpath"], FileMode.Open, FileAccess.Read);
            mappingFile.Load(fs);

            return Utility.DeserializeXmlFileToObject<securityType>(mappingFile.ConvertXmltoString(), "security",
                "http://experian.com/DSAR_Security/v1");
        }


        public List<pdfType> GetAllPdfMaps()
        {
            return _securityRepository.GetAllPdfMaps();
        }

        public void RemovePostalReport(string dsarReference, string pdfReference, string userId)
        {
            int returnOutput = _viewPdfRepository.RemovePostalReport(dsarReference, pdfReference, userId);
            string action = string.Empty;
            AuditEventsType AudEvent = AuditEventsType.REMOVEPDF;
            switch (returnOutput)
            {
                case 1:
                    action = Constantfields.RemoveItem;
                    break;
                case 0:
                    action = Constantfields.RemoveFailed;
                    break;
            }
            _logger.LogApplicationInfo("DSARRemove",
                $"User {userId} for Dsar {dsarReference} item {pdfReference} : {action} ");


            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarReference,
                PdfReference = pdfReference,
                UserId = userId,
                Operation = AudEvent
            });


            if (returnOutput == 0)
                throw new DSARException("Unable to Remove Report");

        }


        public ServiceUserModel GetPostalReportFile(string dsarReference, string pdfReference)
        {

            return _viewPdfRepository.GetPostalReportFile(dsarReference, pdfReference);
        }



        public void CloseReviewTaskInSnow(string dsarRef, string reportRef, string userId)
        {
            var dsarPdfIngestionService = new DsarPDFIngestionService();

            var snowReviewResponse = dsarPdfIngestionService.UpdateSnowDsarReviewTask(new SnowUpdateDsarRequest() { dsar_ref = dsarRef, dsar_pdf = reportRef });

            string snowReviewMessage;
            snowReviewMessage = snowReviewResponse.Equals("API_FAILURE") == true
                ? $"User {userId} failed to update ServiceNow Review task against DSAR:{dsarRef} & Report:{reportRef}"
                : $"User {userId} updated ServiceNow Review task against DSAR:{dsarRef} & Report:{reportRef}";

            _logger.LogApplicationInfo("DSARREVIEW", snowReviewMessage);

            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarRef,
                PdfReference = reportRef,
                UserId = userId,
                Operation = AuditEventsType.CLOSEREVIEWTASKINSNOW
            });

        }
        public void CloseUploadTaskInSnow(string dsarRef, string reportRef, string userId)
        {

            var dsarPdfIngestionService = new DsarPDFIngestionService();

            var snowResponse = dsarPdfIngestionService.UpdateSnowDsarUploadTask(new SnowUpdateDsarRequest() { dsar_ref = dsarRef, dsar_pdf = reportRef });

            string snowMessage;
            snowMessage = snowResponse.Equals("API_FAILURE") == true
                ? $"User {userId} failed to update ServiceNow Upload task against DSAR:{dsarRef} & Report:{reportRef}"
                : $"User {userId} updated ServiceNow Upload task against DSAR:{dsarRef} & Report:{reportRef}";

            _logger.LogApplicationInfo("DSARUPLOAD", snowMessage);

            CaptureEvent(new Audit
            {
                DsarReferenceId = dsarRef,
                PdfReference = reportRef,
                UserId = userId,
                Operation = AuditEventsType.CLOSEUPLOADTASKINSNOW
            });

        }


        public bool ReadTaskStatusDsarUpload(string dsarReference, string pdfReference)
        {
            using (var api = new ServiceNowApi())
            {
                return api.ReadTaskStatusDsarUpload(new SnowUpdateDsarRequest() { dsar_ref = dsarReference, dsar_pdf = pdfReference });
            }
        }

        public bool ReadTaskStatusDsarReview(string dsarReference, string pdfReference)
        {
            using (var api = new ServiceNowApi())
            {
                return api.ReadTaskStatusDsarReview(new SnowUpdateDsarRequest() { dsar_ref = dsarReference, dsar_pdf = pdfReference });
            }
        }
    }
}