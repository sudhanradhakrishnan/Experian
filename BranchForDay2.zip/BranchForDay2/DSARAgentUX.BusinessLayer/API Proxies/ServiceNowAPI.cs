﻿using DSARAgentUX.BusinessLayer.ServiceNow.Response;
using DSARAgentUX.Models.ServiceNow;
using DSARAgentUX.Models.ServiceNow.Request;
using DSARAgentUX.Models.ServiceNow.Response;
using ExperianLogger;
using Microsoft.Win32.SafeHandles;
using Newtonsoft.Json;
using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;

namespace DSARAgentUX.BusinessLayer.API_Proxies
{

    public class ServiceNowApi : IDisposable
    {
        private readonly ILogger _logger;
        private enum Method { Post, Put, Get, Delete };


        private string _baseUrl;
        private string _getDsarGroups;
        private string _authorisation;

        bool disposed = false;
        SafeHandle handle = new SafeFileHandle(IntPtr.Zero, true);

        public ServiceNowApi()
        {
            _logger = new Logger();


            _baseUrl = ConfigurationManager.AppSettings["Snow:BaseUrl"];
            _getDsarGroups = ConfigurationManager.AppSettings["Snow:getDSARGroups"];
            _authorisation = ConfigurationManager.AppSettings["Snow:Authorization"];           
        }



        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;

            if (disposing)
            {
                handle.Dispose();
                // Free any other managed objects here.
                //
            }

            disposed = true;
        }

        public string UpdateDsarUploadTask(SnowUpdateDsarRequest snowUpdateDsarRequest)
        {
            var endpoint = ConfigurationManager.AppSettings["Snow:updateDSARUploadTask"];

            var responseValue = UpdateDsarTask(snowUpdateDsarRequest, endpoint);

            return responseValue;
        }

        public string UpdateDsarReviewTask(SnowUpdateDsarRequest snowUpdateDsarRequest)
        {
            var endpoint = ConfigurationManager.AppSettings["Snow:updateDSARReviewTask"];

            var responseValue = UpdateDsarTask(snowUpdateDsarRequest, endpoint);

            return responseValue;
        }

        private string UpdateDsarTask(SnowUpdateDsarRequest snowUpdateDsarRequest, string endpoint)
        {
            var responsevalue = string.Empty;
            // string endpoint = ConfigurationManager.AppSettings["Snow:updateDSARUploadTask"];
            var postData = JsonConvert.SerializeObject(snowUpdateDsarRequest, Formatting.Indented);

            var enableTaskUpdate = Convert.ToBoolean(ConfigurationManager.AppSettings["Snow:EnableTaskUpdate"]);

            if (enableTaskUpdate)
            {
                try
                {
                    // TODO return appropriate message based on the web response
                    using (WebResponseWrapper apiresponse = InvokeApi(endpoint, postData, Method.Put))
                    {
                        if (apiresponse != null)
                        {
                            var responseString = apiresponse.ResponseString;
                            responsevalue = responseString;
                        }

                        _logger.LogApplicationInfo("DsarSnowUpdate",
                            $"Snow Task Update for dsar referance : {snowUpdateDsarRequest.dsar_ref} and {snowUpdateDsarRequest.dsar_pdf} updated successfully");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogApplicationInfo("DsarSnowUpdate", $"Snow Task Update for dsar referance : {snowUpdateDsarRequest.dsar_ref} and {snowUpdateDsarRequest.dsar_pdf} failed. Error message : {ex.Message}");
                    throw;
                }
            }
            return responsevalue;
        }

        public SnowResponse CreateTaskInServiceNow(SnowOrderDsarRequest snowOrderRequest)
        {
            var responsevalue = new SnowResponse();
            var resultresponse = new Result();
            string endpoint = $"{ConfigurationManager.AppSettings["Snow:createtask"]}";
            snowOrderRequest.requestor = ConfigurationManager.AppSettings["Snow:requestor"];

            var postData = JsonConvert.SerializeObject(snowOrderRequest, Formatting.Indented);

            try
            {
                //TODO return appropriate message based on the web response
                using (WebResponseWrapper apiresponse = InvokeApi(endpoint, postData, Method.Post))
                {
                    if (apiresponse != null)
                    {
                        var responseString = apiresponse.ResponseString;
                        var snowresponse = new { result = string.Empty };
                        var output = JsonConvert.DeserializeAnonymousType(responseString, snowresponse);

                        resultresponse = JsonConvert.DeserializeAnonymousType(output.result, resultresponse);
                        if (resultresponse != null)
                        {
                            responsevalue.result = resultresponse;
                        }
                    }

                    _logger.LogApplicationInfo("DsarSnowCreate",
                        $"{responsevalue.result.request_number} : SNow Task for dsar referance : {snowOrderRequest.dsar_ref} created successfully");
                }

            }
            catch (Exception ex)
            {
                _logger.LogApplicationInfo("DsarSnowCreate", $"SNow Task for dsar referance : {snowOrderRequest.dsar_ref} failed. Error message : {ex.Message}");
                throw;
            }

            return responsevalue;
        }



        private WebResponseWrapper InvokeApi(string url, string postData, Method method)
        {
            try
            {
                string baseUrl = ConfigurationManager.AppSettings["Snow:BaseUrl"];

                var data = Encoding.ASCII.GetBytes(postData);
                WebRequest request = WebRequest.Create(baseUrl + url);
                request.Method = method.ToString();
                request.ContentType = "application/json";
                request.ContentLength = data.Length;

                request.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(ConfigurationManager.AppSettings["Snow:Authorization"]));
                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }

                return new WebResponseWrapper((HttpWebResponse)request.GetResponse(), null);
            }
            catch (WebException webExcp)
            {
                return new WebResponseWrapper(null, webExcp);
            }
            catch (Exception e)
            {
                return null;
                // TODO Code to catch other exceptions goes here.  
            }
        }

        public string[] GetDsarGroups(string userId)
        {
            string[] dsarGroups = new[] { "" };
            string postData = "{\"user_id\":\"" + userId + "\"}";

            var responseString = CallApiGetDsarGroups(postData, Method.Post);

            if (string.IsNullOrEmpty(responseString) == false)
            {
                var definition = new { result = string.Empty };
                dynamic output = JsonConvert.DeserializeAnonymousType(responseString, definition);

                if (string.IsNullOrEmpty(output.result) == false)
                {
                    dsarGroups = output.result.ToString().Split(',');
                }

                _logger.LogApplicationInfo("DSAR APPLICATION INFO",
                    $"{userId} : SNow GetDsarGroups : {output} retrieved successfully");

            }
            return dsarGroups;
        }

        private string CallApiGetDsarGroups(string postData, Method method)
        {
            var responseString = string.Empty;

            try
            {
                var data = Encoding.ASCII.GetBytes(postData);

                var request = WebRequest.Create(_baseUrl + _getDsarGroups);

                request.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(_authorisation));
                request.ContentType = "application/json";
                request.ContentLength = data.Length;
                request.Method = method.ToString();

                request.GetRequestStream().Write(data, 0, data.Length);

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    using (var receiveStream = response.GetResponseStream())
                    {
                        if (receiveStream != null)
                        {
                            using (var readStream = new StreamReader(receiveStream))
                            {
                                responseString = readStream.ReadToEnd();

                                readStream.Close();
                            }
                            receiveStream.Close();
                        }
                    }
                    response.Close();
                }
            }
            catch (Exception ex)
            {
                _logger.LogApplicationError($"Error at SNOW:getUserGroups Call Exception: {ex.Message}");
            }


            return responseString;
        }


        public bool ReadTaskStatusDsarReview(SnowUpdateDsarRequest snowUpdateDsarRequest)
        {
            var endpoint = $"{_baseUrl}{ConfigurationManager.AppSettings["Snow:readDSARReviewTask"]}/{snowUpdateDsarRequest.dsar_ref }/{snowUpdateDsarRequest.dsar_pdf}"; 
            var responseValue = GetStatusForDSARReviewRetrievedTask(snowUpdateDsarRequest, endpoint);
            return responseValue;
        }

        public bool ReadTaskStatusDsarUpload(SnowUpdateDsarRequest snowUpdateDsarRequest)
        {
            var endpoint = $"{_baseUrl}{ConfigurationManager.AppSettings["Snow:readDSARRetrievedTask"]}/{snowUpdateDsarRequest.dsar_ref }/{snowUpdateDsarRequest.dsar_pdf}";
            var responseValue = GetStatusForDSARReviewRetrievedTask(snowUpdateDsarRequest, endpoint);
            return responseValue;
        }



        public bool GetStatusForDSARReviewRetrievedTask(SnowUpdateDsarRequest snowUpdateDsarRequest, string endpoint)
        {

            var responseString = string.Empty;
            var enableTaskUpdate = Convert.ToBoolean(ConfigurationManager.AppSettings["Snow:EnableTaskUpdate"]);
            bool status = false;
            if (enableTaskUpdate)
            {
                try
                {
                    var request = WebRequest.Create(endpoint);

                    request.Headers["Authorization"] = "Basic "
                                                       + Convert.ToBase64String(Encoding.Default.GetBytes(_authorisation));
                    request.ContentType = "application/json";
                    request.Method = Method.Get.ToString();

                    using (var response = (HttpWebResponse)request.GetResponse())
                    {
                        using (var receiveStream = response.GetResponseStream())
                        {
                            if (receiveStream != null)
                            {
                                using (var readStream = new StreamReader(receiveStream))
                                {
                                    responseString = readStream.ReadToEnd();

                                    readStream.Close();
                                }
                                receiveStream.Close();
                            }
                        }
                        response.Close();
                    }

                    if (string.IsNullOrEmpty(responseString) == false)
                    {
                        var definition = new { result = string.Empty };
                        dynamic output = JsonConvert.DeserializeAnonymousType(responseString, definition);
                        bool.TryParse(output.result.ToString(), out status);
                    }
                    _logger.LogApplicationInfo("DsarSnowStatus",
                       $"Snow Task Status for dsar referance : {snowUpdateDsarRequest.dsar_ref} and {snowUpdateDsarRequest.dsar_pdf} retrieved successfully");
                }
                catch (Exception ex)
                {
                    _logger.LogApplicationInfo("DsarSnowStatus", $"Snow Status for dsar referance : {snowUpdateDsarRequest.dsar_ref} and {snowUpdateDsarRequest.dsar_pdf} failed. Error message : {ex.Message}");
                    throw;
                }
            }
           
            return status;
        }
    }
}
