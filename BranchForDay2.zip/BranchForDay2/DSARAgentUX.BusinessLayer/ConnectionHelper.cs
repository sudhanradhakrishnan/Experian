﻿namespace DSARAgentUX.BusinessLayer
{
    /*
    public static class ConnectionHelper
    {
        public static IConnectionFactory GetConnection()
        {
            return new DbConnectionFactory("DSARCon");
        }
    }

    public static class ConnectionSingleton
    {
        private static ILogger _logger;
        private static IConnectionFactory _connectionFactory;
        private static DbContext _context;


        private static IConnectionFactory GetconnectionFactory()
        {
            return _connectionFactory ?? (_connectionFactory = ConnectionHelper.GetConnection());
        }

        public static DbContext GetContext()
        {
            _logger = new Logger();
            try
            {
                return _context ?? (_context = new DbContext(GetconnectionFactory()));
            }
            catch (SqlException ex)
            {
                _logger.LogApplicationError($"DSAR AGENT UX SERVICE LAYER {ex.ErrorMessage}");
                return null;
            }
        }
    }*/
}