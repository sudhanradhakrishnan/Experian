﻿using ExperianLogger;
using System;
using System.Web.Mvc;
using System.Web.Routing;

namespace DSARAgentUX.UI.Attributes
{
    public class HandleAgentErrorAttribute : HandleErrorAttribute
    {
        private ILogger Logger { get; set; }
        public override void OnException(ExceptionContext filterContext)
        {
            var ex = filterContext.Exception;
            filterContext.ExceptionHandled = true;
            ILogger Logger = new Logger();

            Logger.LogApplicationError($"Error while fetching the Data. Exception : {filterContext.Exception}");
            var model = new HandleErrorInfo(filterContext.Exception, "Error", "Index");

            filterContext.HttpContext.Response.Redirect(UrlHelper.GenerateUrl("ErrorHandler", "Index", "Error",
                                                                                 ((Route)RouteTable.Routes["ErrorHandler"]).Defaults,
                                                                                  RouteTable.Routes, filterContext.HttpContext.Request.RequestContext, false));
        }
    }
}