﻿using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Models;
using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using ExperianLogger;

namespace DSARAgentUX.UI.Attributes
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class AuthorizeAgent : AuthorizeAttribute
    {
        public AuthorizeAgent()
        {
            Logger = new Logger();
        }

        public CurrentUser User;
        private string _pdfReference;
        private string _actionName;
        private string _controller;

        private ILogger Logger { get; set; }

        public IDSARAgentUXService AgentUxService { get; set; }


        protected override bool AuthorizeCore(HttpContextBase context)
        {
            if (base.AuthorizeCore(context) == false)
            {
                return false;
            }

            return true;
        }

        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            // Okta authentication layer shoud be providing User claims content
            User = AgentUxService.ValidateCurrentUser();

            _controller = filterContext.RequestContext.RouteData.GetRequiredString("controller");
            _actionName = filterContext.ActionDescriptor.ActionName;
            
            base.OnAuthorization(filterContext);
            
            if (IsUserEntitledToAction(filterContext.HttpContext) == false)
            {
                HandleUnauthorizedRequest(filterContext);
            }
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {

            Logger.LogApplicationInfo("AUTH001",
                         $"USER_AUTH {User.UserId} Is denied access to action : {_actionName} / pdf : {_pdfReference}");
            HttpContext.Current.Response.ClearContent();


            filterContext.Result = new RedirectToRouteResult(
                new RouteValueDictionary(
                    new
                    {
                        controller = "AccessDenied",
                        action = "AccessDenied"
                    })
            );
        }

        private bool IsEntitledToPdf(HttpContextBase httpContext)
        {
            // TODO : This method does not read well 

            _pdfReference = 
                httpContext.Request.RequestContext.RouteData.Values["PDFReference"] as string == ""
                ? (string)httpContext.Request.RequestContext.RouteData.Values["PDFReference"]
                : httpContext.Request.RequestContext.RouteData.Values["pdfReference"] as string;

            return string.IsNullOrEmpty(_pdfReference) || User.IsEntitledToPdfUpload(_pdfReference);
        }

        private bool IsUserEntitledToAction(HttpContextBase httpContext)
        {
            switch (_actionName)
            {
                case "ServiceNowView":
                case "UpdatePublishStatus":              
                    return User.IsEntitledToPublish;

                case "UpdateDsarCancelStatus":
                case "UndoCancel":
                    return User.IsEntitledToCancel;

                case "Duplicatecheck":
                case "UpdateRemoveDuplicateStatus":
                    return User.IsEntitledToRemoveDuplicateCheck;

                case "DepartmentUserView":
                case "GetReport":
                case "GetPostalReport":
                case "RemovePDF":
                case "RemovePostalReport":
                case "StateNoData":
                case "UploadFile":
                case "UploadPostalFile":
                case "ViewAll":
                case "CloseReviewTaskInSnow":
                case "CloseUploadTaskInSnow":
                case "GetAudioRecordingReport":
                    return IsEntitledToPdf(httpContext);

                default:
                    return false;
            }
        }

    }
}