﻿using System.Web.Mvc;
using System.Web.Routing;
using Autofac;
using ExperianLogger;

namespace DSARAgentUX.UI.Controllers
{
    public class BaseController : Controller
    {
        public ILogger Logger { get; }

        public BaseController()
        {
            Logger = new Logger();
        }

        public RedirectToRouteResult ShowErrorMessage(string ErrorTitle, string ErrorMessage, string ErrorCode)
        {

            ModelState.AddModelError("Error", ErrorMessage);

            return RedirectToAction("Index", new RouteValueDictionary(
    new { controller = "Error", action = "Index", Title = ErrorTitle, Message = ErrorMessage, Code = ErrorCode }));

        }
    }
}