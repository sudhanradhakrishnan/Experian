﻿using DSARAgentUX.UI.ViewModels;
using System;
using System.Net;
using System.Web.Mvc;

namespace DSARAgentUX.UI.Controllers
{
    public class ErrorController : BaseController
    {

        public ActionResult Index(string Title, string Message, string Code)
        {
            var model = new ErrorViewModel { Title = Title, Message = Message };
            return View(model);
        }
        public ActionResult PageNotFound()
        {
            Response.StatusCode = (int) HttpStatusCode.NotFound;
            return View();
        }

        public ActionResult AccessDenied(string Title, string Message)
        {
            // Cannot set unauthorized status return
            // as it retriggers the Saml2/Sign-In process, fails ... and loops
            //
            // Response.StatusCode = (int)HttpStatusCode.Unauthorized;
            //

            var model = new ErrorViewModel { Title = Title, Message = Message };
            return View($"AccessDenied",model);

        }
    }
}