﻿using System;
using System.Configuration;
using System.IO;
using System.Net.Mime;
using System.Reflection;
using System.Resources;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Common;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using DSARAgentUX.UI.Attributes;
using DSARAgentUX.UI.Utility;
using DSARAgentUX.UI.ViewModels;
using ExperianLogger;



namespace DSARAgentUX.UI.Controllers
{
    [HandleAgentError]
    [RoutePrefix("dsar")]
    public class DSARController : BaseController
    {
        public IDSARAgentUXService AgentUxService { get; }
        
        public string DepartmentId { get; set; } = string.Empty;
        public string DsarId { get; set; } = string.Empty;
        public string StrUrl { get; set; } = string.Empty;
        private readonly ResourceManager _rmErrorMessage;
        private CurrentUser _currentUser;


        public DSARController(IDSARAgentUXService agentUxService, ILogger logger)
        {
            AgentUxService = agentUxService;
            _rmErrorMessage = new ResourceManager("DSARAgentUX.UI.ErrorMessages.ErrorMessage", Assembly.GetExecutingAssembly());

        }

        private void SetCurrentUser()
        {
            if (_currentUser == null)
            {
                _currentUser = AgentUxService.ValidateCurrentUser();
            }
        }


        [Authorize]
        [AuthorizeAgent]
        [HttpGet]
        [Route("{DSARReference}/pdf/{PDFReference:range(1,99999999)}")]
        [Route("{DSARReference}/pdf/{PDFReference}/review")]
        public ActionResult DepartmentUserView(string dsarReference, string pdfReference,string skipCaptureEvent)
        {
            SetCurrentUser();

            StrUrl = Request.Url?.AbsoluteUri;
      
            DSARViewModel viewdsar;
            try
            {
                viewdsar = DsarAgentUtility.BindModelandViewModelWithPdf(Logger, AgentUxService, dsarReference, _currentUser, pdfReference);

                Logger.LogApplicationInfo(Constantfields.DSARCTRL, $"DepartmentUserScreen viewed by user {viewdsar.CurrentUserName} for reference: {dsarReference}");


                    if (skipCaptureEvent != Constantfields.DSARPDFACTION)
                {
                    AgentUxService.CaptureEvent(new Audit
                    {
                        DsarReferenceId = dsarReference,
                        PdfReference = pdfReference,
                        UserId = _currentUser.UserId,
                        Operation = AuditEventsType.VIEWDEPARTMENTUSERSCREEN
                    });

                }


                if (StrUrl != null)
                {
                    viewdsar.DisplayViewMode = StrUrl.Contains("review");
                }
            }
            catch (DSARException ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while accessing User View for dsar {dsarReference} with pdf ref : {pdfReference} Exception :  {_rmErrorMessage.GetString(ex.Message)}"
                    );

                ModelState.AddModelError("Error", _rmErrorMessage.GetString(ex.Message));
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString(ex.Message), ex.Message);

            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while accessing User View for dsar {dsarReference}  with pdf ref : {pdfReference} Exception : {ex.Message}"
                    );
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
            
            return View(viewdsar);
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("{DSARReference}/publish")]
        public ActionResult ServiceNowView(string dsarReference,string skipCaptureEvent)
        {
            SetCurrentUser();

            DsarId = dsarReference;
            try
            {
                var viewdsar = DsarAgentUtility.BindModelandViewModel(Logger, AgentUxService, _currentUser, dsarReference);

                Logger.LogApplicationInfo(Constantfields.DSARCTRL, $"Fetching DSAR information for Service Now User DSARReference :{dsarReference}");

                if (skipCaptureEvent != Constantfields.SERVICENOWACTION)
                    AgentUxService.CaptureEvent(new Audit
                    {
                        DsarReferenceId = dsarReference,
                        UserId = _currentUser.UserId,
                        Operation = AuditEventsType.SERVICENOWVIEWSCREEN
                    });
                
                return View(viewdsar);
            }
            catch (DSARException ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while fetching the ServiceNowAPI view for Dsar {dsarReference}. Exception : {_rmErrorMessage.GetString(ex.Message)}"
                    );

                ModelState.AddModelError("Error", _rmErrorMessage.GetString(ex.Message));
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString(ex.Message), ex.Message);

            }
            catch (Exception ex)
            {
                Logger.LogApplicationError($"Error while fetching the Service Now User for DSARReference {dsarReference}. Exception : {ex.Message}");
                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("{DSARReference}/pdf/all")]
        public ActionResult ViewAll(string dsarReference)
        {
            SetCurrentUser();

            DsarId = dsarReference;
            StrUrl = Request.Url?.AbsoluteUri;

            try
            {
                var viewdsar = DsarAgentUtility.BindModelandViewModel(Logger, AgentUxService, _currentUser, dsarReference);

                Logger.LogApplicationInfo(Constantfields.DSARCTRL, $"ViewAll screen entered by user {viewdsar.CurrentUserName} for reference: {dsarReference}");

                AgentUxService.CaptureEvent(new Audit
                {
                    DsarReferenceId = dsarReference,
                    UserId = _currentUser.UserId,
                    Operation = AuditEventsType.VIEWALLPDF
                });

                if (StrUrl != null)
                    viewdsar.DisplayViewMode = StrUrl.Contains("pdf/all");

                return View(Constantfields.SERVICENOWVIEW, viewdsar);
            }
            catch (DSARException ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while accessing the View-All page for Dsar {dsarReference}. Exception : {_rmErrorMessage.GetString(ex.Message)}"
                    );
                
                ModelState.AddModelError("Error", _rmErrorMessage.GetString(ex.Message));
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString(ex.Message), ex.Message);

            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while accessing the View-All page for Dsar {dsarReference}. Exception : {_rmErrorMessage.GetString(ex.Message)}");

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(
                    _rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("UpdateDsarCancelStatus/{DSARReference}")]
        public ActionResult UpdateDsarCancelStatus(string dsarReference)
        {
            SetCurrentUser();

            try
            {
                AgentUxService.UpdateDsarCancelStatus(dsarReference, DsarCancelType.ReadyToCancel, _currentUser.UserId,DsarStatusType.Cancelled,AuditEventsType.CANCELDSAR);

                return RedirectToAction(Constantfields.SERVICENOWVIEW,
                    new RouteValueDictionary(new {action = Constantfields.SERVICENOWVIEW, DSARReference = dsarReference, SkipCaptureEvent = Constantfields.SERVICENOWACTION }));
            }
            catch (DSARException ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while updating the cancel status for Dsar {dsarReference}. Exception : {_rmErrorMessage.GetString(ex.Message)}");

                ModelState.AddModelError("Error", _rmErrorMessage.GetString(ex.Message));
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString(ex.Message), ex.Message);

            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while cancelling Dsar {dsarReference}. Exception: {ex.Message}"
                    );

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("UpdatePublishStatus/{DSARReference}/{status}")]
        public ActionResult UpdatePublishStatus(string dsarReference, PublishStatusType status)
        {
            SetCurrentUser();

            try
            {
                AgentUxService.UpdatePublishStatus(dsarReference, status, _currentUser.UserId);
                
                return RedirectToAction(Constantfields.SERVICENOWVIEW,
                    new RouteValueDictionary(new {action = Constantfields.SERVICENOWVIEW, DSARReference = dsarReference, SkipCaptureEvent = Constantfields.SERVICENOWACTION }));
            }
            catch (DSARException ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while updating publish state of Dsar {dsarReference}. Exception: {ex.Message}");

                ModelState.AddModelError("Error", _rmErrorMessage.GetString(ex.Message));
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString(ex.Message), ex.Message);

            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while updating publish state of Dsar {dsarReference}. Exception: {ex.Message}"
                    );

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("UpdateRemoveDuplicateStatus/{DSARReference}/{status}")]
        public ActionResult UpdateRemoveDuplicateStatus(string dsarReference, DuplicateCheckStatusType status)
        {
            SetCurrentUser();

            try
            {
                AgentUxService.UpdateRemoveDuplicateStatus(dsarReference, status, _currentUser.UserId);
                return RedirectToAction(Constantfields.SERVICENOWVIEW,
                    new RouteValueDictionary(new {action = Constantfields.SERVICENOWVIEW, DSARReference = dsarReference, SkipCaptureEvent = Constantfields.SERVICENOWACTION }));
            }
            catch (DSARException ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while updating remove duplicate state of Dsar {dsarReference}. Exception: {ex.Message}");

                ModelState.AddModelError("Error", _rmErrorMessage.GetString(ex.Message));
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString(ex.Message), ex.Message);

            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while updating remove duplicate state of Dsar {dsarReference}. Exception: {ex.Message}");

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("GetReport/{DSARReference}/{PDFReference}")]
        public FileResult GetReport(string dsarReference, string pdfReference)
        {
            SetCurrentUser();

            try
            {
                Logger.LogApplicationInfo(Constantfields.DSARCTRL, 
                    $"User {_currentUser.UserId} retrieving content for Dsar {dsarReference} with item reference {pdfReference}");

                if (string.IsNullOrEmpty(dsarReference) || string.IsNullOrEmpty(pdfReference))
                    return null;

                var byteArray = AgentUxService.GetPdfFile(dsarReference, pdfReference).FileContent;
                var pdfStream = new MemoryStream();

                    pdfStream.Write(byteArray, 0, byteArray.Length);
                    pdfStream.Position = 0;

                    AgentUxService.CaptureEvent(new Audit
                    {
                        DsarReferenceId = dsarReference,
                        PdfReference = pdfReference,
                        UserId = _currentUser.UserId,
                        Operation = AuditEventsType.VIEWPDF
                    });

                    return File(pdfStream, Constantfields.MIMETYPE);
            }

            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while fetching content for Dsar {dsarReference} with item reference {pdfReference}. Exception: {ex.Message}");

                throw;
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("StateNoData/{DSARReference}/{PDFReference}")]
        public ActionResult StateNoData(string dsarReference,  string pdfReference)
        {
            SetCurrentUser();

            try
            {    
                AgentUxService.UploadReportNoData(dsarReference, pdfReference, _currentUser.UserId);
                

                return RedirectToAction(Constantfields.DEPARTMENTUSERVIEW,
                    new RouteValueDictionary(new
                    {
                        action = Constantfields.DEPARTMENTUSERVIEW,
                        DSARReference = dsarReference,
                        PDFReference = pdfReference,
                        SkipCaptureEvent = Constantfields.DSARPDFACTION
                    }));
            }
            catch (DSARException ex)
            {
                Logger.LogApplicationError(
                    $"User { _currentUser.UserId} has experienced an error while saving NoData Dsar {dsarReference} and item reference {pdfReference}. Exception : {ex.Message}"
                    );

                ModelState.AddModelError("Error", _rmErrorMessage.GetString(ex.Message));
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString(ex.Message),ex.Message);

            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User { _currentUser.UserId} has experienced an error while saving NoData Dsar {dsarReference} and item reference {pdfReference}. Exception : {ex.Message}"
                    );

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("RemovePDF/{DSARReference}/{PDFReference}")]
        public ActionResult RemovePDF(string dsarReference, string pdfReference)
        {
            SetCurrentUser();

            try
            {
                AgentUxService.RemovePdf(dsarReference, pdfReference, _currentUser.UserId);

                return RedirectToAction(Constantfields.DEPARTMENTUSERVIEW,
                                        new RouteValueDictionary(new
                                        {
                                            action = Constantfields.DEPARTMENTUSERVIEW,
                                            DSARReference = dsarReference,
                                            PDFReference = pdfReference,
                                            SkipCaptureEvent = Constantfields.DSARPDFACTION
                                        }));
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User { _currentUser.UserId} has experienced an error while removing content for Dsar {dsarReference} and item reference {pdfReference}. Exception: {ex.Message}"
                    );

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("UploadFile")]
        public ActionResult UploadFile(string dsarReference, string pdfReference,HttpPostedFileBase file)
        {
            SetCurrentUser();

            try
            {
                if (file != null)
                {
                    if (ConfigurationManager.AppSettings["Agent:PdfSizeLimitInMB"] != null)
                    {
                        var allowedFileSize = Convert.ToInt32(ConfigurationManager.AppSettings["Agent:PdfSizeLimitInMB"]);

                        var diff = file.ContentLength-(allowedFileSize*1024*1024);

                        if (diff > 0) 
                        {

                            Logger.LogApplicationInfo(Constantfields.DSARCTRL,
                                $"User { _currentUser.UserId} has exceeded file size when trying to upload content for Dsar {dsarReference} and item reference {pdfReference}"                               
                                );

                            return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT004"), $"{_rmErrorMessage.GetString("AGUX0003")} {allowedFileSize} MB", "AGUX0003");
                        }
                    }
                    var fileExt = Path.GetExtension(file.FileName)?.ToUpper();

                    DsarAgentUtility.hasValidReportType(fileExt, pdfReference);

                    PdfFileDetails filedetails = DsarAgentUtility.UpLoadPdfToModel(file);
                    AgentUxService.UploadReportData(filedetails, dsarReference, pdfReference, _currentUser.UserId);

                    ViewBag.Message = "File Uploaded Successfully";

                    return RedirectToAction(Constantfields.DEPARTMENTUSERVIEW,
                        new RouteValueDictionary(new { action = Constantfields.DEPARTMENTUSERVIEW, DSARReference = dsarReference, PDFReference = pdfReference, SkipCaptureEvent = Constantfields.DSARPDFACTION }));

                }

                Logger.LogApplicationInfo(Constantfields.DSARCTRL, $"File uploading for DSAR Reference : {dsarReference} failed due to empty file ");

                ModelState.AddModelError("Error", @"File Upload Failed");
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0002"), "AGUX0002");
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"Error occured while uploading the file for DSAR Reference : {dsarReference}. Exception: {ex.Message}"
                );

                ModelState.AddModelError("Error", @"File Upload Failed");
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("UndoCancel/{DSARReference}")]
        public ActionResult UndoCancel(string dsarReference)
        {
            SetCurrentUser();

            try
            {
                AgentUxService.UpdateDsarCancelStatus(dsarReference, DsarCancelType.None, _currentUser.UserId, DsarStatusType.Active,AuditEventsType.UNDOCANCEL);

                return RedirectToAction(Constantfields.SERVICENOWVIEW,
                    new RouteValueDictionary(new {action = Constantfields.SERVICENOWVIEW, DSARReference = dsarReference, SkipCaptureEvent = Constantfields.SERVICENOWACTION }));
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User { _currentUser.UserId} has experience an error reverting cancel for Dsar : {dsarReference}, Error : {ex.Message}");

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("UploadPostalFile")]
        public ActionResult UploadPostalFile(string dsarReference, string pdfReference, HttpPostedFileBase file)
        {
            SetCurrentUser();

            try
            {
                if (file != null)
                {
                    if (ConfigurationManager.AppSettings["Agent:PdfSizeLimitInMB"] != null)
                    {
                        var allowedFileSize = Convert.ToInt32(ConfigurationManager.AppSettings["Agent:PdfSizeLimitInMB"]);

                        var diff = file.ContentLength - (allowedFileSize * 1024 * 1024);

                        if (diff > 0)
                        {

                            Logger.LogApplicationInfo(Constantfields.DSARCTRL,
                                $"User { _currentUser.UserId} has exceeded file size when trying to upload content for Dsar {dsarReference} and item reference {pdfReference}"
                                );

                            return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT004"), $"{_rmErrorMessage.GetString("AGUX0003")} {allowedFileSize} MB", "AGUX0003");
                        }
                    }
                    var fileExt = Path.GetExtension(file.FileName)?.ToUpper();

                    DsarAgentUtility.hasValidReportType(fileExt, pdfReference);

                    PdfFileDetails filedetails = DsarAgentUtility.UpLoadPdfToModel(file);
                    AgentUxService.UploadPostalReportData(filedetails, dsarReference, pdfReference, _currentUser.UserId);

                    ViewBag.Message = "File Uploaded Successfully";

                    return RedirectToAction(Constantfields.DEPARTMENTUSERVIEW,
                        new RouteValueDictionary(new { action = Constantfields.DEPARTMENTUSERVIEW, DSARReference = dsarReference, PDFReference = pdfReference, SkipCaptureEvent = Constantfields.DSARPDFACTION }));

                }

                Logger.LogApplicationInfo(Constantfields.DSARCTRL, $"Postal file uploading for DSAR Reference : {dsarReference} failed due to empty file ");

                ModelState.AddModelError("Error", @"Postal file Upload failed");
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0002"), "AGUX0002");
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"Error occured while uploading the postal file for DSAR Reference : {dsarReference}. Exception: {ex.Message}"
                );

                ModelState.AddModelError("Error", @"Postal file upload failed");
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("GetPostalReport/{DSARReference}/{PDFReference}")]
        public FileStreamResult GetPostalReport(string dsarReference, string pdfReference)
        {
            SetCurrentUser();

            try
            {
                Logger.LogApplicationInfo(Constantfields.DSARCTRL,
                    $"User {_currentUser.UserId} retrieving content for Dsar {dsarReference} with item reference {pdfReference}");

                if (string.IsNullOrEmpty(dsarReference) || string.IsNullOrEmpty(pdfReference))
                    return null;

                var byteArray = AgentUxService.GetPostalReportFile(dsarReference, pdfReference).FileContent;
                var pdfStream = new MemoryStream();

                pdfStream.Write(byteArray, 0, byteArray.Length);
                pdfStream.Position = 0;

                AgentUxService.CaptureEvent(new Audit
                {
                    DsarReferenceId = dsarReference,
                    PdfReference = pdfReference,
                    UserId = _currentUser.UserId,
                    Operation = AuditEventsType.VIEWPDF
                });

                return new FileStreamResult(pdfStream, "application/pdf");
            }

            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while fetching content for Dsar {dsarReference} with item reference {pdfReference}. Exception: {ex.Message}");

                throw;
            }
        }

        [Authorize]
        [AuthorizeAgent]
        [Route("RemovePostalReport/{DSARReference}/{PDFReference}")]
        public ActionResult RemovePostalReport(string dsarReference, string pdfReference)
        {
            SetCurrentUser();

            try
            {
                AgentUxService.RemovePostalReport(dsarReference, pdfReference, _currentUser.UserId);

                return RedirectToAction(Constantfields.DEPARTMENTUSERVIEW,
                    new RouteValueDictionary(new
                    {
                        action = Constantfields.DEPARTMENTUSERVIEW,
                        DSARReference = dsarReference,
                        PDFReference = pdfReference,
                        SkipCaptureEvent = Constantfields.DSARPDFACTION
                    }));
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User { _currentUser.UserId} has experienced an error while removing content for Dsar {dsarReference} and item reference {pdfReference}. Exception: {ex.Message}"
                );

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }



        [Authorize]
        [AuthorizeAgent]
        [Route("CloseUploadTaskInSnow/{DSARReference}/{PDFReference}")]
        public ActionResult CloseUploadTaskInSnow(string dsarReference, string pdfReference)
        {
            SetCurrentUser();

            try
            {
                 AgentUxService.CloseUploadTaskInSnow(dsarReference, pdfReference, _currentUser.UserId);

               
                return RedirectToAction(Constantfields.DEPARTMENTUSERVIEW,
                                        new RouteValueDictionary(new
                                        {
                                            action = Constantfields.SERVICENOWVIEW,
                                            DSARReference = dsarReference,
                                            PDFReference = pdfReference,
                                            SkipCaptureEvent = Constantfields.DEPARTMENTUSERVIEW
                                        }));
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User { _currentUser.UserId} has experienced an error while Close Upload Task in Snow for Dsar {dsarReference} and item reference {pdfReference}. Exception: {ex.Message}"
                    );

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }


        [Authorize]
        [AuthorizeAgent]
        [Route("CloseReviewTaskInSnow/{DSARReference}/{PDFReference}")]
        public ActionResult CloseReviewTaskInSnow(string dsarReference, string pdfReference)
        {
            SetCurrentUser();

            try
            {
                AgentUxService.CloseReviewTaskInSnow(dsarReference, pdfReference, _currentUser.UserId);



                return RedirectToAction(Constantfields.DEPARTMENTUSERVIEW,
                                        new RouteValueDictionary(new
                                        {
                                            action = Constantfields.SERVICENOWVIEW,
                                            DSARReference = dsarReference,
                                            PDFReference = pdfReference,
                                            SkipCaptureEvent = Constantfields.DEPARTMENTUSERVIEW
                                        }));
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User { _currentUser.UserId} has experienced an error while Close Review Task in Snow for Dsar {dsarReference} and item reference {pdfReference}. Exception: {ex.Message}"
                    );

                ModelState.AddModelError("Error", ex.Message);
                return ShowErrorMessage(_rmErrorMessage.GetString("AGUXT001"), _rmErrorMessage.GetString("AGUX0001"), "AGUX0001");
            }
        }



        [Authorize]
        [AuthorizeAgent]
        [Route("GetAudioRecordingReport/{DSARReference}/{PDFReference}")]
        public FileResult GetAudioRecordingReport(string dsarReference, string pdfReference)
        {
            SetCurrentUser();

            try
            {
                Logger.LogApplicationInfo(Constantfields.DSARCTRL,
                    $"User {_currentUser.UserId} downloading content for Dsar {dsarReference} with item reference {pdfReference}");

                if (string.IsNullOrEmpty(dsarReference) || string.IsNullOrEmpty(pdfReference))
                    return null;

                var byteArray = AgentUxService.GetPdfFile(dsarReference, pdfReference).FileContent;
                var pdfStream = new MemoryStream();

                AgentUxService.CaptureEvent(new Audit
                {
                    DsarReferenceId = dsarReference,
                    PdfReference = pdfReference,
                    UserId = _currentUser.UserId,
                    Operation = AuditEventsType.DOWNLOAD
                });

                var fileDownloadName = getFileName(dsarReference, pdfReference);

                return File(byteArray, MediaTypeNames.Application.Zip, fileDownloadName);

            }

            catch (Exception ex)
            {
                Logger.LogApplicationError(
                    $"User {_currentUser.UserId} has experienced an error while downloading content for Dsar {dsarReference} with item reference {pdfReference}. Exception: {ex.Message}");

                throw;
            }
        }


        private string getFileName(string dsarReference, string pdfReference)
        {
            return dsarReference + "_" + pdfReference + ".zip";
        }


    }
}