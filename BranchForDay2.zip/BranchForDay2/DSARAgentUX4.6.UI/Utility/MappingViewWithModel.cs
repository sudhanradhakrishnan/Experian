﻿using DSARAgentUX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using ExperianLogger;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Common;
using DSARAgentUX.UI.ViewModels;

namespace DSARAgentUX.UI.Utility
{
    public class MappingViewWithModel
    {
        public ILogger Logger { get; }

        public DSARViewModel view { get; set; }

        public IDSARAgentUXService AgentUxService { get;}
        public MappingViewWithModel(ILogger logger, IDSARAgentUXService agentUxService)
        {
            Logger = logger;
            AgentUxService = agentUxService;
        }

        private bool hasValiedPDFId = true;
        public DSARViewModel BindDataWithViewAndPDF(ServiceUserModel serviceUser, List<ServiceUserModel> objDepartmentModel, List<ServiceUserModel> objPostalDepartmentModel, List<pdfType> pdfMaps, CurrentUser _currentUser, string pdfReference)
        {
            view = new DSARViewModel();
            BindingObjecttoView(serviceUser, objDepartmentModel, objPostalDepartmentModel, pdfMaps, _currentUser, pdfReference);
            return view;
        }

        public DSARViewModel BindDataWithView(ServiceUserModel serviceUser, List<ServiceUserModel> objDepartmentModel, List<ServiceUserModel> objPostalDepartmentModel, List<pdfType> pdfMaps, CurrentUser _currentUser)
        {
            view = new DSARViewModel();
            BindingObjecttoView(serviceUser, objDepartmentModel, objPostalDepartmentModel, pdfMaps, _currentUser, null);
            return view;
        }

        private void BindingObjecttoView(ServiceUserModel serviceUser, List<ServiceUserModel> objDepartmentModel, List<ServiceUserModel> objPostalDepartmentModel, List<pdfType> pdfMaps, CurrentUser _currentUser, string pdfReference)
        {
            view.UserAuthorization = _currentUser;           

            ProcessDsars(serviceUser.DataSubjectAccessRequest);
            ProcessServiceUser(serviceUser, _currentUser.UserId);

            if (pdfMaps != null && pdfMaps.Count > 0)
            {
                view.Departments = RemoveDeselectedDataSources(pdfMaps).GroupBy(y => y.departmentName)
                                      .Select(g => g.First())
                                      .ToList();
                if (string.IsNullOrEmpty(pdfReference) == false)
                {

                    if (pdfMaps.FirstOrDefault(x => x.id.Equals(pdfReference.Trim())) == null)
                    {
                        throw new DSARException("AGUX0006");
                    }
                }
            }


            if (objDepartmentModel == null)
            {
                Logger.LogApplicationDebug("AUGUXBUG015", $"DepartmentModel is NULL for dsarReference:  {serviceUser.DsarReference}");
                return;
            }
            if (objPostalDepartmentModel == null)
            {
                Logger.LogApplicationDebug("AUGUXBUG015", $"DepartmentModel is NULL for dsarReference:  {serviceUser.DsarReference}");
                return;
            }


            if (string.IsNullOrEmpty(pdfReference) == true)
            {
                BuildVmForUploadedReports(objDepartmentModel, objPostalDepartmentModel, pdfMaps, serviceUser.DsarReference);
            }
            else if (string.IsNullOrEmpty(pdfReference) == false)
            {
                BuildVmForUploadedReport(objDepartmentModel, objPostalDepartmentModel,pdfMaps, serviceUser.DsarReference, pdfReference);
            }

            if (!string.IsNullOrEmpty(pdfReference))
            {
                if (IsUploadTaskClosedInSnowButtonValid(pdfReference)) view.IsUploadTaskClosedInSnow = true;
                if (IsReviewTaskClosedInSnowButtonValid(pdfReference)) view.IsReviewTaskClosedInSnow = true;
            }
            ProcessUIElements();

        }

        private void ProcessUIElements()
        {
            view.EnableReplacePDFButton = false;
            view.EnableStateNodataButton = false;
            view.EnableUploadPDFButton = false;

            view.EnablePostalReplacePdfButton = false;
            view.EnablePostalUploadPdfButton = false;
            view.EnablePostalRemovePdfButton = false;

            if (view.UserAuthorization.UserAuthProfile != null)
            {
                view.IsEntitledToCancel = view.UserAuthorization.IsEntitledToCancel;
                view.IsEntitledToRemoveDuplicateCheck = view.UserAuthorization.IsEntitledToRemoveDuplicateCheck;
                view.IsEntitledToPublish = view.UserAuthorization.IsEntitledToPublish;
                view.IsAuthorized = view.UserAuthorization.IsAuthorized;
            }
            else
            {
                view.IsEntitledToCancel = view.IsEntitledToRemoveDuplicateCheck = view.IsEntitledToPublish = view.IsAuthorized = true;
            }

            if (!view.PDFUploads.Any())
                return;

            if (IsNoDataButtonValid()) view.EnableStateNodataButton = true;
            if (IsReplacePdfButtonValid()) view.EnableReplacePDFButton = true;
            if (IsUploadPdfButtonValid()) view.EnableUploadPDFButton = true;
            if (IsRemovePdfButtonValid()) view.EnableRemovePDFButton = true;

          
            if (IsPostalReplacePdfButtonValid()) view.EnablePostalReplacePdfButton = true;
            if (IsPostalUploadPdfButtonValid()) view.EnablePostalUploadPdfButton = true;
            if (IsPostalRemovePdfButtonValid()) view.EnablePostalRemovePdfButton = true;


            if (!(view.DSARCancel == DsarCancelType.Cancelled || view.PublishStatus == PublishStatusType.Published))
                view.AllowPDFtoUpload = true;




        }

        private bool IsRemovePdfButtonValid()
        {
            return (view.PDFUploads[0].Status == PDFStatusType.Uploaded || (view.PDFUploads[0].Status == PDFStatusType.State_No_Data))
                   && view.PublishStatus != PublishStatusType.Published && view.DSARStatus != DsarStatusType.Cancelled &&
                   !view.DisplayViewMode; 
        }

        private bool IsUploadPdfButtonValid()
        {
            return !view.DisplayViewMode && view.PDFUploads[0].Status == PDFStatusType.None &&
                   view.PublishStatus != PublishStatusType.Published && view.DSARStatus != DsarStatusType.Cancelled;
        }

        private bool IsReplacePdfButtonValid()
        {
            return (view.PDFUploads[0].Status == PDFStatusType.Uploaded || view.PDFUploads[0].Status == PDFStatusType.State_No_Data)
                   && view.PublishStatus != PublishStatusType.Published && view.DSARStatus != DsarStatusType.Cancelled &&
                   !view.DisplayViewMode;
        }

        private bool IsNoDataButtonValid()
        {
            return view.PDFUploads[0].Status == PDFStatusType.None &&
                   view.PublishStatus != PublishStatusType.Published && view.DSARStatus != DsarStatusType.Cancelled && !view.DisplayViewMode;
        }

        private bool IsPostalRemovePdfButtonValid()
        {
            return (view.PostalPDFUploads[0].Status == PDFStatusType.Uploaded )
                   && view.PublishStatus != PublishStatusType.Published && view.DSARStatus != DsarStatusType.Cancelled &&
                   !view.DisplayViewMode;
        }



        private bool IsUploadTaskClosedInSnowButtonValid(string pdfReference)
        {

            return AgentUxService.ReadTaskStatusDsarUpload(view.DSARReference, pdfReference);
        }


        private bool IsReviewTaskClosedInSnowButtonValid(string pdfReference)
        {
            return AgentUxService.ReadTaskStatusDsarReview(view.DSARReference, pdfReference);
        }

        private bool IsPostalUploadPdfButtonValid()
        {
            return !view.DisplayViewMode && view.PostalPDFUploads[0].Status == PDFStatusType.None &&
                   view.PublishStatus != PublishStatusType.Published && view.DSARStatus != DsarStatusType.Cancelled;
        }

        private bool IsPostalReplacePdfButtonValid()
        {
            return (view.PostalPDFUploads[0].Status == PDFStatusType.Uploaded)
                   && view.PublishStatus != PublishStatusType.Published && view.DSARStatus != DsarStatusType.Cancelled &&
                   !view.DisplayViewMode;
        }


        private void BuildVmForUploadedReports(List<ServiceUserModel> objDepartmentModel, List<ServiceUserModel> objPostalDepartmentModel, List<pdfType> pdfMaps, string dsarReference)
        {

            var reportUploads = BuildListForReports(objDepartmentModel, pdfMaps, dsarReference);
            var postalReportUploads = BuildListForReports(objPostalDepartmentModel, pdfMaps, dsarReference);

            view.PDFUploads = reportUploads.OrderBy(o => o.DepartmentName).ToList();
            view.PostalPDFUploads = postalReportUploads.OrderBy(o => o.DepartmentName).ToList();
        }

        private void BuildVmForUploadedReport(List<ServiceUserModel> objDepartmentModel, List<ServiceUserModel> objPostalDepartmentModel, List<pdfType> pdfMaps, string dsarReference, string pdfReference)
        {

            var reportUploads = BuildListForReport(objDepartmentModel, pdfMaps, dsarReference, pdfReference);
            var postalReportUploads = BuildListForReport(objPostalDepartmentModel, pdfMaps, dsarReference, pdfReference);
            
            view.PDFUploads = reportUploads;
            view.PostalPDFUploads = postalReportUploads;
        }

        private List<PdfFileDetails> BuildListForReport(List<ServiceUserModel> objDepartmentModel, List<pdfType> pdfMaps, string dsarReference, string pdfReference)
        {
            if (pdfReference == null)
            {
                Logger.LogApplicationDebug("AUGUXBUG020", $"Report Reference not valid for view details map");
                throw new Exception($"Report Reference not valid for Details map");
            }

            var reportMapItem = pdfMaps.FirstOrDefault(x => x.id.Equals(pdfReference));
            if (reportMapItem == null)
            {
                Logger.LogApplicationDebug("AUGUXBUG021", $"Report Reference not valid for view details map");
                throw new Exception($"Report Reference not valid for Details map");
            }

            var reportUploads = new List<PdfFileDetails>();
            
            var reportVmDetails = new PdfFileDetails()
            {
                Id = 0,
                DsarReference = dsarReference,
                ServiceNowTaskName = reportMapItem.serviceNowTaskName,
                DepartmentName = reportMapItem.departmentName,
                DepartmentDescription = reportMapItem.departmentName,
                PdfReference = pdfReference,
                FileName = reportMapItem.readableName,
                Status = PDFStatusType.None
        };
            

            if (objDepartmentModel.Count > 0)
            {
                var retrievedReport = objDepartmentModel.FirstOrDefault(x => x.PdfReference.Equals(pdfReference));
                if (retrievedReport != null)
                {
                    reportVmDetails.Id = retrievedReport.PdfId;

                    reportVmDetails.ServiceNowTaskName = reportMapItem.serviceNowTaskName;
                    reportVmDetails.DepartmentName = reportMapItem.departmentName;
                    reportVmDetails.DepartmentDescription = reportMapItem.departmentName;

                    reportVmDetails.Status = retrievedReport.PdfStatus;
                    reportVmDetails.ModifiedBy = retrievedReport.ModifiedBy;
                    reportVmDetails.ModifiedDate_Formatted = retrievedReport.ModifiedDate.ToString("dd MMMM yyyy,hh:mm tt");
                }
            }

            reportUploads.Add(reportVmDetails);

            return reportUploads;
        }


        private List<PdfFileDetails> BuildListForReports(List<ServiceUserModel> objDepartmentModel, List<pdfType> pdfMaps, string dsarReference)
        {
            var reportUploads = new List<PdfFileDetails>();

            foreach (var map in pdfMaps)
            {
                var objFileDetail = new PdfFileDetails
                {
                    DsarReference = dsarReference,
                    ServiceNowTaskName = map.serviceNowTaskName,
                    DepartmentName = map.departmentName,
                    DepartmentDescription = map.departmentName,
                    PdfReference = map.id,
                    FileName = map.readableName,
                    Status = PDFStatusType.None,
                    ModifiedBy = null,
                    ModifiedDate_Formatted = null
                };

                var reportIdItem = objDepartmentModel.FirstOrDefault(x => x.PdfReference.Equals(map.id));

                if (reportIdItem != null) 
                {
                    objFileDetail.FileName = reportIdItem.FileName;
                    objFileDetail.Status = reportIdItem.PdfStatus;
                    objFileDetail.ModifiedBy = reportIdItem.ModifiedBy;
                    objFileDetail.ModifiedDate_Formatted = reportIdItem.ModifiedDate.ToString("dd MMMM yyyy,hh:mm tt");
                }

                reportUploads.Add(objFileDetail);

            }
            return reportUploads;
        }

        private void ProcessDsars(dsars dsarRequests)
        {
            if (dsarRequests.Equals(null))
            {
                Logger.LogApplicationDebug("DSARDEBUG0011", "DSAR Request is NULL");
                return;
            }


            foreach (var dsar in dsarRequests.Items.OfType<DSARType>())
            {
                ProcessDsar(dsar);
            }
        }

        private void ProcessServiceUser(ServiceUserModel serviceUser, string userId)
        {
            if (serviceUser == null)
                return;

            view.CurrentUserName = userId;
            view.ServiceModel = serviceUser;
            view.DSARStatus = view.ServiceModel.DsarStatus;
            view.PublishStatus = view.ServiceModel.PublishStatus;
            view.DuplicateStatus = view.ServiceModel.DuplicateStatus;
            view.ModifiedDate = view.ServiceModel.ModifiedDate;
            view.DSARCancel = view.ServiceModel.DsarCancelStatus;

            if (view.PublishStatus == PublishStatusType.Published && view.DSARStatus == DsarStatusType.Published)
            {
                view.PublishInfo = Constantfields.PublishInformation + view.ModifiedDate.ToString("dd MMMM yyyy,hh:mm tt");
            }
            if (view.DSARStatus == DsarStatusType.Cancelled)
            {
                view.DSARCanceledBy = view.ServiceModel.Username;
                view.ActivityTime = view.ServiceModel.ActivityTime.ToString("dd MMMM yyyy,hh:mm tt");
            }
        }

        private void ProcessDsar(DSARType dsar)
        {

            view.dsarRequest = dsar;
            view.DSARReference = view.dsarRequest.Reference;

            if(dsar.DataSources.AudioRecordingsInformation != null)
                view.AudioRecordingsInformation = true;
            


            if (view.dsarRequest.Person.Item != null)
            {
                if (view.dsarRequest.Person.Item.GetType().Name == Constantfields.StructuredNameType)
                {
                    var name = (StructuredNameType)view.dsarRequest.Person.Item;
                    view.Fullname = name.Title + " " + name.Forename + " " + name.Surname;
                }
                else
                {
                    var name = (string)view.dsarRequest.Person.Item;
                    view.Fullname = name;
                }
            }
            ProcessPersonalAddressItems();

            view.RequestDate = view.dsarRequest.RequestDate.ToString("dd MMMM yyyy,hh:mm tt");
            view.RequestType = view.dsarRequest.OriginatingSource.ToString();
            view.ConsumerDOB = view.dsarRequest.Person.DateOfBirth.ToString("dd MMMM yyyy");
            view.EmailAddress = view.dsarRequest.Person.EmailAddress;
            view.timeperiodrequest = ModelFormatterHelpers.ReadXmlEnumAttributeValue(view.dsarRequest.TimePeriodRequest);
            view.DocumentDeliveryMethodType = view.dsarRequest.DocumentDeliveryMethod.ToString();

            Logger.LogApplicationDebug("DSARDEBUG0014", $"Processing completed for Personal Address information dsarReference:  {dsar.Reference}");
        }

        private void ProcessPersonalAddressItems()
        {
            if (view.dsarRequest.Address.Items == null)
                return;

            view.PreviousAddresses = new List<string>();
            if (view.dsarRequest.Address.Items[0].GetType().Name == Constantfields.FormattedAddress)
            {
                var address = (FormattedAddressType)view.dsarRequest.Address.Items[0];
                view.CurrentAddress = address.CurrentAddress;
                view.PreviousAddresses.Add(address.PreviousAddress1);
                view.PreviousAddresses.Add(address.PreviousAddress2);
                view.PreviousAddresses.Add(address.PreviousAddress3);
                view.PreviousAddresses.Add(address.PreviousAddress4);
                view.PreviousAddresses.Add(address.PreviousAddress5);
                view.PreviousAddresses.Add(address.PreviousAddress6);
                view.PreviousAddresses.Add(address.PreviousAddress7);
                view.PreviousAddresses.Add(address.PreviousAddress8);
            }
            else
            {
                throw new Exception($"Structured Address Not Expected In DSAR Reference : {view.dsarRequest.Reference}");
            }
        }


        private List<pdfType> RemoveDeselectedDataSources(List<pdfType> pdfMaps)
        {
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.AffordabilityInformation, "AffordabilityInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.MarketingServices, "MarketingServices");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.HistoricCreditReport, "HistoricCreditReport");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.WebMonitoringInformation, "WebMonitoringInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.AutomotiveInformation, "AutomotiveInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.CreditAccountsTracingInformation, "CreditAccountsTracingInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.UnclaimedAssetRegister, "UnclaimedAssetRegister");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.AdditionBusinessInformation, "AdditionBusinessInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.HRInformation, "HRInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.ExperianID, "ExperianID");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.BackgroundCheckingInformation, "BackgroundCheckingInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.ExperianClientRelatedInformation, "ExperianClientRelatedInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.ComparisonServiceInformation, "ComparisonServiceInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.DetailOfContactWithExperianInformation, "DetailOfContactWithExperianInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.CreditExpertAndFreeAccountInformation, "CreditExpertAndFreeAccountInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.FraudDetectionInformation, "FraudDetectionInformation");
            RemovePFDFromDataSources(pdfMaps, view.dsarRequest.DataSources.AudioRecordingsInformation, "AudioRecordings");
            return pdfMaps;
        }

        private void RemovePFDFromDataSources<T>(List<pdfType> pdfMaps, T datasources, string dataprovider)
        {
            if (datasources == null)
            {
                pdfMaps.RemoveAll(x => HumanFriendlyNames.GetPDFbyID(dataprovider).Contains(convertToInt(x.id)));
            }
        }

        static int convertToInt(string str)
        {
            int result = 0;
            int.TryParse(str, out result);
            return result;
        }

    }
}