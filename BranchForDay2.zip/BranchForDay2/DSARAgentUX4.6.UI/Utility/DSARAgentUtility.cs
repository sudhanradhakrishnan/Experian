﻿using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using DSARAgentUX.UI.ViewModels;
using ExperianLogger;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace DSARAgentUX.UI.Utility
{
    public static class DsarAgentUtility
    {
        public static DSARViewModel BindModelandViewModel(ILogger logger,IDSARAgentUXService agentUxService, CurrentUser currentUser, string dsarReference)
        {
            MappingViewWithModel mapviewobject = new MappingViewWithModel(logger, agentUxService);
            List<pdfType> pdfmaps = agentUxService.GetAllPdfMaps();

            ServiceUserModel serviceuser =  PullDsarInformation(agentUxService, dsarReference);

            return mapviewobject.BindDataWithView(serviceuser, agentUxService.GetAllUploadedPdfDetails(dsarReference), agentUxService.GetAllUploadedPostalPdfDetails(dsarReference), pdfmaps, currentUser);
             
        }

        public static DSARViewModel BindModelandViewModelWithPdf(ILogger logger, IDSARAgentUXService agentUxService, string dsarReference, CurrentUser currentUser, string pdfReference)
        {
            
            MappingViewWithModel mapviewobject = new MappingViewWithModel(logger, agentUxService);
            List<pdfType> pdfmaps = agentUxService.GetAllPdfMaps();
            if (pdfmaps.Find(x => x.id.Equals(pdfReference)) == null)
            {
                throw new DSARException("AGUX0006");
            }

            ServiceUserModel serviceuser = PullDsarInformation(agentUxService, dsarReference);

            return mapviewobject.BindDataWithViewAndPDF(serviceuser, agentUxService.GetUploadedPdfDetails(dsarReference, pdfReference), agentUxService.GetUploadedPostalPdfDetails(dsarReference, pdfReference),
                pdfmaps, currentUser, pdfReference);

        }

        private static ServiceUserModel PullDsarInformation(IDSARAgentUXService agentUxService, string dsarReference)
        {
            ServiceUserModel serviceuser = agentUxService.GetDsarInformation(dsarReference);

            if (serviceuser.DsarReference == null)
            {
                throw new DSARException("AGUX0005");
            }

            var activitylog = agentUxService.GetCancelledUsernameByReference(dsarReference);

            if (activitylog != null)
            {
                serviceuser.ActivityTime = activitylog.ActivityTime;
                serviceuser.Username = activitylog.Username;
            }

            return serviceuser;
        }

        public static PdfFileDetails UpLoadPdfToModel(HttpPostedFileBase file)
        {
            string fileName = Path.GetFileName(file.FileName);

            byte[] fileDetail;

            using (var str = file.InputStream)
            {
                using (var br = new BinaryReader(str))
                {
                    fileDetail = br.ReadBytes((int)str.Length);
                }
            }

            PdfFileDetails fd = new PdfFileDetails
            {
                FileName = fileName,
                FileContent = fileDetail,
                Status = PDFStatusType.Uploaded
            };

            return fd;
        }

        public static void hasValidReportType(string reportnameextension,string pdfReference)
        {
            if (pdfReference == Constantfields.AUDIORECORDINGPDFREFERENCE)
            {
                if (string.IsNullOrWhiteSpace(FilterReportExtension(Constantfields.AUDIORECORDINGFILETYPE, reportnameextension)))
                    throw new DSARException("AGUX0007");
            }
            else
            {
                if (string.IsNullOrWhiteSpace(FilterReportExtension(Constantfields.PDFFILETYPE, reportnameextension)))
                    throw new DSARException("AGUX0004");
            }
        }

        private static string FilterReportExtension(string listofExtension, string reportExtension)
        {
            return listofExtension.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).FirstOrDefault(pm => pm.ToUpper().Equals(reportExtension));
        }

    }
}