﻿using Autofac;
using Autofac.Integration.Mvc;
using DSARAgentUX.BusinessLayer;
using DSARAgentUX.BusinessLayer.Interfaces;
using ExperianLogger;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace DSARAgentUX.UI
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            RegisterDI();
     
        }

        private void RegisterDI()
        {
            var builder = new ContainerBuilder();
            builder.RegisterControllers(Assembly.GetExecutingAssembly());
            builder.RegisterSource(new ViewRegistrationSource());
            builder.RegisterFilterProvider();

            // manual registration of types;
            builder.RegisterType<Logger>().As<ILogger>();
            builder.RegisterType<DSARAgentUXService>().As<IDSARAgentUXService>();
 
            var container = builder.Build(); 
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));

        }


    }
}
