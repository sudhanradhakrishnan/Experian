﻿using DSARAgentUX.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using ExperianLogger;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Common;

namespace DSARAgentUX.UI.ViewModels
{
    public class DSARViewModel
    {
        public List<pdfType> Departments { get; set; }
        public bool IsReadyToPublish { get; set; }
        public bool IsDuplicateSentToSTS { get; set; }
        public DsarStatusType DSARStatus { get; set; }
        public DsarCancelType DSARCancel { get; set; }
        public PublishStatusType PublishStatus { get; set; }
        public ServiceUserModel ServiceModel { get; set; }
        public DuplicateCheckStatusType DuplicateStatus { get; set; }
        public string DocumentDeliveryMethodType { get; set; }
        public string Fullname { get; set; }
        public string DSARReference { get; set; }
        public string RequestDate { get; set; }
        public string RequestType { get; set; }
        public string ConsumerName { get; set; }
        public string ConsumerDOB { get; set; }
        public string DSARCanceledBy { get; set; }
        public string ActivityTime { get; set; }
        public string EmailAddress { get; set; }
        public string CurrentAddress { get; set; }
        public string TimeatcurrentAddress { get; set; }
        public List<string> PreviousAddresses { get; set; }
        public DsarInformation CompleteDSAR { get; set; }
        public List<PdfFileDetails> PDFUploads { get; set; }
        public List<PdfFileDetails> PostalPDFUploads { get; set; }

        public string Modifiedby { get; set; }
        public string timeperiodrequest { get; set; }
        public Dictionary<string, List<KeyValuePair<string, string>>> XMLValues { get; set; }
        public bool DisplayViewMode { get; set; }
        public string PDFReference { get; set; }
        public PDFStatusType PDFStatus { get; set; }
        public int PDFId { get; set; }
        public string DepartmentName { get; set; }
        public List<string> Timeatpreviousaddress { get; set; }
        public List<string> Department { get; set; }
        public DSARType dsarRequest { get; set; }
        public DsarStatusType Status { get; set; }
        public int DuplicateStatus1 { get; set; } = 0;
        public int PublishStatus1 { get; set; } = 0;
        public DateTime ModifiedDate { get; set; }
        public string PublishInfo { get; set; }
        public bool EnableReplacePDFButton { get; set; }
        public bool EnableStateNodataButton { get; set; }
        public bool EnableUploadPDFButton { get; set; }
        public bool EnableRemovePDFButton { get; set; }

        public bool EnablePostalReplacePdfButton { get; set; }
        public bool EnablePostalUploadPdfButton { get; set; }
        public bool EnablePostalRemovePdfButton { get; set; }

        public bool AudioRecordingsInformation { get; set; }

        public bool IsEntitledToCancel { get; set; }
        public bool IsEntitledToRemoveDuplicateCheck { get; set; }
        public bool IsEntitledToPublish { get; set; }
        public bool IsAuthorized { get; set; }
        public bool AllowPDFtoUpload { get; set; }

        public bool IsUploadTaskClosedInSnow { get; set; }
        public bool IsReviewTaskClosedInSnow { get; set; }

        public string CurrentUserName { get; set; }

        public CurrentUser UserAuthorization { get; set; }

    }
}