﻿using DSARAgentUX.Models;
using System;
using System.Xml.Serialization;

namespace DSARAgentUX.UI.ViewModels
{
    public static class ModelFormatterHelpers
    {
        public static string GetShortDate(DateTime date)
        {
            return date.ToString("dd MMMM yyyy,hh:mm tt");
        }

        public static string GetDateOnly(DateTime date)
        {
            return date.ToString("dd MMMM yyyy");
        }

        public static string ReadXmlEnumAttributeValue<T>(T requestTypevalue)
        {
            Type type = typeof(T);
            if (string.IsNullOrWhiteSpace(requestTypevalue.ToString()))
                return requestTypevalue.ToString();
            var Info = type.GetMember(requestTypevalue.ToString());
            var attributes = Info[0].GetCustomAttributes(typeof(XmlEnumAttribute), false);
            return ((XmlEnumAttribute)attributes[0]).Name;
        }

    }
}