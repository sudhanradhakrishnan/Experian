﻿using System.Web.Mvc;
using System.Web.Routing;

namespace DSARAgentUX.UI
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.MapMvcAttributeRoutes();

            routes.MapRoute(
                "ErrorHandler",
                "Error/{action}/{Title}/{Message}",
                new
                {
                    controller = "Error",
                    action = "Index",
                    Title = "Application Error",
                    Message = "An Error occured, and we were unable to process your request."
                }
            );

            routes.MapRoute(
                "AccessDenied",
                "AccessDenied/{action}",
                new
                {
                    controller = "Error",
                    action = "AccessDenied",
                    Title = "Access Denied",
                    Message = "You dont have permission to view/access this feature."
                }
            );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );

            routes.MapRoute(
                 "PageNotFound",
                 "{*catchall}",
                new { controller = "Error", action = "PageNotFound" }
                    );
         }
    }
}