﻿using System.Collections.Generic;

namespace SecurityFileGenerator
{
    public class UserGroup
    {
        public string GroupId { get; set; }
        public Dictionary<string, Users> Users = new Dictionary<string, Users>();
    }
}