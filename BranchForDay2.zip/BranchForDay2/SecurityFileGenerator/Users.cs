﻿using System.Collections.Generic;

namespace SecurityFileGenerator
{
    public class Users
    {
        public string Id { get; set; }
        public List<string> Groups { get; set; }
        public string Name { get; set; }
        public string LanId { get; set; }
    }
}