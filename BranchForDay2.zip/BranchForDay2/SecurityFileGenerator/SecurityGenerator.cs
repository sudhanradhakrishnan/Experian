﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using static System.String;

namespace SecurityFileGenerator
{
    public class SecurityGenerator
    {
        private readonly Dictionary<string, Group> _groups = new Dictionary<string, Group>();
        private readonly Dictionary<string, Users> _users = new Dictionary<string, Users>();
        private readonly Dictionary<string, PdfReferences> _pdf = new Dictionary<string, PdfReferences>();

        private readonly List<string> _devUsers = new List<string>
        {
            // Developers
            @"EXPERIANUK\C51014A",
            @"EXPERIANUK\C51053A",
            @"EXPERIANUK\C51052A",
            @"EXPERIANUK\C510167",
            @"EXPERIANUK\C11241A",
            @"EXPERIANUK\c09792a",
            @"EXPERIANUK\c07198a",
            // Testers
            @"EXPERIANUK\C50385A",
            @"EXPERIANUK\C51054A",
            @"EXPERIANUK\C51055A",
            @"EXPERIANUK\C51056A",
        };


        private readonly List<string> snowAccessGroup = new List<string>
        {
            @"DSAR GSSE Data Quality Team",
            @"DSAR Small Change Team(BSO)",
            @"DSAR Salesforce Agents",
            @"DSAR EBC - Client Support",
        };

        private readonly ExcelUtilities _excelUtilities = new ExcelUtilities();

        public string FileLocation { get; }
        public string Env { get; }

        public SecurityGenerator(string location, string environment)
        {
            FileLocation = location;
            Env = environment;
        }

        public void Build()
        {
            ProcessFiles();
            GenerateXml();
        }

        private void GenerateXml()
        {
            const string customerServicingTeam = "DSAR Customer Servicing Team";

            var gt = _groups.Values.Select(x => new groupType {id = x.Id, name = x.Name}).ToArray();
            var ut = _users.Values.Select(x => new userType {id = x.LanId, group = x.Groups.ToArray()}).ToArray();

            var pdf = _pdf.Values.Select(x => new pdfType
            {
                id = x.PdfReference.ToString(),
                group = GetAccessGroups(x.AccessGroup, customerServicingTeam,x.AccessGroupQA),
                departmentName = x.DepartmentName,
                readableName = $"{ x.HumanReadableName}.pdf",
                serviceNowTaskName = x.ServiceNowTaskName,
                nodataFilename = $"NO_DATA_{x.PdfReference.ToString()}_{x.HumanReadableName}.pdf"
            }).ToArray();


            var serviceTeamGroupId = GetGroupId(customerServicingTeam);
            var am = new actionmapType
            {
                cancel = new[] {serviceTeamGroupId},
                publish = new[] {serviceTeamGroupId},
                removeDuplicateCheck = new[] {serviceTeamGroupId}
            };


            var st = new securityType
            {
                actionmap = am,
                groups = gt,
                users = ut,
                pdfmap = pdf
            };

            var xml = GenerateXml(st);

            var xmlFilename = "../../../DSARAgentUX.BusinessLayer/XML/security";

            switch (Env)
            {
                case "UAT":
                    xmlFilename += "_uat";
                    break;
                case "PROD":
                    xmlFilename += "_prod";
                    break;
                case "DEV":                   
                default:
                    break;
            }

            xmlFilename += ".xml";

            using (var writetext = new StreamWriter(xmlFilename))
            {
                writetext.WriteLine(xml);
            }

            var contents = File.ReadAllText(xmlFilename);

            var o = DeserializeXmlFileToObject<securityType>(contents);

            Console.WriteLine(xml);
        }

        public static T DeserializeXmlFileToObject<T>(string XmlFile)
        {
            var returnObject = default(T);
            if (IsNullOrEmpty(XmlFile)) return default(T);
            var outerXml = XmlFile;

            try
            {
                var serializer = new XmlSerializer(typeof(T),
                    AddNamespaceForXml("security", "http://experian.com/DSAR_Security/v1"));

                using (XmlReader reader = new XmlTextReader(new StringReader(outerXml)))
                {
                    returnObject = (T) serializer.Deserialize(reader);
                }
            }
            catch (Exception ex)
            {
                //TODO:need find the error method.
                Console.WriteLine(ex.Message);
            }

            return returnObject;
        }

        public static XmlRootAttribute AddNamespaceForXml(string elementname, string namespacename)
        {
            var xRoot = new XmlRootAttribute
            {
                ElementName = elementname,
                Namespace = namespacename,
                IsNullable = true
            };

            return xRoot;
        }

        public string[] GetAccessGroups(string accessGroup, string serviceGroup, string accessGroupQA)
        {
            var list = new List<string>();

            var accessGroupId = GetGroupId(accessGroup);
            var serviceGroupId = GetGroupId(serviceGroup);
            var accessGroupQAId = GetGroupId(accessGroupQA);

            if (!IsNullOrEmpty(accessGroupId))
            {
                list.Add(accessGroupId);
            }

            if(!String.Equals(accessGroup, accessGroupQA,StringComparison.OrdinalIgnoreCase))
            {
                list.Add(accessGroupQAId);
            }

            if (IsNullOrEmpty(serviceGroupId) || list.Contains(serviceGroupId))
                return list.ToArray();

            list.Add(serviceGroupId);

            return list.ToArray();
        }

        private static string GenerateXml(securityType st)
        {
            var ser = new XmlSerializer(st.GetType(), "http://experian.com/DSAR_Security/v1");
            string result;

            using (var memStm = new MemoryStream())
            {
                ser.Serialize(memStm, st);
                memStm.Position = 0;
                result = new StreamReader(memStm).ReadToEnd();
            }

            return result;
        }

        private void ProcessFiles()
        {
            var files = Directory.GetFiles(FileLocation, "*.xlsx");
            var groupFile = "";
            var memberFile = "";
            var pdfFile = "";

            foreach (var file in files)
            {
                if (file.StartsWith("~"))
                    continue;


                groupFile = file;
                pdfFile = file;
                // https://experiantest.service-now.com/nav_to.do?uri=%2Fsys_report_template.do%3Fjvar_report_id%3Dac4d4339dbed5744417e3f3ffe9619bb%26jvar_selected_tab%3DgroupReports%26jvar_list_order_by%3DmodificationDate%26jvar_list_sort_direction%3Ddesc%26sysparm_reportquery%3D%26jvar_search_created_by%3D%26jvar_search_table%3D%26jvar_search_report_sys_id%3D%26jvar_report_home_query%3D
                // https://experiantest.service-now.com/nav_to.do?uri=%2Fsys_report_template.do%3Fjvar_report_id%3D720a781cdb8a9744b7f5317ffe9619ec%26jvar_selected_tab%3DmyReports%26jvar_list_order_by%3D%26jvar_list_sort_direction%3D%26sysparm_reportquery%3D%26jvar_search_created_by%3D%26jvar_search_table%3D%26jvar_search_report_sys_id%3D%26jvar_report_home_query%3D
                if (file.Contains("sys_user_group"))
                {
                    groupFile = file;
                }
                else if (file.Contains("sys_user_grmember"))
                {
                    memberFile = file;
                }
                else if (file.Contains("DSAR URIs"))
                {
                    pdfFile = file;
                }
            }

            ProcessGroup(groupFile);
           // ProcessMembers(memberFile);
            ProcessPdfGroups(pdfFile);
        }

        private void ProcessPdfGroups(string pdfFile)
        {
            _excelUtilities.SetExcelFile(pdfFile, "PDF To Task Mapping");

            try
            {
                for (var row = 2; row <= _excelUtilities.Sheet.UsedRange.Rows.Count; row++)
                {
                    var pdfReference = _excelUtilities.GetCellData(row, 1);
                    var departmentName = _excelUtilities.GetCellData(row, 2);
                    var serviceNowTaskName = _excelUtilities.GetCellData(row, 3);
                    var groupName = _excelUtilities.GetCellData(row, 4);
                    var groupNameqa = _excelUtilities.GetCellData(row, 5);
                    var humanReadableName = _excelUtilities.GetCellData(row, 6);

                    if (IsNullOrEmpty(pdfReference))
                        continue;

                    _pdf.Add(pdfReference, new PdfReferences
                    {
                        PdfReference = Convert.ToInt32(pdfReference),
                        DepartmentName = departmentName,
                        ServiceNowTaskName = serviceNowTaskName,
                        AccessGroup = groupName,
                        AccessGroupQA = groupNameqa,
                        HumanReadableName = humanReadableName
                    });
                }
            }
            finally
            {
                _excelUtilities.Close();
            }
        }

        private void ProcessMembers(string membersFile)
        {
//            ProcessDevMembers();
//            return;
            _excelUtilities.SetExcelFile(membersFile, "Page 1");

            var id = 1;
            try
            {
                for (var row = 2; row <= _excelUtilities.Sheet.UsedRange.Rows.Count; row++)
                {
                    var key = id.ToString();
                    var group = _excelUtilities.GetCellData(row, 1);
                    var user = _excelUtilities.GetCellData(row, 3);
                    var lanid = _excelUtilities.GetCellData(row, 4);

                    if (!_users.ContainsKey(key))
                    {
                        _users.Add(id.ToString(), new Users
                        {
                            Id = id.ToString(),
                            LanId = lanid,
                            Groups = new List<string>(),
                            Name = user
                        });
                    }

                    var groupId = GetGroupId(group);
                    _users[key].Groups.Add(groupId);

                    id++;
                }
            }
            finally
            {
                _excelUtilities.Close();
            }
        }

        private void ProcessDevMembers()
        {
            foreach (var u in _devUsers)
            {
                var users = new Users
                {
                    Id = u,
                    Name = "",
                    Groups = _groups.Select(x => x.Key).ToList()
                };

                _users.Add(u, users);
            }
        }

        private string GetGroupId(string group)
        {
            var groupId = "";
            foreach (var g in _groups)
            {
                if (g.Value.Name.Trim().Equals(group.Trim()))
                {
                    groupId = g.Key;
                }
            }

            return groupId;
        }

        private void ProcessGroup(string groupFile)
        {
            _excelUtilities.SetExcelFile(groupFile, "PDF To Task Mapping");
            Dictionary<string, Group> _validategroups = new Dictionary<string, Group>();
            try
            {
                var id = 1;

                foreach (var snow in snowAccessGroup)
                {
                    //AddAccessGroup(_validategroups, id.ToString(), snow);
                }
                
                for (var row = 2; row <= _excelUtilities.Sheet.UsedRange.Rows.Count; row++)
                {
                    var key = id.ToString();
                    var name = _excelUtilities.GetCellData(row, 4);
                    if (!_validategroups.ContainsKey(name))
                    {
                        AddAccessGroup(_validategroups, key, name);                       
                    }

                    var nameReview = _excelUtilities.GetCellData(row, 5);
                    if (!_validategroups.ContainsKey(nameReview))
                    {
                        AddAccessGroup(_validategroups, key, nameReview);                       
                    }
                    Console.WriteLine($"{name}");
                }


                id = 1;
                foreach (var validategroup in _validategroups.OrderBy(x => x.Key))
                {
                    var name = validategroup.Key;

                    if (!_groups.ContainsKey(name))
                    {
                        _groups.Add(id.ToString(), new Group
                        {
                            Id = id.ToString(),
                            Name = name.Trim(),
                        });

                        id++;
                    }
                }
            }
            finally
            {
                _excelUtilities.Close();
            }
        }

        private static void AddAccessGroup(Dictionary<string, Group> _validategroups, string key, string snow)
        {
            _validategroups.Add(snow, new Group
            {
                Id = key.Trim(),
                Name = snow.Trim(),
            });
        }
    }
}