﻿namespace SecurityFileGenerator
{
    public class Group
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Manager { get; set; }
        public bool Active { get; set; }
    }
}