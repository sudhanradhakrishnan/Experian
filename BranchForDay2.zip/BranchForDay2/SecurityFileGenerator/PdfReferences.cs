﻿namespace SecurityFileGenerator
{
    public class PdfReferences
    {
        public int PdfReference { get; set; }
        public string AccessGroup { get; set; }
        public string HumanReadableName { get; set; }
        public string DepartmentName { get; set; }
        public string ServiceNowTaskName { get; set; }
        public string AccessGroupQA { get; set; }
    }
}