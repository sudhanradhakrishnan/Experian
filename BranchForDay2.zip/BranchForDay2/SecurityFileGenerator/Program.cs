﻿namespace SecurityFileGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            var location = args.Length > 0 ? args[0] : @"C:\DSAR\Security\";

            var env = args.Length > 1 ? args[1] : "DEV";

            var s = new SecurityGenerator(location, env);
            s.Build();
        }
    }
}