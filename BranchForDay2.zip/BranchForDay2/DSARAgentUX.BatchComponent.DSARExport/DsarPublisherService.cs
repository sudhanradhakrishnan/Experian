﻿using DSARAgentUX.BusinessLayer;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Common;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using ExperianLogger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.IO;
using DSARAgentUX.Models;

namespace DSARAgentUX.BatchComponent.DSARExport
{
    public class DsarPublisherService
    {
        private ILogger Logger { get; }
        public bool DebugMode { get; set; }
        readonly string _dsarPublishPath = ConfigurationManager.AppSettings["dsarpublishpath"];
        readonly string _stsDropPath = ConfigurationManager.AppSettings["stsdroppath"];
        private readonly IDsarBatchComponentService _batchComponentService;
        private readonly string CANCELLED = "CANCELLED";
        private readonly string CANCEL = "CANCEL";
        private readonly string REMOVEDUPLICATECHECK = "REMOVE_DUPLICATE_CHECK";
        public delegate string Publisher(string x);

        public DsarPublisherService()
        {
            Logger = new Logger();
            _batchComponentService = new DsarBatchComponentService();
        }

        public void Start()
        {
            try
            {
                var lstpublishedfile = PublishDsar();
                DropDsarDetailToSts(lstpublishedfile);               
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError($"DSAREXPORT05 ERROR ,FUNCTION NAME:DsarScheduler {ex.Message}");
            }
        }

        private List<DsarInformation> PublishDsar()
        {
            var lstpublished = new List<DsarInformation>();
            var currentDsar = "";
            try
            {
                Logger.LogApplicationInfo("DSAREXPORT01", "Geting All Published Dsar");
                foreach (var zipWrapper in _batchComponentService.GetAllPublishedDsarZipMem())
                {
                    currentDsar = zipWrapper.DsarValue.Reference;
                    using (var fileStream =
                        new FileStream($"{_dsarPublishPath}{zipWrapper.DsarValue.Reference}.zip", FileMode.Create))
                    {
                        var memoryStream = new MemoryStream(zipWrapper.ZipInMemory.ToArray());
                        memoryStream.Seek(0, SeekOrigin.Begin);
                        memoryStream.CopyTo(fileStream);
                    }
                    Logger.LogApplicationInfo("DSAREXPORT03", "DSAR Refreance:" + currentDsar + " Ziped to " + _dsarPublishPath + " loaction");
                    _batchComponentService.UpdatePublishStatus(zipWrapper.DsarValue.Reference);
                    Logger.LogApplicationInfo("DSAREXPORT05", "Updated Publish Status for DSAR Refreance : " + currentDsar);
                    lstpublished.Add(new DsarInformation
                    {
                        Reference = zipWrapper.DsarValue.Reference,
                        Status = zipWrapper.DsarValue.Status,
                        Duplicate = zipWrapper.DsarValue.Duplicate
                    });
                }
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError($"PublishDSAR : {currentDsar} - {ex.Message}");
            }

            return lstpublished;
        }

        private void DropDsarDetailToSts(List<DsarInformation> lstpublish)
        {
            try
            {
               
                var lstcanDup = _batchComponentService.DropCsvForCompletedAndDuplicateDsaRs();
                Logger.LogApplicationInfo("DSAREXPORT03", "Pulled Cancel and Duplicate DSAR from the Database");
                lstpublish.AddRange(lstcanDup);
                var path = _stsDropPath + "DsarMainframeUpdate-" + DateTime.Now.ToString("ddMMyyyy") + ".txt";
                WriteDataToCsvFile(path, lstpublish);
                UpdateCancelDuplicate();
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError($"DSAR AGENT UX CREATE FLAT FILE {ex.Message}");
            }
        }
        private void WriteDataToCsvFile(string path, IEnumerable<DsarInformation> publishedDsars)
        {
            try
            {
                using (var writer = new CsvFileWriter(path))
                {
                    var dsarInformations = publishedDsars as DsarInformation[] ?? publishedDsars.ToArray();
                    if (dsarInformations.Any())
                    {
                        foreach (var dsar in dsarInformations)
                        {
                            var status = dsar.Status.ToString().ToUpper() == CANCELLED ? CANCEL : dsar.Status.ToString().ToUpper();

                            var row = new CsvRow
                            {
                                dsar.Reference +(dsar.Duplicate == DuplicateCheckStatusType.MarkedDuplicate ? REMOVEDUPLICATECHECK : status)
                            };
                            writer.WriteRow(row);
                        }
                    }
                    else
                    {
                        var row = new CsvRow { "" };
                        writer.WriteRow(row);
                    }
                   
                }
                Logger.LogApplicationInfo("DSAREXPORT04", "Droped Dsar Detail To STS location : " + _stsDropPath);
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError($"DSAR AGENTUX CREATE FLAT FILE {ex.Message}");
                Logger.LogApplicationDebug("NOT_SEND_TO_MF", $"{ex.Message}");
            }
        }

        private void UpdateCancelDuplicate()
        {
            try
            {
                _batchComponentService.UpdateCancelDuplicateInformation();
                Logger.LogApplicationInfo("DSAREXPORT01", "Updated Cancel and Duplicate Information to DataBase");
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError($"DSAR AGENT UX UPDATE CANCEL AND DUPLICATECHECK {ex.Message}");
            }
        }
    }
}
