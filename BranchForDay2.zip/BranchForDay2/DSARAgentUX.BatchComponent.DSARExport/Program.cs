﻿using System;
using System.ServiceProcess;
using ExperianLogger;

namespace DSARAgentUX.BatchComponent.DSARExport
{
    class Program
    {
        static void Main(string[] args)
        {
            DsarPublisherService service = new DsarPublisherService();
            service.Start();
        }
    }
}