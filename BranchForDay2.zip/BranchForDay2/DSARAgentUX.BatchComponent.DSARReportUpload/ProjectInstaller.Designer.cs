﻿namespace DSARAgentUX.BatchComponent.DSARReportUpload
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dsarReportUploadserviceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.dsarReportUploadserviceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // dsarReportUploadserviceProcessInstaller
            // 
            this.dsarReportUploadserviceProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalSystem;
            this.dsarReportUploadserviceProcessInstaller.Password = null;
            this.dsarReportUploadserviceProcessInstaller.Username = null;
            // 
            // dsarReportUploadserviceInstaller
            // 
            this.dsarReportUploadserviceInstaller.ServiceName = "DSARAgentUX.BatchComponent.DSARReportUpload";
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.dsarReportUploadserviceProcessInstaller,
            this.dsarReportUploadserviceInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller dsarReportUploadserviceProcessInstaller;
        private System.ServiceProcess.ServiceInstaller dsarReportUploadserviceInstaller;
    }
}