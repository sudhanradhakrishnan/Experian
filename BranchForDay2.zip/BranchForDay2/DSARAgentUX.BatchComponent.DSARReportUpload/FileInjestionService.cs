﻿using DSARAgentUX.BusinessLayer;
using DSARAgentUX.Common;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.DataAccessLayer.Interface;
using DSARAgentUX.DataAccessLayer.Repositories;
using DSARAgentUX.Models;
using ExperianLogger;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using DSARAgentUX.Models.DataSubjectAccessRequests;

namespace DSARAgentUX.BatchComponent.DSARReportUpload
{
    public partial class FileInjestionService : ServiceBase
    {
        private FileSystemWatcher _watcher;
        private string _pdfPath;
        string _fullPath;
        private static ILogger _logger;
        private readonly FileWaiter _fileWaiter;
        private IFileUploadRepository FileUploadRepository { get; }

        public bool DebugMode { get; set; }

        public FileInjestionService()
        {
            InitializeComponent();
            _logger = new Logger();
            _fileWaiter = new FileWaiter();
            FileUploadRepository = new FileUploadRepository();

        }

        protected override void OnStart(string[] args)
        {
            try
            {
                using (var log = new EventLog("Application"))
                {
                    log.Source = "DSARAgentUX.BatchComponent.DSARReportUpload";
                    log.WriteEntry("DSAR Pdf Upload  Service started", EventLogEntryType.Information, 101, 1);

                    _pdfPath = ConfigurationManager.AppSettings["pdfauto:input"];

                    _watcher = new FileSystemWatcher(_pdfPath, "*.pdf");
                    _watcher.Changed += FileChanged;
                    _watcher.Error += _watcher_Error;
                    _watcher.IncludeSubdirectories = false;
                    _watcher.EnableRaisingEvents = true;

                    _logger.LogApplicationInfo("DABC001", "DSAR Pdf Upload service is now started");

                    if (DebugMode)
                    {
                        PerformWait();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogApplicationError($"DSAR Pdf Upload service failed : {ex.Message}");
                throw;
            }
        }

        private void _watcher_Error(object sender, ErrorEventArgs e)
        {
            _logger.LogApplicationError($"DSAR Pdf Upload Watcher failed : {e.GetException().Message}");
        }

        private void FileChanged(object sender, FileSystemEventArgs eventArgs)
        {
            try
            {
                var filePath = eventArgs.FullPath;

                var processPdfFileUpload = new ProcessFileUpload(filePath);
                if (_fileWaiter.FileRestPeriodIsOver(filePath))
                    _fileWaiter.EnableFileToBeProcessed(filePath);

                if (_fileWaiter.fileCreatedOrChangedAndNotResting(eventArgs, filePath))
                {
                    _fileWaiter.RestFile(filePath);
                    _fileWaiter.waitForFileToBeReady(filePath);
                    processPdfFileUpload.ProcessFile();
                }
            }
            catch (Exception ex)
            {
                _logger.LogApplicationError($"Error occured .File {_fullPath} returned exception: {ex.Message}");
            }
        }





        protected override void OnStop()
        {
            _watcher.Dispose();
        }

        public void Test()
        {
            DebugMode = true;
            OnStart(new[] { "" });
            Console.ReadLine();
            OnStop();
        }

        private void PerformWait()
        {
            if (DebugMode)
            {
                Task.Delay(3000000).Wait();
            }
        }

    }
}