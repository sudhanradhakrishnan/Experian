﻿using DSARAgentUX.BusinessLayer;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Common;
using DSARAgentUX.Models;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using DSARAgentUX.Models.ServiceNow.Request;
using ExperianLogger;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace DSARAgentUX.BatchComponent.DSARReportUpload
{
    public class ProcessFileUpload
    {
        private string fileName;
        private string dsarReference;
        private string pdfReference;
        private string constant;

        private string _modifyUser;
        private string _configNoData;

        private List<string> _dsarsReferenceNumber;
        private List<string> _messageContent;

        private byte[] _fileContent;

        private readonly IDsarPDFIngestionService _dsarPdfIngestionService;
        private ReportConstant _reportType;
        enum ReportConstant { NO_DATA, REPORT, REPORT_P };

        public string FullPath { get; set; }
        public ILogger Logger { get; set; }
        public string snowResponse { get; set; }
        public ProcessFileUpload(string filePath)
        {
            _configNoData = ConfigurationManager.AppSettings["db:nodata"];

            FullPath = filePath;
            Logger = new Logger();
            _dsarsReferenceNumber = new List<string>();
            _messageContent = new List<string>();

            _dsarPdfIngestionService = new DsarPDFIngestionService();
        }


        public void ProcessFile()
        {
            try
            {
                fileName = Path.GetFileName(FullPath);
                _fileContent = File.ReadAllBytes(FullPath);

                _modifyUser = File.GetAccessControl(FullPath).GetOwner(typeof(System.Security.Principal.NTAccount)).ToString();

                if (_fileContent.IsFileSizeExceedsLimit())
                {
                    WriteAuditContent($"User has exceeded file size when trying to upload content for Dsar {dsarReference} and item reference {pdfReference}");
                    return;
                }

                SplitFileNameIntoDsarRefAndReportRef();
                
                ServiceUserModel dsarObject = _dsarPdfIngestionService.GetDsarInformation(dsarReference);

                if (string.IsNullOrEmpty(dsarObject.DsarReference) == true)
                {
                    WriteAuditContent($"Rejected : Dsar reference is not valid");
                    return;
                }
                
                if (dsarObject.DsarStatus == DsarStatusType.Published 
                    || dsarObject.DsarStatus == DsarStatusType.Cancelled
                    || dsarObject.PublishStatus == PublishStatusType.ReadyToPublish
                    || dsarObject.DsarCancelStatus == DsarCancelType.ReadyToCancel )
                {
                    CreateMessage(dsarObject);
                    return;
                }

                // TODO :: CheckValid ReportReference



                PdfFileDetails pdfFileDetails = new PdfFileDetails
                {
                    FileName = fileName,
                    FileContent = _fileContent,
                    Status = PDFStatusType.Uploaded
                };
                
                _reportType = (ReportConstant)Enum.Parse(typeof(ReportConstant), constant);
                
                switch (_reportType)
                {
                    case ReportConstant.REPORT:
                    case ReportConstant.NO_DATA:
                        CommitPrimaryReport(_reportType, pdfFileDetails);
                        break;

                    case ReportConstant.REPORT_P:
                        CommitPostalReport(_reportType, pdfFileDetails);
                        break;

                    default:
                        WriteAuditContent($"Rejected, Invalid File Name.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Logger.LogApplicationError($"Error occured while uploading the file for DSAR Reference : {dsarReference}. Exception: {ex.Message}");
                WriteLocalFileResponse($"Error occured while uploading the file for DSAR Reference : {dsarReference}. Exception: {ex.Message}");
            }
        }

        private void CommitPrimaryReport(ReportConstant reportType, PdfFileDetails pdfFileDetails)
        {
            var pdfFound = _dsarPdfIngestionService.CheckDuplicatePDF(dsarReference, pdfReference); ;

            if (pdfFound == true)
            {
                WriteAuditContent($"Rejected: Report already uploaded against Dsar:{dsarReference}, Report:{pdfReference}");
                return;
            }

            var returnOutput = 0;

            if (Equals(ReportConstant.NO_DATA, reportType))
            {
                returnOutput = _dsarPdfIngestionService
                    .UploadStateNoDataPDF(_configNoData, dsarReference, pdfReference, string.Empty, _modifyUser);
            }
            else
            {
                returnOutput = _dsarPdfIngestionService
                    .UploadPdf(pdfFileDetails, pdfFileDetails.Status, dsarReference, pdfReference, _modifyUser);
            }

            if (returnOutput == 1)
            {
                WriteAuditContent(
                    $"Successfully uploaded {reportType} report against DSAR:{dsarReference} & Report:{pdfReference}");
            }

            snowResponse = _dsarPdfIngestionService.UpdateSnowDsarUploadTask(new SnowUpdateDsarRequest() { dsar_ref = dsarReference, dsar_pdf = pdfReference });
            if (snowResponse.Equals("API_FAILURE"))
            {
                WriteAuditContent(
                    $"Failed to update ServiceNow Upload Task against DSAR:{dsarReference} & Report:{pdfReference}");
            }

            snowResponse = _dsarPdfIngestionService.UpdateSnowDsarReviewTask(new SnowUpdateDsarRequest() { dsar_ref = dsarReference, dsar_pdf = pdfReference });
            if (snowResponse.Equals("API_FAILURE"))
            {
                WriteAuditContent(
                    $"Failed to update ServiceNow Review Task against DSAR:{dsarReference} & Report:{pdfReference}");
            }
        }

        private void CommitPostalReport(ReportConstant reportType, PdfFileDetails pdfFileDetails)
        {
            var postalPdfFound = _dsarPdfIngestionService.CheckDuplicatePostalPDF(dsarReference, pdfReference);

            if (postalPdfFound == true)
            {
                WriteAuditContent($"Rejected: Postal Report already uploaded against Dsar:{dsarReference}, Report:{pdfReference}");
                return;
            }

            var returnOutput = 0;
            returnOutput = _dsarPdfIngestionService
                .UploadPostalPdf(pdfFileDetails, pdfFileDetails.Status, dsarReference, pdfReference, _modifyUser);

            if (returnOutput == 1)
            {
                WriteAuditContent(
                    $"Successfully uploaded Postal Report against DSAR:{dsarReference} & Report :{pdfReference}. ServiceNow:{snowResponse}");
            }

        }

        private void SplitFileNameIntoDsarRefAndReportRef()
        {
            string[] fileInfo = FullPath.ToUpper().Replace(".PDF", "").Split('_');
            string[] dsarInfo = fileInfo[0].Split('\\');

            if (dsarInfo.Length > 0)
            {
                dsarReference = dsarInfo[dsarInfo.Length - 1];
            }

            switch (fileInfo.Length)
            {
                case 3:
                    pdfReference = fileInfo[1];
                    constant = fileInfo[2];
                    break;
                case 4:
                    pdfReference = fileInfo[1];
                    constant = fileInfo[2] + "_" + fileInfo[3];
                    break;
                default:
                    CreateMessage();
                    return;
            }
        }

        private void CreateMessage()
        {
            WriteAuditContent($"Rejected: DSAR is not valid");
            return;   
        }

        private void CreateMessage(ServiceUserModel dsarObject)
        {
            if (string.IsNullOrEmpty(dsarObject?.DsarReference))
            {
                WriteAuditContent($"Rejected: DSAR is not valid");
                return;
            }
            
            var result = "";
            
            if (Equals(DsarStatusType.Published, dsarObject.DsarStatus))
            {
                result += $"Rejected: Not able to upload against {dsarReference} because this DSAR is published";
            }
            else if (Equals(DsarStatusType.Cancelled, dsarObject.DsarStatus))
            {
                result += $"Rejected: Not able to upload against {dsarReference} because this DSAR is Cancelled";
            }

            else if (Equals(PublishStatusType.Published, dsarObject.DsarCancelStatus))
            {
                result += $"Rejected: Not able to upload against {dsarReference} because this DSAR is published";
            }
            else if (Equals(PublishStatusType.ReadyToPublish, dsarObject.DsarCancelStatus))
            {
                result += $"Rejected: Not able to upload against {dsarReference} because this DSAR is in Ready To Publish state";
            }
            else if (Equals(DsarCancelType.Cancelled, dsarObject.DsarCancelStatus))
            {
                result += $"Rejected: Not able to upload against {dsarReference} because this DSAR is Cancelled";
            }

            else if (Equals(DsarCancelType.ReadyToCancel, dsarObject.DsarCancelStatus))
            {
                result += $"Rejected: Not able to upload against {dsarReference} because this DSAR  is in Ready To be Cancelled state";
            }
            
            WriteAuditContent(result);

        }

        private void WriteAuditContent(string result)
        {
            Logger.LogApplicationInfo(Constantfields.DsarBatchReportLoad, result);
            WriteLocalFileResponse(result);
        }


        private void WriteLocalFileResponse(string result)
        {
            fileName = fileName.ToUpper().Replace(".PDF", "");
            string path = ConfigurationManager.AppSettings["pdfauto:output"] + fileName + (result.Contains($"Rejected") ? $"_Rejected.txt" : $"_Uploaded.txt");
            if (!File.Exists(path))
            {
                using (StreamWriter sw = File.CreateText(path))
                {
                    sw.WriteLine(result);
                }
            }
        }

    }
}
