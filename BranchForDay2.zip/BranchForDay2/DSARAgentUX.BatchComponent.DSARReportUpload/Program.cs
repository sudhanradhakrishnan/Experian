﻿using System;
using System.ServiceProcess;

namespace DSARAgentUX.BatchComponent.DSARReportUpload
{
    static class Program
    {
        private static void Main()
        {
            if (Environment.UserInteractive)
            {
                var service = new FileInjestionService();
                service.Test();

            }
            else
            {
                var servicesToRun = new ServiceBase[]
                   {
                        new FileInjestionService()
                   };

                ServiceBase.Run(servicesToRun);
            }
        }
             

    }
}
