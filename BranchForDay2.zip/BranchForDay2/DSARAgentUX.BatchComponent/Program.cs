﻿using System;
using System.ServiceProcess;

namespace DSARAgentUX.BatchComponent
{
    static class Program
    {
        private static void Main()
        {
            if (Environment.UserInteractive)
            {
                var service = new XmlInjestionService();
                service.Test();

            }
            else
            {
                var servicesToRun = new ServiceBase[]
                   {
                        new XmlInjestionService()
                   };

                ServiceBase.Run(servicesToRun);
            }
        }
    }
}
