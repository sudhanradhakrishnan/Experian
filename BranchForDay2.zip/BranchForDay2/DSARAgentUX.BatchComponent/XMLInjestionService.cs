﻿using DSARAgentUX.BusinessLayer;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.BusinessLayer.LoadProcess;
using DSARAgentUX.Common;
using DSARAgentUX.Models;
using DSARAgentUX.Models.ServiceNow.Request;
using ExperianLogger;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;

namespace DSARAgentUX.BatchComponent
{
    public partial class XmlInjestionService : ServiceBase
    {
        private FileSystemWatcher _watcher;
        private string _xmlPath;
        private IDsarBatchComponentService _batchComponentService;
        string _dir;
        string _convertedFileName;
        string _fullPath;
        private static ILogger _logger;
        private readonly FileWaiter _fileWaiter;

        private List<string> _dsarsReferanceNumber;
        private List<string> _messageContent;

        public bool DebugMode { get; set; }

        public XmlInjestionService()
        {
            InitializeComponent();
            _logger = new Logger();
            _fileWaiter = new FileWaiter();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                using (var log = new EventLog("Application"))
                {
                    log.Source = "DSARAgentUX.BatchComponent.DSARLoad";
                    log.WriteEntry("DSAR Load Service started", EventLogEntryType.Information, 101, 1);

                    _xmlPath = ConfigurationManager.AppSettings["dSARXmlPath"];

                    _watcher = new FileSystemWatcher(_xmlPath, "*.xml");
                    _watcher.Changed += FileChanged;
                    _watcher.Error += _watcher_Error;
                    _watcher.IncludeSubdirectories = false;
                    _watcher.EnableRaisingEvents = true;

                    _logger.LogApplicationInfo("DABC001", "DSAR Batch component service is now started");

                    if (DebugMode)
                    {
                        PerformWait();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogApplicationError($"DSAR Batch component service failed : {ex.Message}");
                throw;
            }
        }

        private void _watcher_Error(object sender, ErrorEventArgs e)
        {
            _logger.LogApplicationError($"DSAR Batch component File Watcher failed : {e.GetException().Message}");
        }

        private void FileChanged(object sender, FileSystemEventArgs eventArgs)
        {
            try
            {
                var filePath = eventArgs.FullPath;
                _dsarsReferanceNumber = new List<string>();
                _messageContent = new List<string>();
                if (_fileWaiter.FileRestPeriodIsOver(filePath))
                    _fileWaiter.EnableFileToBeProcessed(filePath);

                if (_fileWaiter.fileCreatedOrChangedAndNotResting(eventArgs, filePath))
                {
                    _fileWaiter.RestFile(filePath);
                    _fileWaiter.waitForFileToBeReady(filePath);
                    ProcessFile(filePath);
                }
            }
            catch (Exception ex)
            {
                _logger.LogApplicationError($"Error occured .File {_fullPath} returned exception: {ex.Message}");
                _convertedFileName = Path.GetFileName(_fullPath) + ".error." + DateTime.Now.ToString("yyyyMMddhhmmtt");
                _messageContent.Add(ex.Message);
                WriteFile(_dir, _convertedFileName, _messageContent);
            }
        }


        private void ProcessFile(string fileName)
        {
            _fullPath = fileName;
            _batchComponentService = new DsarBatchComponentService();
            var xml = ValidateXml();
            _logger.LogApplicationInfo("DSARINFO", $"File {_fullPath} is validated successfully");

            ValidateDataSources(xml);

            IterateDsars(xml);
            if (_dsarsReferanceNumber.Contains(Constantfields.NODATA))
            {
                _messageContent.Add(Constantfields.NODATARECEIVED);
            }
            else
            {
                foreach (string dsarNumber in _dsarsReferanceNumber)
                {
                    _messageContent.Add($"Data loaded to DB {dsarNumber}");
                }
            }
            WriteFile(_dir, _convertedFileName, _messageContent);
            GenerateDsarOutput();


        }

        private void ValidateDataSources(XmlDocument xml)
        {
            XmlNodeList listOfDsars = xml.SelectNodes("//dsar");

            foreach (XmlNode singleContact in listOfDsars)
            {
                if (Helpers.HasAudioAndDepartmentSource(singleContact))
                {
                    throw new Exception($"Error occurred . Inserting XML to DB failed, XML has audio department and other department");
                }
            }
        }

        private void GenerateDsarOutput()
        {
            var outGenerator = new DsarOutputGenerator();
            outGenerator.AddGenerator(new BUFileDsarOutput(_fullPath));
            outGenerator.AddGenerator(new HumanFriendlyDsarOutput(_fullPath));
            outGenerator.BuildAll(_fullPath);
            _logger.LogApplicationInfo("DSAR APPLICATION INFO", $"File {_fullPath} processed and successfully generated output files");

            GeneratorServiceNowTask(outGenerator);
        }


        private void GeneratorServiceNowTask(DsarOutputGenerator dsaroutGenerator)
        {

            int count = 1;
            if (dsaroutGenerator._list != null && dsaroutGenerator._list.Count > count)
            {
                var humanFriendlyDsar = (HumanFriendlyDsarOutput)dsaroutGenerator._list[count];
                using (var snowGenerator = new SnowTaskGenerator(humanFriendlyDsar.GeneratedFileName, humanFriendlyDsar.dsarRequest))
                {
                    if (Convert.ToBoolean(ConfigurationManager.AppSettings["Snow:enableTaskCreation"]))
                    {
                        snowGenerator.CreateServiceNowTaskUsingDsarRef();
                    }
                }

                var buFileDsarOutput = (BUFileDsarOutput)dsaroutGenerator._list[0];
                buFileDsarOutput.BUFileContent.Save(buFileDsarOutput.GeneratedFileName);

            }


            _logger.LogApplicationInfo("DSAR APPLICATION INFO", $"File {_fullPath} Appended with Service Now Task number and successfully generated output files");

        }


        private void IterateDsars(XmlDocument validatedAvcoxml)
        {
            IterateDsarsAndInsertIntoDatabaseOneByOne(validatedAvcoxml);
            _convertedFileName = Path.GetFileName(_fullPath) + ".processed." + DateTime.Now.ToString("yyyyMMddhhmmtt");
        }

        private XmlDocument ValidateXml()
        {
            _dir = Path.GetDirectoryName(_fullPath);
            var avcoxml = GetEmbeddedResourceContent("DSAR_Submission.xsd");
            var validatedAvcoxml = ValidateAvcoxmlAgainstXsd(avcoxml, _fullPath);
            return validatedAvcoxml;
        }

        private void IterateDsarsAndInsertIntoDatabaseOneByOne(XmlDocument validatedAvcoxml)
        {
            try
            {

                foreach (XmlNode dsar in validatedAvcoxml)
                {
                    if (dsar.NodeType != XmlNodeType.Element)
                        continue;
                    if (dsar.ChildNodes.Count > 0 && dsar.ChildNodes[0].Name == Constantfields.TRANSFERMESSAGE)
                    {
                        _dsarsReferanceNumber.Add(Constantfields.NODATA);
                        break;
                    }
                    foreach (XmlNode dsarlist in dsar.ChildNodes)
                    {
                        var dsarReference = ((XmlElement)dsarlist.ChildNodes[0]).InnerXml;
                        if (_batchComponentService.CheckDsarDuplicate(dsarReference))
                        {
                            _logger.LogApplicationInfo("DSAR INFO",
                                $"DSAR Duplicate Reference Number found :{dsarReference}");

                            throw new Exception($"XML Injestion Failed. DSARReference :{dsarReference} already exists");
                        }
                    }
                    foreach (XmlNode dsarlist in dsar.ChildNodes)
                    {
                        _batchComponentService.SaveAvcoxml(dsarlist.OuterXml);
                        var dsarReference = ((XmlElement)dsarlist.ChildNodes[0]).InnerXml;
                        _dsarsReferanceNumber.Add(dsarReference);
                        _logger.LogApplicationInfo("DSAR INFO", $"DSAR Reference Number : { dsarReference } loaded to DB");
                    }
                }

                _logger.LogApplicationDebug("DSAR DEBUG INFO", "Inserted the XML data to DB");
            }
            catch (Exception ex)
            {
                _logger.LogApplicationError(
                    $"Error occured . Inserting XML to DB failed,Returned exception: {ex.Message}");
                throw;
            }
        }

        private static Stream GetEmbeddedResourceContent(string resourceFilename)
        {
            try
            {
                var assembly = Assembly.GetAssembly(typeof(dsars));
                var resourcesfile = assembly.GetManifestResourceNames();
                var filename = resourcesfile.FirstOrDefault(o => o.Contains(resourceFilename));
                var stream = assembly.GetManifestResourceStream(filename);
                string text;
                if (stream == null)
                {
                    throw new Exception($"Embedded resource { filename } doesn't exists");
                }

                var bytes = new byte[stream.Length];
                stream.Position = 0;
                stream.Read(bytes, 0, (int)stream.Length);
                using (var mstream = new MemoryStream(bytes))
                {
                    using (var reader = new StreamReader(mstream))
                    {
                        text = reader.ReadToEnd();
                    }
                }

                var streamxsd = new MemoryStream();
                var writer = new StreamWriter(streamxsd);
                writer.Write(text);
                writer.Flush();
                streamxsd.Position = 0;
                return streamxsd;
            }
            catch (Exception ex)
            {
                _logger.LogApplicationError(
                    $"Error occured, while getting embedded resource content,Returned exception: {ex.Message}");
                throw;
            }
        }

        private static XmlDocument ValidateAvcoxmlAgainstXsd(Stream xsdLocation, string _fullPath)
        {
            var tr = new XmlTextReader(xsdLocation);
            var schema = new XmlSchemaSet();
            schema.Add(null, tr);

            var settings = new XmlReaderSettings
            {
                ValidationType = ValidationType.Schema
            };

            settings.Schemas.Add(schema);
            settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
            settings.ValidationEventHandler += ValidationEventHandler;
            var doc = new XmlDocument { XmlResolver = null };
            using (var xmlReader = XmlReader.Create(_fullPath, settings))
            {
                doc.Load(xmlReader);
            }

            return doc;
        }

        private static void ValidationEventHandler(object sender, ValidationEventArgs ex)
        {
            switch (ex.Severity)
            {
                case XmlSeverityType.Error:
                    _logger.LogApplicationError(
                        $"Error occured .XMLinjestionService: Line:214 >> ValidationEventHandler: {ex.Message}");
                    throw new Exception(ex.Message);
                case XmlSeverityType.Warning:
                    _logger.LogApplicationError(
                        $"Error occured .XMLinjestionService: Line:220 >> ValidationEventHandler: {ex.Message}");
                    break;
                default:
                    _logger.LogApplicationError(
                        $"Error occured .XMLinjestionService: Line:224 >> ValidationEventHandler: {ex.Message}");
                    throw new ArgumentOutOfRangeException();
            }
        }


        private static void WriteFile(string path1, string fileName, List<string> content)
        {
            try
            {
                var convertedPath = Path.Combine(path1, fileName);
                foreach (string outputinformation in content)
                {
                    File.AppendAllText(convertedPath, outputinformation
                                      + Environment.NewLine);
                }
                _logger.LogApplicationDebug("DSAR DEBUG INFO", $"File {fileName} writing is completed");
            }
            catch (Exception ex)
            {
                _logger.LogApplicationError($"Error occured, Writing to the file {fileName} failed: {ex.Message}");
                throw;
            }
        }

        protected override void OnStop()
        {
            _watcher.Dispose();
        }

        public void Test()
        {
            DebugMode = true;
            OnStart(new[] { "" });
            Console.ReadLine();
            OnStop();
        }

        private void PerformWait()
        {
            if (DebugMode)
            {
                Task.Delay(3000000).Wait();
            }
        }
    }
}