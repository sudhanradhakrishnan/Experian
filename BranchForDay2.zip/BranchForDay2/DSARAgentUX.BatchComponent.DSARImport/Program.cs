﻿using DSARAgentUX.BusinessLayer;
using DSARAgentUX.BusinessLayer.Interfaces;
using DSARAgentUX.Common;
using DSARAgentUX.Models;
using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;
using DSARAgentUX.Models.DataSubjectAccessRequests;
using Topshelf;
using ExperianLogger;

namespace DSARAgentUX.BatchComponent
{

    public class InjestionService
    {
        private FileSystemWatcher _watcher;
        private string xmlPath;
        private string buFileShareLocation;
        private IDSARAgentUXService agentUXService;
        string dir;
        string convertedFileName;
        string FullPath;
        private ILogger logger;
        public InjestionService()
        {
           
        }
        public void Start()
        {
            try
            {
                xmlPath = ConfigurationManager.AppSettings["dSARXmlPath"];
                buFileShareLocation = ConfigurationManager.AppSettings["buFileShareLocation"];

                _watcher = new FileSystemWatcher(xmlPath, "*.xml");
                _watcher.Created += FileCreated;
                _watcher.IncludeSubdirectories = false;
                _watcher.EnableRaisingEvents = true;
            }
            catch (Exception ex)
            {
                logger.LogApplicationError($"DSAR AGENT UX {ex.Message}");
               
            }
        }
        public void Stop()
        {
            _watcher.Dispose();
        }


        private void FileCreated(object sender, FileSystemEventArgs e)
        {
            try
            {
                FullPath = e.FullPath;
                string content = File.ReadAllText(FullPath);
                agentUXService = new DSARAgentUXService();

                //validate the XML and if it throws errors, it will go to Exception section 
                dir = Path.GetDirectoryName(FullPath);
                Stream avcoxml = GetEmbeddedResourceContent("DSAR_Submission.xsd");
                XmlDocument ValidatedAvcoxml = ValidateAvcoxmlAgainstXSD(avcoxml, FullPath);

                //Iterate DSARS node by node.
                IterateNodebyBode(ValidatedAvcoxml);
                convertedFileName = Path.GetFileName(FullPath) + ".processed." + DateTime.Now.ToString("yyyyMMddhhmmtt");
                WriteFile(dir, convertedFileName);


                var outGenerator = new DsarOutputGenerator();
                outGenerator.AddGenerator(new BUFileDsarOutput(FullPath));
                outGenerator.AddGenerator(new HumanFriendlyDsarOutput(FullPath));
                outGenerator.BuildAll(FullPath);


                ////Generate BI File
                //var biFileContent = GenerateBIFileContent(FullPath);
                //var biFileName = Path.Combine(buFileShareLocation, Path.GetFileName(FullPath) + ".BIFile." + DateTime.Now.ToString("yyyyMMddhhmmtt") + ".xml");
                //biFileContent.Save(biFileName);

                //Generate Humanfriendly file
                //var humanReadableFileContent = GenerateHumanReadableContent(FullPath);
                //var hrFileName = Path.Combine(buFileShareLocation, Path.GetFileName(FullPath) + ".HumanReadable." + DateTime.Now.ToString("yyyyMMddhhmmtt") + ".txt");
                //var file = new System.IO.StreamWriter(hrFileName);
                //file.WriteLine(humanReadableFileContent);
                //file.Close();

            }
            catch (Exception ex)
            {
                logger.LogApplicationError($"DSAR AGENT UX {ex.Message}");
                convertedFileName = Path.GetFileName(FullPath) + ".error." + DateTime.Now.ToString("yyyyMMddhhmmtt");
                WriteFile(dir, convertedFileName);
            }
        }

        

        /// <summary>
        /// This method is used to iterate through DSARS and insert DSAR into the BD one by one.
        /// </summary>
        /// <param name="ValidatedAvcoxml">XmlDocument</param>
        private void IterateNodebyBode(XmlDocument ValidatedAvcoxml)
        {
            foreach (XmlNode dsar in ValidatedAvcoxml)
            {
                if (dsar.NodeType == XmlNodeType.Element)
                {
                    foreach (XmlNode dsarlist in dsar.ChildNodes)
                    {
                        agentUXService.SaveAvcoxml(dsarlist.OuterXml);
                    }
                       
                }
            }
        }


        /// <summary>
        /// This Method is used to Load XSD from Resources file and returns stream 
        /// </summary>
        /// <param name="resFilename">XSD file name</param>
        /// <returns>XSD as Stream</returns>
        private Stream GetEmbeddedResourceContent(string resFilename)
        {

            try
            {
               Assembly assembly = Assembly.GetAssembly(typeof(dsars));
                var resourcesfile = assembly.GetManifestResourceNames();
                //string filename = string.Empty;
                string filename = resourcesfile.FirstOrDefault(o => o.Contains(resFilename));
                Stream stream = assembly.GetManifestResourceStream(filename);
                if (stream == null)
                    throw new Exception("Embedded resource " + filename + " doesn't exists");
                byte[] bytes = new byte[stream.Length];
                stream.Position = 0;
                stream.Read(bytes, 0, (int)stream.Length);
                MemoryStream Mstream = new MemoryStream(bytes);
                StreamReader reader = new StreamReader(Mstream);
                string text = reader.ReadToEnd();
                var streamxsd = new MemoryStream();
                var writer = new StreamWriter(streamxsd);
                writer.Write(text);
                writer.Flush();
                streamxsd.Position = 0;
                return streamxsd; // this is your stream
            }

            catch (Exception ex)
            {
                logger.LogApplicationError($"DSAR AGENT UX {ex.Message}");
                return null;
            }

        }


        /// <summary>
        /// This Method is used to vadidate AVCO xml against XSD file.
        /// </summary>
        /// <param name="xsdLocation">XSD Stream</param>
        /// <param name="xml">XML Path</param>
        /// <returns>validated XML as XMLDocument</returns>
        private static XmlDocument ValidateAvcoxmlAgainstXSD(Stream xsdLocation, string xml)
        {

            XmlTextReader tr = new XmlTextReader(xsdLocation);
            XmlSchemaSet schema = new XmlSchemaSet();
            schema.Add(null, tr);
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ValidationType = ValidationType.Schema;
            settings.Schemas.Add(schema);
            settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
            settings.ValidationEventHandler += new ValidationEventHandler(ValidationEventHandler);
            XmlReader xmlReader = XmlReader.Create(xml, settings);
           // var xmlReader = XmlReader.Create(xml, settings);
            var doc = new XmlDocument();
            doc.Load(xmlReader);
            return doc;
        }


        //private static XmlDocument LoadAndValidateDsars(string xsdLocation, string xml)
        //{
        //    var settings = new XmlReaderSettings();
        //    settings.Schemas.Add("http://experian.com/DSAR_Submission/v1", xsdLocation);
        //    settings.ValidationType = ValidationType.Schema;
        //    settings.ValidationEventHandler += ValidationEventHandler;

        //    var xmlReader = XmlReader.Create(xml, settings);
        //    var doc = new XmlDocument();
        //    doc.Load(xmlReader);

        //    return doc;
        //}

        private static dsars DeSerialiseDsars(XmlDocument doc)
        {
            dsars dsars;
            using (TextReader reader = new StringReader(doc.InnerXml))
            {
                var serializer = new XmlSerializer(typeof(dsars));
                dsars = (dsars)serializer.Deserialize(reader);
            }

            return dsars;
        }

        private static void ValidationEventHandler(object sender, ValidationEventArgs e)
        {
            switch (e.Severity)
            {
                case XmlSeverityType.Error:
                   throw new ArgumentOutOfRangeException(e.Message,e.Exception);
                    //TODO: Log Error
                case XmlSeverityType.Warning:
                    throw new ArgumentOutOfRangeException(e.Message, e.Exception);
                    //TODO: Log Error
                default:
                    throw new ArgumentOutOfRangeException(e.Message, e.Exception);
            }
        }


        private void WriteFile(string dir, string convertedFileName)
        {
            try
            {
                var convertedPath = Path.Combine(dir, convertedFileName);
                File.WriteAllText(convertedPath, string.Empty);
            }
            catch (Exception ex)
            {
                logger.LogApplicationError($"DSAR AGENT UX {ex.Message}");
            }
        }
    }

    public class PublisherService
    {
        private ILogger logger;
        //string DailyTime = "22:37:00";
        string DailyTime = ConfigurationManager.AppSettings["dsarpublishDailyTime"];
        string dSARPublishPath = ConfigurationManager.AppSettings["dsarpublishpath"];
        string STSDropPath = ConfigurationManager.AppSettings["stsdroppath"];
        private IDSARAgentUXService agentUXService;
        public delegate string Publisher(string x);

        public PublisherService()
        {

        }
        public void Start()
        {
            try
            {
                Publisher DComp = new Publisher(DSARScheduler(DailyTime));
            }
            catch(Exception ex)
            {
                logger.LogApplicationError($"DSAR AGENT UX {ex.Message}");
            }
        }

        private Publisher DSARScheduler(string dailyTime)
        {

            var timeParts = DailyTime.Split(new char[1] { ':' });
            while (true)
            {

                var dateNow = DateTime.Now;
                var date = new DateTime(dateNow.Year, dateNow.Month, dateNow.Day,
                int.Parse(timeParts[0]), int.Parse(timeParts[1]), int.Parse(timeParts[2]));
                TimeSpan ts;
                if (date > dateNow)
                    ts = date - dateNow;
                else
                {
                    date = date.AddDays(1);
                    ts = date - dateNow;
                }

                //waits certan time and run the code
                Task.Delay(ts).Wait();

                // Do the publish action here!!!
                //TODO : Transaction scope
                try
                {

                    // Create the TransactionScope to execute the commands, guaranteeing
                    // that both commands can commit or roll back as a single unit of work.
                    //using (TransactionScope scope = new TransactionScope())
                    //{
                        DropDSARDetailToSTS();
                        CompleteDSAR();
                        scope.Complete();
                    }
                }
                catch (TransactionAbortedException ex)
                {

                    logger.LogApplicationError($"DSAR AGENT UX {ex.Message}");
                }
                catch (ApplicationException ex)
                {
                    logger.LogApplicationError($"DSAR AGENT UX {ex.Message}");
                }
            }
        }

        private void UpdateDSAR_Complete()
        {
            agentUXService = new DSARAgentUXService();
            agentUXService.UpdateDSAR_Complete();
        }

        private void DropDSARDetailToSTS()
        {
            agentUXService = new DSARAgentUXService();
            agentUXService.DropCsvForCompletedAndDuplicateDsaRs(STSDropPath+ DateTime.Now.ToString("yyyyMMddhhmmtt") + "AgentUXUpdatesOnDSARs.csv");
        }

        private void CompleteDSAR()
        {

                agentUXService = new DSARAgentUXService();
                foreach (var zipWrapper in agentUXService.GetAllPublishedDsarZipMem())
                {
                    using (var fileStream = new FileStream(dSARPublishPath + zipWrapper.DsarValue.Reference + DateTime.Now.ToString("yyyyMMddhhmmtt") + ".zip", FileMode.Create))
                    {
                        var memoryStream = new MemoryStream(zipWrapper.ZipInMemory.ToArray());
                        memoryStream.Seek(0, SeekOrigin.Begin);
                        memoryStream.CopyTo(fileStream);
                    }
                }
 
        }

        public void Stop()
        {

        }
    }


    class Program
    {
        private static ILogger logger;
        public static void Main()
        {
            try
            {
                var rc = Ingestion();
                // var rc = Publisher();
                var exitCode = (int)Convert.ChangeType(rc, rc.GetTypeCode());  //11
                Environment.ExitCode = exitCode;
            }
            catch (Exception ex)
            {
                logger.LogApplicationError($"DSAR AGENT UX {ex.Message}");
            }
        }

        private static TopshelfExitCode Publisher()
        {
            var rc = HostFactory.Run(x => //1
            {
                x.Service<PublisherService>(s => //2
                {
                    s.ConstructUsing(name => new PublisherService()); //3
                    s.WhenStarted(tc => tc.Start()); //4
                    s.WhenStopped(tc => tc.Stop()); //5
                });
                x.RunAsLocalSystem(); //6

                x.SetDescription("DSARInformation Agent UX service to PublishStatus DSARInformation reports."); //7
                x.SetDisplayName("DSARInformation-PublishStatus(Agent UX)"); //8
                x.SetServiceName("DSARInformation-PublishStatus(Agent UX)"); //9
            });
            return rc;
        }

        private static TopshelfExitCode Ingestion()
        {
            var rc = HostFactory.Run(x => //1
            {
                x.Service<InjestionService>(s => //2
                {
                    s.ConstructUsing(name => new InjestionService()); //3
                    s.WhenStarted(tc => tc.Start()); //4
                    s.WhenStopped(tc => tc.Stop()); //5
                });
                x.RunAsLocalSystem(); //6

                x.SetDescription("DSARInformation Agent UX service to load XML into the System."); //7
                x.SetDisplayName("DSARInformation-Load(Agent UX)"); //8
                x.SetServiceName("DSARInformation-Load(Agent UX)"); //9
            }); //10
            return rc;
        }
    }
}
