﻿/*using System;
using System.Collections.Generic;
using System.Text;

namespace DelphiSelectSplunkServices.Services
{
    [CustomAuthorize]

    [HttpGet]

    [HandleError(View = "DetailedError")]

    public async Task<ActionResult> Search(SearchArgsViewModel searchArgs)

    {

        if (!ModelState.IsValid)

        {

            return View("Search", searchArgs);

        }



        //redirect to login if session expired and tried to search

        if (SessionHelper.LogInInfo.UserName == null || SessionHelper.LogInInfo.Password == null)

        {

            return RedirectToAction("Index", "Home");

        }



        // show message if use preset selected but preset is not defined

        if (searchArgs.UsePresets && string.IsNullOrEmpty(searchArgs.Preset))

        {

            ModelState.AddModelError("error.error", "Please select a preset");

            return View("Search", searchArgs);

        }



   /* //<TODO> need to refactor the code with asyc wrapper



    Deepak: Below is the sample query which you can refer.This is query is searching for the logs from a server called CEMS - QAT2 - PEP01 and with event id PPIN003


Search in the string is the keyword which is a mandatory prefix

            //string searchQuery = "search host=CEMS-QAT2-PEP01 Message.EventID=PPIN003 OR Message.EventID=PPIN002";*/

/*

string searchQuery = string.Empty;



        string earlierDate = string.Empty;

        string latestDate = string.Empty;



        SessionHelper.SearchArgs = null;

        searchArgs.TransactionID = string.Empty;



        SetStartAndEndDates(searchArgs, out earlierDate, out latestDate);

        TempData["SearchMessage"] = $"The search is done for the period {earlierDate} to {latestDate}";



        //-----

        if (logger == null) throw new ArgumentNullException(nameof(logger), Common.Constants.Const_LoggerNullError);

        logger.Log(new LogEntry(LoggingEventType.Info, XMLHelper.ConvertObjectToXMLString(searchArgs), Settings.InfoEventID));



    //steps to follow



    //1: Load splunk queries from xml



    //Deepak: my custom queries were stored in an XML file and loaded at runtime




            List<Query> splunkQueries = LoadSplunkQueries(searchArgs);



        //2: Start: Loop through the query collection



        List<RootObject> lstSplunkMessage = new List<RootObject>();



        List<string> listString = new List<string>();

        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

        ServicePointManager.ServerCertificateValidationCallback += (o, c, ch, er) => true;



    //4: Execute the query against splunk



    Deepak: scheme – protocol(normally https), host – URL, port(normally 8089)




            using (var service = new Service(Scheme.Https, Settings.Host, Settings.Port))

        {

        Deepak: should be using the Splunk credentials here – username and password



                      await service.LogOnAsync(SessionHelper.LogInInfo.UserName, SessionHelper.LogInInfo.Password);



            foreach (Query item in splunkQueries)

            {

                searchQuery = string.Empty;

                //3: Replace the place holders and build the query



                if (!searchQuery.StartsWith("search ", StringComparison.OrdinalIgnoreCase))

                {

                    searchQuery = "search " + searchQuery;

                }



                searchQuery = searchQuery + CreateSplunkQuery(item.Text, searchArgs);



            Deepak: there are many search criteria’s but I was using SearchOneShotAsync




                    using (SearchResultStream resultStream = await service.SearchOneShotAsync(searchQuery, 0, new JobArgs

                    {

                       Deepak :  please you need to makesure of the period



                        //<test>

                //EarliestTime = "-30d",

                //LatestTime = "now",



                EarliestTime = earlierDate,

                        LatestTime = latestDate,

                    }))

                    {

                //5: Combine the results

                searchArgs.Results.AddRange(GetAllResults(resultStream, item.Application));

            }

        }//6:  end loop: Loop through the query collection

    }



    SessionHelper.SearchArgs = searchArgs;

 

            return View("Search", searchArgs);

}



Deepak: method used to cast the resultstream to the  object in c#,

You can have two options here

 

Option 1- real time import of records

Option 2 : a service to download the data and a importing mechanism import that to your database








private List<RootObject> GetAllResults(SearchResultStream resultStream, string application)

{

    List<RootObject> lstSplunkMessage = new List<RootObject>();



    foreach (SearchResult result in resultStream)

    {

        try

        {

            lstSplunkMessage.Add(this.ParseResult(result, application));

            lstSplunkMessage[lstSplunkMessage.Count - 1].ItemID = lstSplunkMessage.Count;

        }

        catch

        {

            //the stream has some broken fields

            // Enumeration ended prematurely : System.IO.InvalidDataException: Read <fieldOrder> where </fieldOrder> was expected.  

        }

    }





    return lstSplunkMessage;

}



private RootObject ParseResult(SearchResult searchResult, string application)

{

    string rawData = searchResult.SegmentedRaw.Value;

    RootObject item = JsonConvert.DeserializeObject<RootObject>((rawData));



    item.Message.Application = application;

    item.Message.requestXML = string.IsNullOrEmpty(item.Message.requestXML) ?

                                    string.IsNullOrEmpty(item.Message.DataLog) ? item.Message.GeodsData : item.Message.DataLog

                                    : item.Message.requestXML;



    item.Message.SecurityParameters.experianClientID = item.Message.SecurityParameters.experianClientID ?? "NA";

    item.Message.SecurityParameters.Organisation = item.Message.SecurityParameters.Organisation ?? "NA";



    return item;

}
}*/
