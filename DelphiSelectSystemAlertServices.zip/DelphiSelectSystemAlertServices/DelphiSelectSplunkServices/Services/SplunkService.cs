﻿using DelphiSelectSplunkServices.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Xml.Linq;

namespace DelphiSelectSplunkServices.Services
{
    public class SplunkService : ISplunkService
    {
        private string BaseUrl = "http://localhost:8000";

        public string AccessSplunk()
        {
            var client = new WebClient();
            var parameters = new Dictionary<string, string>
                {
                    { "username", "admin" },
                    { "password", "mypassword" }
                };

            var result = client.UploadString(String.Format("{0}/services/auth/login", BaseUrl), UrlEncode(parameters));
            var doc = XDocument.Load(result);  // load response into XML document (LINQ)
            var key = doc.Elements("sessionKey").Single().Value; // get the one-and-only <sessionKey> element.
            string returnsterin = @"====>sessionkey:  {0}  <===="+ key;
            return returnsterin;
        }

        // Utility function: 
        private string UrlEncode(IDictionary<string, string> parameters)
        {
            var sb = new StringBuilder();
            foreach (var val in parameters)
            {
                // add each parameter to the query string, url-encoding the value.
                sb.AppendFormat("{0}={1}&", val.Key, HttpUtility.UrlEncode(val.Value));
            }
            sb.Remove(sb.Length - 1, 1); // remove last '&'
            return sb.ToString();
        }
    }
}
