﻿using DelphiSelectSystemServices.Interface;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DelphiSelectSystemServices.Services
{
    public class ServiceA : IServiceA
    {
        private readonly ILogger<ServiceA> _logger;
        private readonly IEmailService _serviceB;

        public ServiceA(ILogger<ServiceA> logger, IEmailService serviceB)
        {
            _logger = logger;
            _serviceB = serviceB;
        }

        public void Run()
        {
            _logger.LogInformation("In Service A");

            string strFilePath = @"C:\Temp\";
            // System.IO.File.AppendAllText(@"C:\\izaz\\"+DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss")+".txt", Envireonment.NewLine + "Duration: " + s + Environment.NewLine);
            var path = strFilePath + "Data" + DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss") + ".csv";
            string strSeperator = ",";
            StringBuilder sbOutput = new StringBuilder();

            int[][] inaOutput = new int[][]{
            new int[]{1000, 2000, 3000, 4000, 5000},
            new int[]{6000, 7000, 8000, 9000, 10000},
            new int[]{11000, 12000, 13000, 14000, 15000} };

            int ilength = inaOutput.GetLength(0);

            for (int i = 0; i < ilength; i++)
                sbOutput.AppendLine(string.Join(strSeperator, inaOutput[i]));

            // Create and write the csv file
            File.WriteAllText(path, sbOutput.ToString());

            // To append more lines to the csv file
            File.AppendAllText(path, sbOutput.ToString());

            _serviceB.Run();
        }
    }
}
