﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DelphiSelectSystemServices.Interface
{
    public interface IEmailService
    {
        void Run();
        void SendEmail(String ToEmail, string cc, string bcc, String Subj, string Message);
    }
}
