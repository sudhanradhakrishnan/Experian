﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DelphiSelectSystemServices.Interface
{

    public interface IServiceA
    {
        void Run();
    }

}
